# Brand Profile: Purewine

> **OFFBOARDING (Mike, 2026-07-23):** brand is leaving RMC soon. Maintenance only — no proactive listing rewrites, audits, or campaign builds unless Mike asks. Unconfirmed draft sections below are frozen as-is.

```yaml
brand_id: purewine
name: Purewine
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B07LGBLWBS | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... | Yes |
| B06XGP85LR | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... | Yes |
| B09HJJ2C8Z | PureWine Phoenix Bio-Pods - Premium Wine Filter Replacements for Enhanced Flavour - Rem... |  |
| B09HJMRZWS | Phoenix Wine Aerator & Purifier - Reusable Wine Aerator Pourer with BioPod Filter Syste... |  |
| B099MNMLVZ | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B09RRX1XF8 | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B0BJ4JSQB6 | Phoenix Wine Aerator & Purifier - Reusable Wine Aerator Pourer with BioPod Filter Syste... |  |
| B0771H8V5H | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B08TRNKYND | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... | Yes |
| B08JNQ39JM | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... | Yes |
| B099M8WLKD | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B06XGP5B63 | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B0CN9J6NQ4 | PureWine Pink Wand Technology Histamine and Sulfite Filter, Purifier Reduces Wine Aller... |  |
| B0FL9J8QJQ | (no title on file) |  |
| B06XBPFHNJ | PureWine Wand Filters Stick Histamines and Sulfites - Reduces Wine Allergies & Purifier... |  |

_Last synced: 2026-07-30 (15 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

_(draft — Mike to confirm)_ Wine drinkers 30–65 who get headaches/congestion from wine, plus gift buyers (host gifts, wine lovers). Problem-aware shoppers searching for a fix. Premium accessory pricing.

## Voice & tone

_(draft)_ Confident, practical, a little celebratory — solving a real annoyance without medical gravity.
Fits: "Filter out the histamines and sulfites. Keep the wine."
Does not fit: medical promises, chemistry-lecture tone, party-gimmick silliness.

## Claims — approved

**Apply per product per its current listing; never transplant.**

| Claim | Substantiation |
|---|---|
| Removes/filters histamines & sulfites | product function, current listings |
| Removes sediment | current listings (Phoenix pods) |
| No added chemicals / nothing added to the wine | current listings where stated |
| Works with red, white & rosé | current listings |
| BPA-free etc. | label facts where stated |

## Claims — banned

- **PENDING MIKE:** "Eliminate Headaches & Allergies" is on the CURRENT live titles — that is a health-outcome claim, not a filtration fact. Draft position: banned in all NEW copy (say what the filter removes, never what symptoms it prevents); existing titles are the brand's call to fix. Confirm.
- Any health outcome: prevents/eliminates headaches, allergy relief, hangover prevention/cure.
- Any implication of medical benefit or that filtered wine is "healthier".

## Keywords

<!-- AUTO:KEYWORDS START — data columns refresh weekly from Data Dive; Tier override + Notes are yours and survive every refresh -->
| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| purewine biopods | 250 |  | 1 (B09HJJ2C8Z) | Defend |  |  |
| the phoenix wine filter pods | 250 |  | 1 (B09HJJ2C8Z) | Defend |  |  |
| the phoenix wine purifier | 250 |  | 1 (B09HJMRZWS) | Defend |  |  |
| the phoenix wine | 250 |  | 1 (B09HJMRZWS) | Defend |  |  |
| purewine phoenix | 250 |  | 1 (B09HJMRZWS) | Defend |  |  |
| the wands for wine | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| wine wand | 250 | 0.7 | 1 (B06XGP85LR) | Defend |  |  |
| sulfite removing stick | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| wine sticks | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| no more headaches wine sticks | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| wine wands | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| the wand for wine headaches | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| no hangover wine sticks | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| wine stick | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| the wand for wine | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| the wand no more wine headaches | 250 | 0.63 | 1 (B06XGP85LR) | Defend |  |  |
| the wand wine purifier | 250 | 0.73 | 1 (B06XGP85LR) | Defend |  |  |
| pure wine wand purifier | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| no more wine headaches the wand | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| the wine wand | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| wine wand filter stick | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| the wand wine filter | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| the wand wine | 250 |  | 1 (B06XGP85LR) | Defend |  |  |
| goodbye sulfites | 250 | 0.2 | 2 (B06XGP85LR) | Defend |  |  |
| wine sulfite remover | 250 | 0.7 | 2 (B06XGP85LR) | Defend |  |  |
| sulphite wine filter | 250 |  | 2 (B06XGP85LR) | Defend |  |  |
| sulfite remover for wine | 250 | 0.7 | 2 (B06XGP85LR) | Defend |  |  |
| sulphite remover wine | 250 |  | 2 (B06XGP85LR) | Defend |  |  |
| sulphite wine remover | 250 |  | 2 (B06XGP85LR) | Defend |  |  |
| wine headaches | 250 |  | 2 (B06XGP85LR) | Defend |  |  |
| wine sticks to remove sulfites | 250 |  | 2 (B06XGP85LR) | Defend |  |  |
| sulfites remover | 250 |  | 2 (B06XGP85LR) | Defend |  |  |
| wine filter stick | 250 |  | 2 (B06XGP85LR) | Defend |  |  |
| wine wand filter | 250 |  | 2 (B06XGP85LR) | Defend |  |  |
| wine purifier | 250 | 1 | 3 (B06XGP85LR) | Defend |  |  |
| wine histamine remover | 250 |  | 3 (B06XGP85LR) | Defend |  |  |
| wine sulphites remover | 250 |  | 3 (B06XGP85LR) | Defend |  |  |
| sulfate remover wine | 250 |  | 3 (B06XGP85LR) | Defend |  |  |
| no more wine headaches | 250 |  | 3 (B06XGP85LR) | Defend |  |  |
| wine sulfite and histamine remover | 250 |  | 3 (B06XGP85LR) | Defend |  |  |
| wine stir sticks that help reduce hangover | 250 |  | 3 (B06XGP85LR) | Defend |  |  |
| wine purifier sulfite remover | 250 | 0.8 | 3 (B06XGP85LR) | Defend |  |  |
| wine filter sticks | 250 |  | 4 (B06XGP85LR) | Defend |  |  |
| wine filter that takes histamine out￼ | 250 |  | 4 (B06XGP85LR) | Defend |  |  |
| remove sulfites and histamines from wine | 250 |  | 4 (B06XGP85LR) | Defend |  |  |
| wine filter alleviates hangover headaches | 250 |  | 4 (B06XGP85LR) | Defend |  |  |
| wine stir stick | 250 |  | 5 (B06XGP85LR) | Defend |  |  |
| the wand | 250 |  | 7 (B099M8WLKD) | Strike zone |  |  |
| wine related gifts | 250 |  | 8 (B06XGP85LR) | Strike zone |  |  |
| gifts for wine connoisseur | 250 |  | 9 (B06XGP85LR) | Strike zone |  |  |
| wine aerator sulphite filter | 250 |  | 11 (B09HJMRZWS) | Strike zone |  |  |
| wine aerator and filter | 250 |  | 12 (B09HJMRZWS) | Strike zone |  |  |
| wine filter sulphites | 250 |  | 15 (B09HJMRZWS) | Strike zone |  |  |
| wine accessories for wine lovers | 250 | 0.1 | 16 (B06XGP85LR) | Strike zone |  |  |
| gifts for wine lovers | 250 | 0.1 | 16 (B06XGP85LR) | Strike zone |  |  |
| wine filters | 250 |  | 18 (B06XGP85LR) | Strike zone |  |  |
| wine filter | 250 | 0.67 | 20 (B06XGP85LR) | Strike zone |  |  |
| wand | 1567 | 0.1 | 22 (B06XGP85LR) | Strike zone |  |  |
| wine accessories | 250 | 0.2 | 27 (B06XGP85LR) | Strike zone |  |  |
| wine gadgets | 250 |  | 30 (B0771H8V5H) | Strike zone |  |  |

_Synced 2026-07-30 from dashboard Data Dive snapshots. Rank = best across tracked ASINs (shown in brackets). Rank ≤30 keywords always listed; the rest are top-volume._
<!-- AUTO:KEYWORDS END -->

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO — team to add (Üllo is the known category rival; confirm before targeting).

## Notes

- Current live titles carry the "Eliminate Headaches & Allergies" claim — flagged above; several titles also exceed 75 chars (in the title sweep).
- Strong gifting angle (occasions/holiday) worth a promo-calendar note.
