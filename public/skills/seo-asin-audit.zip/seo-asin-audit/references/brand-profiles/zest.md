# Brand Profile: Zest

> **Minimal-effort brand (Mike, 2026-07-23):** staying, but low investment by design. Quick wins only (e.g. the bare 23-char title) — no deep audits, no sustained keyword work.

```yaml
brand_id: zest
name: Zest
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B0G3B8YKF2 | Zest Under Eye Patches for Dark Circles – Under Eye Mask with Collagen & Hyaluronic Aci... |  |
| B0CRFSFP4P | Zest Under Eye Patches for Dark Circles – Under Eye Mask with Collagen & Hyaluronic Aci... | Yes |
| B0GTMZSRLY | Zest Under Eye Patches |  |

_Last synced: 2026-07-30 (3 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

Women 25–50 buying affordable self-care/skincare extras; impulse + gift friendly price point.

## Voice & tone

Fresh, light, ritual-forward — a spa moment at home.
Fits: "Ten minutes. Cooler, brighter under-eyes."
Does not fit: medical/anti-aging promises, luxury-brand seriousness.

## Claims — approved

**Acure cosmetic model: ingredient + free-from facts per current listing; cosmetic-APPEARANCE wording only.**

| Claim | Substantiation |
|---|---|
| With Collagen & Hyaluronic Acid | label / current listing |
| "Reduces the appearance of" puffiness/dark circles/wrinkles | cosmetic wording — appearance only |
| Count/usage facts (pairs per jar etc.) | label |

## Claims — banned

- Structural/medical skin claims: "removes wrinkles", "repairs skin", "treats dark circles" — appearance wording only.
- Anything not on the current listing/label.

## Keywords

<!-- AUTO:KEYWORDS START — data columns refresh weekly from Data Dive; Tier override + Notes are yours and survive every refresh -->
| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| brightening eye patches | 250 | 0.71 | 18 (B0CRFSFP4P) | Strike zone |  |  |
| eye patches | 72489 | 0.93 | 101 (B0CRFSFP4P) | — |  |  |
| eye mask | 56184 | 0.5 | 101 (B0CRFSFP4P) | — |  |  |
| under eye patches | 32798 | 0.93 | 82 (B0CRFSFP4P) | Long shot |  |  |
| eye masks | 11158 | 0.71 | 101 (B0CRFSFP4P) | — |  |  |
| eye patch | 9889 | 0.86 | 101 (B0CRFSFP4P) | — |  |  |
| patch yeux | 7855 | 0.93 | 101 (B0CRFSFP4P) | — |  |  |
| dark circles under eye treatment | 6682 | 0.36 | 101 (B0CRFSFP4P) | — |  |  |
| under eye mask | 5890 | 0.93 | 78 (B0CRFSFP4P) | Long shot |  |  |
| eye patches for dark circles | 4334 | 0.86 | 48 (B0CRFSFP4P) | Long shot |  |  |
| under eye | 4189 | 0.64 | 101 (B0CRFSFP4P) | — |  |  |
| eye masks for dark circles and puffiness | 2650 | 0.86 | 47 (B0CRFSFP4P) | Long shot |  |  |
| dark circles | 1899 | 0.5 | 101 (B0CRFSFP4P) | — |  |  |
| collagen eye patches | 1871 | 0.79 | 63 (B0CRFSFP4P) | Long shot |  |  |
| eyemask | 1780 | 0.5 | 101 (B0CRFSFP4P) | — |  |  |

_Synced 2026-07-30 from dashboard Data Dive snapshots. Rank = best across tracked ASINs (shown in brackets). Rank ≤30 keywords always listed; the rest are top-volume._
<!-- AUTO:KEYWORDS END -->

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

_(pre-drafted from search-term + Data Dive data, 30d to 2026-07-19 — team to confirm)_

Crowded, white-label-heavy category (~72k monthly CA searches on "eye patches" per Data Dive). On our keywords:

- **Rhode** — data-backed: shoppers reach us via "rhode eye patches" (3 clicks, 1 order) — cheap conquest traffic, keep it.
- **grace & stella** — category leader on Amazon.ca under-eye patch terms (knowledge-based — confirm).
- **LANEIGE / Wander Beauty** — premium end, more "eye mask" than patch terms (knowledge-based — confirm).

Minimal-effort brand: know who's on the shelf beside us; don't build conquest campaigns.

## Notes

- Only 3 ASINs, one with a bare 23-char title ("Zest Under Eye Patches") — under-optimized; the one quick listing-copy win worth taking.
- 1 rank radar.
