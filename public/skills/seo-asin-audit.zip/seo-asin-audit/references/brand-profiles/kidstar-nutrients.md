# Brand Profile: Kidstar Nutrients

```yaml
brand_id: kidstar-nutrients
name: Kidstar Nutrients
marketplaces: [CA]
category: children's & family supplements (NHP)
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B09NJQGJTH | KidStar Nutrients BioFe Pure Iron Chewables, Sweet Blast, No Sugar, Sweetened with Xyli... | Yes |
| B0CJW8F4S4 | KidStar Nutrients BioFe Pure Iron Chewables, Sweet Blast, No Sugar, Sweetened with Xylitol |  |
| B0D9HX2FRP | Kidstar Nutrients - BioFe Pure Iron 5mg, 120 Chewable Tablets 60-Day Supply - Helps to ... | Yes |
| B0DPGP2NC4 | KidStar Nutrients - BeRegular Prebiotic Fibre & Probiotic Blend, 180g Unflavoured Powde... | Yes |
| B0B1RX555V | KidStar Nutrients - BioFe+ Iron Liquid for the Family, 250ml 50-Servings - Helps to Pre... | Yes |
| B0B1RJBWP7 | KidStar Nutrients - Star Multi Kids Multivitamin, 60 Chewable Tablets 60-Day Supply, Sp... | Yes |
| B0GYZNMV83 | KidStar Nutrients StarMulti Multinutrient Chewable (Space Berry) |  |
| B0F8KPTRF4 | KidStar Nutrients - BioFe Liquid Elemental Iron 30mg, 46 Sachets 46-Day Supply - Helps ... | Yes |
| B0B1RXN2VX | KidStar Nutrients - Vitamin D3 Spray 500 IU, 52ml Liquid 375-Servings, Organic Orange F... | Yes |
| B0GYZPSVRB | KidStar Nutrients - Vitamin D3 Spray 500 IU, Organic Orange |  |
| B0BTKTPBWD | KidStar Nutrients BioFe Pure Iron Chewables, Natural Grape Flavour, 10 Mg Iron Per Tabl... | Yes |
| B0GYZSDKFQ | KidStar Nutrients BioFe Pure Iron Chewables, Natural Grape Flavour, 60 Chewable Tablets |  |
| B0BJHHY19F | (no title on file) | Yes |
| B0GGDTTPJH | KidStar Nutrients All-in-One Vegan Protein Vanilla, For Kids and Adults, 10 Grams Plant... |  |
| B0GYZVJ3DV | KidStar Nutrients All-in-One Plant-Based Protein 400g |  |
| B09K4FX6T5 | KidStar Nutrients - BioFe+ Liquid Iron with Vitamin B6 & B12 for the Family, 250ml 50-S... |  |
| B0GYZVS452 | KidStar Nutrients BioFe+ Iron Liquid ADULT LABEL (Sweet Blast), 250 mL |  |
| B0B1RSXX4P | Kidstar Nutrients - BioFe Pure Iron Drops Unflavoured 30ml 50-Day Supply - Helps to Pre... |  |
| B0GZ1PJ7PS | KidStar Nutrients BioFe Pure Iron Drops Unflavoured 30ml |  |
| B0GYZMWT46 | KidStar Nutrients BioFe+ Iron Liquid KIDS LABEL (Sweet Blast), 250ml |  |
| B0GXX6QYWW | KidStar Nutrients - BioFe Liquid Elemental Iron 30mg, 46 Sachets 46-Day Supply - Helps ... |  |
| B0B1RNX7LS | KidStar All-in-One Vegan Protein Powder, Chocolate Flavour, Plant-Based Protein Blend, ... |  |
| B0GY1RQ7XQ | KidStar Nutrients BioFe Pure Iron 5mg, 120 Chewable Tablets & BioFe Pure Iron 5mg, 60 C... |  |
| B0GY1SB9KM | KidStar Nutrients BioFe+ Iron Liquid for the Family, Kids 250ml & BioFe+ Iron Liquid fo... |  |
| B0GXXBPZTL | KidStar Nutrients - BioFe+ Iron Liquid for the Family, 250ml 50-Servings - Helps to Pre... |  |
| B0GXX5Y68V | KidStar Nutrients - Star Multi Kids Multivitamin, 60 Chewable Tablets, Space Berry Flav... | Yes |
| B0GXXBFCT9 | KidStar Nutrients - Vitamin D3 Spray 500 IU, 52ml Liquid 375-Servings, Organic Orange F... |  |
| B0GXX63BWK | KidStar Nutrients Omega 3 with Vitamin D3, High-DHA, Lemon Blueberry, 120 Chewable Soft... |  |
| B0GY1KSZPB | KidStar Nutrients Omega 3 with Vitamin D3, 120 Chewable Softgels & BioFe Pure Iron 5mg,... |  |
| B0GYZVDXHH | KidStar Nutrients Omega 3 with Vitamin D3, High-DHA, Lemon Blueberry |  |
| B0GXX7VMG3 | KidStar Nutrients BioFe Pure Iron Chewables, Sweet Blast, No Sugar, Sweetened with Xyli... | Yes |
| B0GYZWXC7N | KidStar Nutrients Vitamin C Chewable tablets |  |
| B0GY1VK6ST | KidStar Nutrients BioFe Pure Iron Drops Unflavoured 30ml & BioFe+ Iron Liquid for the F... |  |
| B0GXX8DG6F | Kidstar Nutrients - BioFe Pure Iron Drops Unflavoured 30ml - Helps to Prevent Iron Defi... | Yes |
| B0GXWYHYLN | KidStar Nutrients BioFe Pure Iron Chewables, Natural Grape Flavour, 10 Mg Iron Per Tabl... |  |
| B0CGTNWQY1 | KidStar Vitamin C 250mg, 60 Sugar-Free Chewable Tablets 60-Day Supply, Tangy Tangerine ... | Yes |
| B0GY1W84L8 | KidStar Nutrients Vitamin C 250mg, 60 Chewable Tablets & BioFe Pure Iron 5mg, 60 Chewab... |  |
| B0GY1QV1DG | KidStar Nutrients Star Multi Kids Multivitamin, 60 Chewable Tablets & BioFe Pure Iron 5... | Yes |
| B0GY1RJV9T | KidStar Nutrients Vitamin C 250mg, 60 Chewable Tablets & Star Multi Kids Multivitamin, ... | Yes |
| B0GYZPLYWK | (no title on file) |  |
| B0GXX59C4G | (no title on file) |  |
| B0GXX48MQG | (no title on file) |  |
| B0GY1SBHQF | (no title on file) |  |
| B0H4S9BQ1Q | (no title on file) |  |
| B0H3QKZRPF | (no title on file) |  |

_Last synced: 2026-07-30 (45 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

Health-conscious parents looking for high-quality supplements for their children — with a big emphasis on baby and toddler products, a segment that isn't widely served. That scarcity is a core differentiator: for many buyers there is no obvious alternative. Price position: slightly above the big-corporation brands, bordering on premium.

## Voice & tone

Warm, parental, a little fun — with clinical/science support standing behind it. Lead with the parent's care, back it with the credentials; never lecture, never sound like a pharma insert.
Fits: "Gentle iron your kid will actually take — backed by the science your pediatrician would ask about."
Does not fit: fear-based copy, cold clinical tone, candy-brand silliness, any effect promise beyond the licensed claim (see Claims).

## Claims — approved

**One rule: whatever licensed claim is already on that specific product's current listing and label is fair to use. Anything that isn't, is not.**

- Reuse the licensed NHP wording exactly as it appears (e.g. "Helps to prevent iron deficiency") — on that product only.
- Never transplant a claim from one product to another, even within the same line.
- Dosage, age ranges, servings, supply counts are label facts — never estimate, round, or extend them.

## Claims — banned

- Anything not on that product's current listing/label (see above — the rule cuts both ways).
- Any disease treatment/cure language or effect claim beyond the exact licensed wording.

## Keywords

<!-- AUTO:KEYWORDS START — data columns refresh weekly from Data Dive; Tier override + Notes are yours and survive every refresh -->
| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| iron supplements for kids | 3028 | 0.91 | 1 (B0CJW8F4S4) | Defend |  |  |
| kids iron | 2078 | 0.91 | 1 (B0CJW8F4S4) | Defend |  |  |
| iron for kids | 1735 | 1 | 1 (B0CJW8F4S4) | Defend |  |  |
| kids iron supplement | 1637 | 0.91 | 1 (B0CJW8F4S4) | Defend |  |  |
| iron supplements kids | 250 | 1 | 1 (B0CJW8F4S4) | Defend |  |  |
| kidstar multivitamin | 250 | 0.82 | 1 (B0B1RJBWP7) | Defend |  |  |
| baby iron drops | 472 | 1 | 2 (B0GZ1PJ7PS) | Defend |  |  |
| toddler iron supplement | 250 | 1 | 2 (B0CJW8F4S4) | Defend |  |  |
| iron drops baby | 250 | 0.9 | 2 (B0GZ1PJ7PS) | Defend |  |  |
| iron drops | 250 | 1 | 2 (B0GZ1PJ7PS) | Defend |  |  |
| liquid iron for kids | 250 | 1 | 2 (B0GYZMWT46) | Defend |  |  |
| iron drops for kids | 250 | 1 | 2 (B0GZ1PJ7PS) | Defend |  |  |
| methylated multivitamin kids | 250 | 1 | 2 (B0B1RJBWP7) | Defend |  |  |
| protein powder for kids | 250 | 1 | 3 (B0GYZVJ3DV) | Defend |  |  |
| baby iron supplement | 250 | 0.7 | 4 (B0GZ1PJ7PS) | Defend |  |  |
| kids protein powder | 864 | 1 | 4 (B0GYZVJ3DV) | Defend |  |  |
| kids methylated multivitamin | 250 | 1 | 4 (B0B1RJBWP7) | Defend |  |  |
| vitamin d spray | 250 | 0.43 | 6 (B0GYZPSVRB) | Strike zone |  |  |
| kids multivitamin with iron | 706 | 0.91 | 6 (B0B1RJBWP7) | Strike zone |  |  |
| kids protein | 250 | 0.9 | 9 (B0GYZVJ3DV) | Strike zone |  |  |
| omega kids | 250 | 0.9 | 9 (B0GYZVDXHH) | Strike zone |  |  |
| omega 3 kids | 3623 | 0.9 | 10 (B0GYZVDXHH) | Strike zone |  |  |
| chewable iron supplements | 250 | 1 | 10 (B0CJW8F4S4) | Strike zone |  |  |
| kids vitamins with iron | 250 | 0.82 | 10 (B0CJW8F4S4) | Strike zone |  |  |
| methylfolate kids | 250 | 0.45 | 10 (B0B1RJBWP7) | Strike zone |  |  |
| kids omega | 593 | 1 | 11 (B0GYZVDXHH) | Strike zone |  |  |
| omega 3 for kids | 972 | 0.9 | 12 (B0GYZVDXHH) | Strike zone |  |  |
| omega for kids | 250 | 0.9 | 12 (B0GYZVDXHH) | Strike zone |  |  |
| kids omega 3 | 1463 | 1 | 13 (B0GYZVDXHH) | Strike zone |  |  |
| iron chewable | 250 | 0.91 | 13 (B0CJW8F4S4) | Strike zone |  |  |
| omega 3 chewable | 250 | 0.7 | 14 (B0GYZVDXHH) | Strike zone |  |  |
| chewable iron | 710 | 0.82 | 14 (B0CJW8F4S4) | Strike zone |  |  |
| protein for kids | 250 | 0.9 | 15 (B0GYZVJ3DV) | Strike zone |  |  |
| kids vitamin c | 929 | 1 | 16 (B0GYZWXC7N) | Strike zone |  |  |
| blood builder iron supplement | 1955 | 0.36 | 16 (B0CJW8F4S4) | Strike zone |  |  |
| vitamine d enfant | 250 | 0.79 | 16 (B0GYZPSVRB) | Strike zone |  |  |
| vitamin c for kids | 250 | 1 | 17 (B0GYZWXC7N) | Strike zone |  |  |
| probiotic powder | 948 | 0.71 | 17 (B0DPGP2NC4) | Strike zone |  |  |
| childrens multivitamins | 250 | 1 | 17 (B0B1RJBWP7) | Strike zone |  |  |
| vitamin c kids | 820 | 1 | 18 (B0GYZWXC7N) | Strike zone |  |  |
| vitamin c 250mg | 250 | 0.36 | 18 (B0GYZWXC7N) | Strike zone |  |  |
| kids protein shake | 250 | 1 | 18 (B0GYZVJ3DV) | Strike zone |  |  |
| toddler multivitamin 2 year old | 250 | 0.91 | 18 (B0B1RJBWP7) | Strike zone |  |  |
| kids methylfolate | 250 | 0.36 | 18 (B0B1RJBWP7) | Strike zone |  |  |
| bio active fiber | 250 | 0.43 | 19 (B0DPGP2NC4) | Strike zone |  |  |
| omega 3 enfant | 250 | 0.9 | 19 (B0GYZVDXHH) | Strike zone |  |  |
| vitamin d3 kids | 250 | 0.79 | 19 (B0GYZPSVRB) | Strike zone |  |  |
| kids multi vitamin | 250 | 1 | 19 (B0B1RJBWP7) | Strike zone |  |  |
| multivitamin for kids | 250 | 1 | 19 (B0B1RJBWP7) | Strike zone |  |  |
| probiotic and prebiotic supplement | 250 | 0.71 | 20 (B0DPGP2NC4) | Strike zone |  |  |
| prebiotic and probiotic supplement | 250 | 0.86 | 20 (B0DPGP2NC4) | Strike zone |  |  |
| vitamin d kids | 2602 | 0.64 | 20 (B0GYZPSVRB) | Strike zone |  |  |
| kids vitamins | 9919 | 1 | 20 (B0B1RJBWP7) | Strike zone |  |  |
| toddler multivitamin | 979 | 0.91 | 20 (B0B1RJBWP7) | Strike zone |  |  |
| omega 3 supplements kids | 250 | 0.9 | 21 (B0GYZVDXHH) | Strike zone |  |  |
| toddler multivitamin 3 years old | 250 | 0.82 | 21 (B0B1RJBWP7) | Strike zone |  |  |
| multi vitamins kids | 1392 | 1 | 21 (B0B1RJBWP7) | Strike zone |  |  |
| iron liquid | 1363 | 0.93 | 22 (B0GYZMWT46) | Strike zone |  |  |
| prebiotics and probiotics in one | 1641 | 0.57 | 22 (B0DPGP2NC4) | Strike zone |  |  |
| bio active fibre | 250 | 0.57 | 22 (B0DPGP2NC4) | Strike zone |  |  |
| kids fish oil | 250 | 0.9 | 22 (B0GYZVDXHH) | Strike zone |  |  |
| vit d kids | 250 | 0.79 | 22 (B0GYZPSVRB) | Strike zone |  |  |
| multivitamins for kids | 2693 | 1 | 22 (B0B1RJBWP7) | Strike zone |  |  |
| multivitamin kids | 758 | 1 | 22 (B0B1RJBWP7) | Strike zone |  |  |
| kids multivitamins | 250 | 1 | 22 (B0B1RJBWP7) | Strike zone |  |  |
| kid multivitamin | 250 | 1 | 22 (B0B1RJBWP7) | Strike zone |  |  |
| liquid iron | 4162 | 0.93 | 23 (B0GYZMWT46) | Strike zone |  |  |
| iron supplements liquid | 494 | 0.87 | 23 (B0GYZMWT46) | Strike zone |  |  |
| vit c chewable | 250 | 0.36 | 23 (B0GYZWXC7N) | Strike zone |  |  |
| kids vitamin d | 2492 | 0.71 | 23 (B0GYZPSVRB) | Strike zone |  |  |
| vitamin d for baby | 696 | 0.71 | 23 (B0GYZPSVRB) | Strike zone |  |  |
| kids multivitamin | 7400 | 1 | 23 (B0B1RJBWP7) | Strike zone |  |  |
| vitamins kids | 1425 | 1 | 23 (B0B1RJBWP7) | Strike zone |  |  |
| kid vitamins | 672 | 1 | 23 (B0B1RJBWP7) | Strike zone |  |  |
| vitamins for kids | 575 | 1 | 23 (B0B1RJBWP7) | Strike zone |  |  |
| prebiotics | 1421 | 0.71 | 24 (B0DPGP2NC4) | Strike zone |  |  |
| prebiotic fibre | 250 | 0.71 | 24 (B0DPGP2NC4) | Strike zone |  |  |
| pre/probiotic supplements | 250 | 0.57 | 24 (B0DPGP2NC4) | Strike zone |  |  |
| fish oil for kids | 250 | 0.8 | 24 (B0GYZVDXHH) | Strike zone |  |  |
| vitamin d toddler | 250 | 1 | 24 (B0GYZPSVRB) | Strike zone |  |  |
| growth vitamins for kids | 735 | 0.82 | 24 (B0B1RJBWP7) | Strike zone |  |  |
| vitamin kids | 684 | 0.45 | 24 (B0B1RJBWP7) | Strike zone |  |  |
| childrens vitamins | 250 | 1 | 24 (B0B1RJBWP7) | Strike zone |  |  |
| liquid iron supplement | 564 | 0.87 | 25 (B0GYZMWT46) | Strike zone |  |  |
| iron liquid supplements | 250 | 0.87 | 25 (B0GYZMWT46) | Strike zone |  |  |
| fish oil kids | 250 | 0.8 | 25 (B0GYZVDXHH) | Strike zone |  |  |
| vitamin d for kids | 1484 | 0.71 | 25 (B0GYZPSVRB) | Strike zone |  |  |
| toddler vitamin d | 490 | 1 | 25 (B0GYZPSVRB) | Strike zone |  |  |
| vitamin for kids | 250 | 1 | 25 (B0B1RJBWP7) | Strike zone |  |  |
| vitamin d baby | 1654 | 0.86 | 26 (B0GYZPSVRB) | Strike zone |  |  |
| toddler vitamins | 1530 | 0.82 | 26 (B0B1RJBWP7) | Strike zone |  |  |
| kids vitamin | 821 | 1 | 26 (B0B1RJBWP7) | Strike zone |  |  |
| probiotic prebiotic | 250 | 0.71 | 27 (B0DPGP2NC4) | Strike zone |  |  |
| baby dha | 250 | 0.3 | 27 (B0GYZVDXHH) | Strike zone |  |  |
| dha kids | 250 | 0.8 | 27 (B0GYZVDXHH) | Strike zone |  |  |
| baby vitamin d | 808 | 0.86 | 27 (B0GYZPSVRB) | Strike zone |  |  |
| vitamin d enfant | 250 | 0.64 | 27 (B0GYZPSVRB) | Strike zone |  |  |
| prebiotic | 1305 | 0.57 | 28 (B0DPGP2NC4) | Strike zone |  |  |
| vitamin c chewables | 250 | 0.45 | 29 (B0GYZWXC7N) | Strike zone |  |  |
| vitamine d enfants | 250 | 0.64 | 29 (B0GYZPSVRB) | Strike zone |  |  |
| children's vitamin d | 250 | 0.64 | 29 (B0GYZPSVRB) | Strike zone |  |  |
| all in one protein powder | 775 | 0.3 | 30 (B0GYZVJ3DV) | Strike zone |  |  |
| l methylfolate kids | 250 | 0.36 | 30 (B0B1RJBWP7) | Strike zone |  |  |

_Synced 2026-07-30 from dashboard Data Dive snapshots. Rank = best across tracked ASINs (shown in brackets). Rank ≤30 keywords always listed; the rest are top-volume._
<!-- AUTO:KEYWORDS END -->

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

Per product line — assess ASIN-by-ASIN, not brand-level:
- **BioFe iron (the main line): effectively no direct competitors.** Category-leadership play — own the terms, don't frame against anyone.
- **StarMulti:** competes as a general kids' multivitamin — the crowded end of the catalog; evaluate competitors per ASIN there.
- Other lines (D3, omega-3, protein, fibre): judge each ASIN's competitive set individually.

## Notes

- **Massive focus on repeat purchase and Subscribe & Save** — favour S&S enrollment, retention framing, and repeat-purchase metrics in every audit and recommendation.
- **Promotions run on the tentpole dates:** Prime Day, Big Deal Days, Black Friday, Cyber Monday, Boxing Day, Big Spring Sale. No off-calendar promo rhythm.
- **Catalog quirk:** many bundles and multi-packs launched deliberately as value tiers. Bundle copy must name both components; variant distinguishers (flavor, count, format — chewable/liquid/drops/sachets, kids vs adult label) must survive every rewrite.
