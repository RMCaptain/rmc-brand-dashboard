# Brand Profile: Acure

```yaml
brand_id: acure
name: Acure
marketplaces: [CA]
category: hair & skin care — vegan, clean-ingredient
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B003Z4UKGM | Acure Brightening Cleansing Gel - Vegan Face Scrub, Gentle Facial Cleanser for Radiant ... | Yes |
| B003Z4OD24 | Acure Brightening Facial Scrub, Exfoliating Face Wash, Gentle Daily Scrubber & Exfoliat... | Yes |
| B003Z4QGRE | Acure Brightening Night Cream - Radiance Boosting Night Face Cream for Women & Men, Hyd... |  |
| B01KU49HEA | ACURE The Essentials Moroccan Argan Oil / 100% Vegan / Versatile - for Any Skin & Hair ... | Yes |
| B01IKK31UC | Acure Dry Shampoo - Mini Powder Dry Shampoo for Women with Brunette & Dark Hair, Care t... | Yes |
| B004DTQ9L8 | ACURE The Essentials Moroccan Argan Oil / 100% Vegan / Versatile - for Any Skin & Hair ... |  |
| B082G1C4BZ | Acure Ultra Hydrating 12 Hour Facial Cream - Intense Face Moisturizer for Women & Men, ... |  |
| B0FSTJ4KFP | Acure The Essentials Argan Oil - Organic Argan Oil for Hair & Skin, Pure Renewing Moist... |  |
| B0CMZ58SMT | Acure Bonding Hair Mask - Weekly Deep Conditioning Hair Mask for Damaged Locks, Rescue ... |  |
| B0CMZ1G5F9 | Acure Bonding Hair Serum - Leave In Hair Oil for Damaged and Frizzy Hair, Treatment for... |  |
| B0FSVVRJ9L | Acure Bonding Hair Serum - Leave In Hair Oil for Damaged and Frizzy Hair, Treatment for... |  |
| B0FSTKZ85S | Acure Bonding Leave-In Conditioner - Leave in Conditioner Spray for Women & Men, Moistu... |  |
| B09MYC86PG | Acure Brightening Day & Night Cream Set - Daily Cica Cream & Night Face Cream for Women... | Yes |
| B003Z4QHP0 | Acure Brightening Day Cream - Cica Cream, Anti Aging Moisturizer to Brighten for Women ... | Yes |
| B09L5GGN1Z | Acure Brightening Facial Scrub - Exfoliating Face Wash, Gentle Daily Scrubber & Exfolia... | Yes |
| B00H4H9RRE | Acure Curiously Clarifying Conditioner - Hair Conditioner for Women & Men with Oily Hai... |  |
| B0DY8RRY91 | Acure Curiously Clarifying Conditioner & Argan Gently Cleanses, Removes Buildup, Boost ... |  |
| B0DZDCG1FT | Acure Curiously Clarifying Shampoo and Conditioner Set - Daily Deep Cleansing & Hydrati... | Yes |
| B082G1Z6HH | Acure Daily Workout Watermelon Conditioner - Lightweight Hydrating & Moisturizing Condi... |  |
| B0FSX8ZSRY | Acure Daily Workout Watermelon Shampoo & Conditioner - Lightweight Hydrating & Clarifyi... | Yes |
| B0071HIE94 | Acure Dry Shampoo - Mini Powder Dry Shampoo for Women with Blonde & Dark Hair, Care to ... | Yes |
| B0DZDCMD6N | Acure Dry Shampoo - Mini Powder Dry Shampoo for Women with Blonde & Dark Hair, Care to ... | Yes |
| B071XVDZ1D | Acure Dry Shampoo - Mini Powder Dry Shampoo for Women with Brunette & Dark Hair, Care t... | Yes |
| B082G1XYRB | Acure Ultra Hydrating Green Juice Face Cleanser - Superfood Cleanser, Green Face Wash f... | Yes |
| B0FSTHT5RD | Acure Ultra Hydrating Green Juice Face Cleanser - Superfood Cleanser, Face Wash for Wom... |  |
| B082YG2VT1 | Acure Ultra Hydrating Conditioner - Deep Moisture Conditioner for Women & Men with Dry,... | Yes |
| B0CMZC4GY3 | Acure Bonding Leave-In Conditioner - Leave in Conditioner Spray for Women & Men, Moistu... |  |
| B003Z4MCJA | Acure Radically Rejuvenating Eye Cream - Under Eye Cream for Dark Circles & Wrinkles, F... |  |
| B082G1SBGX | Acure Resurfacing 1% Glycolic Acid & Unicorn Root Cleanser - Exfoliating Face Wash, Gly... |  |
| B0FSTLNKXY | Acure Resurfacing 1% Glycolic Acid & Unicorn Root Cleanser - Exfoliating Face Wash, Gly... |  |
| B0DZDDZ3SW | Acure Simply Smoothing Shampoo and Conditioner Set - Hydrating & Moisturizing for Women... | Yes |
| B082YG5X38 | Acure Simply Smoothing Shampoo - Hydrating Anti Frizz Shampoo for Women & Men, Moisturi... | Yes |
| B082YG4LNC | Acure Simply Smoothing Conditioner - Hydrating & Moisturizing Conditioner for Women & M... |  |
| B00B4C35IW | Acure Seriously Soothing Cleansing Cream - Gentle Hydrating & Exfoliating Face Wash, Da... | Yes |
| B00BTYPW5E | Acure Soothing Day Cream - Moisturizer for Dry Sensitive Skin, Hydrating & Soothing Fac... | Yes |
| B078ZHPLNR | Acure Ultra Hydrating Shampoo - Moisturizing Shampoo for Women & Men, Moisturize & Soft... | Yes |
| B0DZDDDJ4Z | Acure Vivacious Volume Shampoo and Conditioner Set - Thickening & Volumizing Hair Care ... | Yes |
| B082YGK39W | Acure Vivacious Volume Shampoo - Volumizing Shampoo for Fine Thin Hair, Add Body and Th... | Yes |
| B082YG2VT8 | Acure Vivacious Volume Conditioner - Volumizing Conditioner for Women & Men, Lightweigh... |  |
| B07NJ4H5S3 | Acure Radically Rejuvenating Whipped Night Cream - Anti Aging Peptide Night Face Cream ... | Yes |
| B0GSSFNDNL | Acure Brightening Body Scrub - Exfoliating Body Scrub with Sea Salt, Scrubber for Men &... |  |
| B0DHJD7FYM | Acure Zombie Cell Clarifying Serum - Rejuvenate Face Serum with Niacinaminde & Milk Thi... |  |
| B0GR1QQK8B | Acure Radically Rejuvenating Rose Argan Oil - Face, Hair & Body Oil Serum Rich in Vitam... |  |
| B0GR1SVFJ7 | Acure Bonding Hair Mask - Weekly Deep Conditioning Hair Mask for Damaged Locks, Rescue ... |  |
| B0GR1VW2H4 | Acure Bonding Hair Serum - Leave In Hair Oil for Damaged and Frizzy Hair, Treatment for... |  |
| B0GR2471JR | Acure Simply Smoothing Shampoo and Conditioner, Hydrating & Moisturizing for Women & Me... |  |
| B0GR3QLN62 | Acure Bonding Leave-In Conditioner - Leave in Conditioner Spray for Women & Men, Moistu... |  |
| B0GR6ZW4MM | Acure Brightening Day & Night Cream, Daily Cica Cream & Night Face Cream for Women & Me... |  |
| B0GR7CTHSM | Acure Daily Workout Watermelon Shampoo & Conditioner - Lightweight Hydrating & Clarifyi... |  |
| B0GRK2X3HB | Acure Dry Shampoo - Mini Powder Dry Shampoo for Women with Blonde & Dark Hair, Care to ... |  |
| B0GRK7DPY1 | Acure Dry Shampoo - Mini Powder Dry Shampoo for Women with Brunette & Dark Hair, Care t... |  |
| B082YH2CD8 | Acure Curiously Clarifying Conditioner - Hair Conditioner for Women & Men with Oily Hai... |  |
| B0GS49LYNS | Acure Curiously Clarifying Conditioner & Argan Gently Cleanses, Removes Buildup, Boost ... |  |
| B0040ZHUH2 | Acure Brightening Glowing Serum - 100% Vegan, Brighter Skin Appearance, Argan Oil, Pump... |  |
| B082YGKB59 | Acure Brightening Body Scrub - Exfoliating Body Scrub with Sea Salt, Scrubber for Men &... |  |
| B082YFMNTK | Acure Radically Rejuvenating Dual Phase Bakuchiol Serum - Bakuchiol Oil Serum for Face,... |  |
| B082G1VNQ6 | Acure Daily Brightening Vitamin C Serum with Ferulic Acid - Brightening Face Serum for ... |  |
| B0DHJH8534 | Acure Zombie Cell Clarifying Mask - Detoxifying Face Mask with Niacinamide, Pore Minimi... |  |
| B0GR1NVK6Q | Acure Resurfacing 1% Glycolic Acid & Unicorn Root Cleanser - Exfoliating Face Wash, Gly... |  |
| B0GR1KZ3FY | Acure Ultra Hydrating Green Juice Face Cleanser - Superfood Cleanser, Green Face Wash f... |  |
| B0GQXK7D5W | Acure Brightening Facial Scrub, Exfoliating Face Wash, Gentle Daily Scrubber & Exfoliat... |  |
| B082G1C4BV | Acure Daily Workout Watermelon Shampoo - Lightweight Hydrating & Clarifying Shampoo for... | Yes |
| B082YFN2ZK | Acure Curiously Clarifying Shampoo - Cleansing & Clarifying Shampoo for Women & Men, Sc... |  |
| B0GX2S2XBZ | Acure Curiously Clarifying Shampoo and Conditioner, Daily Deep Cleansing & Hydrating Se... |  |
| B0FSWHQ91F | Acure Brightening Body Scrub - Exfoliating Body Scrub with Sea Salt, Scrubber for Men &... |  |
| B0FST7XZCK | (no title on file) |  |
| B0B33W89KK | (no title on file) |  |

_Last synced: 2026-07-30 (67 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

Mostly women, 20–55. They want a premium product at an affordable price and they read ingredient panels — clean ingredients matter. Positioning: entry-premium ("masstige") — the lower end of premium, the higher end of affordable. Not drugstore-cheap, not luxury.

## Voice & tone

Clean, modern, simple — clinical with a splash of fun.
Fits: "Vegan. Sulfate-free. That simple." / short, ingredient-forward, confident lines with an occasional wink.
Does not fit: hype ("miracle", "game-changing"), luxury-speak, cutesy filler, or medical/treatment tone (see Claims).

## Claims — approved

**Apply each claim only where that specific product's label/current listing carries it — never transplant across products.**

| Claim | Substantiation |
|---|---|
| Vegan / 100% Vegan | label / current listing |
| Cruelty-free | label / current listing |
| Sulfate-free | label / current listing |
| Paraben-free | label / current listing |
| Organic <ingredient> (e.g. organic argan oil) | label / current listing — ingredient-level only, not "organic product" |
| Dermatologist-tested | only where the current listing states it |

## Claims — banned

- Any disease or illness claim, including soft "supports" forms — no treating, curing, preventing, or supporting anything related to a medical condition (acne treatment, eczema relief, hair-loss prevention, "repairs skin barrier", etc.). Cosmetic benefit wording only.
- Any claim not in the table above or the product's current listing.

## Keywords

<!-- AUTO:KEYWORDS START — data columns refresh weekly from Data Dive; Tier override + Notes are yours and survive every refresh -->
| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| acure | 1145 | 0.15 | 1 (B003Z4OD24) | Defend |  |  |
| gommage eclaicissant visage | 250 |  | 1 (B003Z4OD24) | Defend |  |  |
| face scrub acure brightening facial scrub | 250 |  | 1 (B003Z4OD24) | Defend |  |  |
| gommage eclairssisant visage | 250 |  | 1 (B003Z4OD24) | Defend |  |  |
| facial scrub natural ingredients | 250 |  | 1 (B003Z4OD24) | Defend |  |  |
| acure brightening facial scrub | 250 | 0.38 | 1 (B003Z4OD24) | Defend |  |  |
| natural exfoliating face wash | 250 |  | 1 (B003Z4OD24) | Defend |  |  |
| brightening facial scrub | 250 |  | 1 (B003Z4OD24) | Defend |  |  |
| gommage visage eclaircissant | 250 |  | 1 (B003Z4OD24) | Defend |  |  |
| face brightening exfoliant | 250 |  | 1 (B003Z4OD24) | Defend |  |  |
| acure shampoo | 645 | 0.21 | 1 (B082YGK39W) | Defend |  |  |
| detox hair shampoo and conditioner set | 250 |  | 1 (B082YFN2ZK) | Defend |  |  |
| cleansing shampoo and conditioner | 250 |  | 1 (B082YFN2ZK) | Defend |  |  |
| ultra hydrating shampoo | 250 |  | 1 (B078ZHPLNR) | Defend |  |  |
| face brighening wash | 250 |  | 2 (B003Z4UKGM) | Defend |  |  |
| face cleaning exfoliating | 250 |  | 2 (B003Z4OD24) | Defend |  |  |
| cruelty free exfoliating face cleanser | 250 |  | 2 (B003Z4OD24) | Defend |  |  |
| exfoliant natural visage | 250 |  | 2 (B003Z4OD24) | Defend |  |  |
| face brightening scrub | 250 |  | 2 (B003Z4OD24) | Defend |  |  |
| face scrub brightening | 250 |  | 2 (B003Z4OD24) | Defend |  |  |
| natural face scrub | 250 |  | 2 (B003Z4OD24) | Defend |  |  |
| acure dry shampoo | 250 | 0.57 | 2 (B0071HIE94) | Defend |  |  |
| deep clarifying shampoo and conditioner | 250 |  | 2 (B082YFN2ZK) | Defend |  |  |
| hair bonding serum | 250 |  | 2 (B0CMZ1G5F9) | Defend |  |  |
| rejuvenate face serum | 250 | 0.19 | 2 (B0DHJD7FYM) | Defend |  |  |
| face scrub exfoliator | 250 | 0.62 | 3 (B003Z4OD24) | Defend |  |  |
| exfoliating face cleanser for women | 250 |  | 3 (B003Z4OD24) | Defend |  |  |
| skin brigheting scrub | 250 |  | 3 (B003Z4OD24) | Defend |  |  |
| glycolic acid cleanser | 250 | 0.4 | 3 (B082G1SBGX) | Defend |  |  |
| crème eclaircissante visage nuit | 250 |  | 3 (B003Z4QGRE) | Defend |  |  |
| facial wash brightening oily skin | 250 |  | 4 (B003Z4UKGM) | Defend |  |  |
| brightening face wash for women | 250 |  | 4 (B003Z4OD24) | Defend |  |  |
| dry shampoo powder colour safe | 250 |  | 4 (B0071HIE94) | Defend |  |  |
| glycolic acid face wash | 538 | 0.4 | 4 (B082G1SBGX) | Defend |  |  |
| ultra moisture shampoo | 250 |  | 4 (B078ZHPLNR) | Defend |  |  |
| natural facial scrub | 250 |  | 5 (B003Z4OD24) | Defend |  |  |
| natural face exfoliator scrub | 250 |  | 5 (B003Z4OD24) | Defend |  |  |
| natural face scrub women | 250 |  | 5 (B003Z4OD24) | Defend |  |  |
| watermelon shampoo | 250 |  | 5 (B082G1C4BV) | Defend |  |  |
| brightening body scrub | 250 |  | 5 (B082YGKB59) | Defend |  |  |
| face exfoliator scrub | 961 | 0.54 | 6 (B003Z4OD24) | Strike zone |  |  |
| face exfoliator scrub natural | 250 |  | 6 (B003Z4OD24) | Strike zone |  |  |
| face cleanser for women scrub | 250 |  | 6 (B003Z4OD24) | Strike zone |  |  |
| brightening exfoliating face wash | 250 |  | 6 (B003Z4OD24) | Strike zone |  |  |
| clarifying shampoo and conditioner | 756 | 0.42 | 6 (B082YFN2ZK) | Strike zone |  |  |
| shampoo and conditioner for oily hair | 250 |  | 6 (B082YFN2ZK) | Strike zone |  |  |
| body scrub brightening | 250 |  | 6 (B082YGKB59) | Strike zone |  |  |
| revitalisant hydratant cheveux fin | 250 |  | 6 (B082YG2VT1) | Strike zone |  |  |
| shampoo and conditioner set clarifying | 250 |  | 7 (B082YFN2ZK) | Strike zone |  |  |
| clarifying shampoo and conditioner set | 250 |  | 7 (B082YFN2ZK) | Strike zone |  |  |
| face scrub | 14363 | 0.54 | 8 (B003Z4OD24) | Strike zone |  |  |
| facial scrub exfoliator | 1052 | 0.69 | 8 (B003Z4OD24) | Strike zone |  |  |
| gommage visage | 820 | 0.54 | 8 (B003Z4OD24) | Strike zone |  |  |
| exfoliant visage femme | 602 | 0.62 | 8 (B003Z4OD24) | Strike zone |  |  |
| scrub face | 576 | 0.62 | 8 (B003Z4OD24) | Strike zone |  |  |
| facescrub | 250 |  | 8 (B003Z4OD24) | Strike zone |  |  |
| glycolic acid face cleanser | 250 |  | 8 (B082G1SBGX) | Strike zone |  |  |
| exfoliating face scrub | 2023 | 0.54 | 9 (B003Z4OD24) | Strike zone |  |  |
| face scrub women | 1730 | 0.62 | 9 (B003Z4OD24) | Strike zone |  |  |
| brightening face cleanser | 250 |  | 9 (B003Z4OD24) | Strike zone |  |  |
| exfoliant visage gommage | 250 |  | 9 (B003Z4OD24) | Strike zone |  |  |
| brightening face wash men | 250 |  | 9 (B003Z4OD24) | Strike zone |  |  |
| shampoo and conditioner clarifying | 250 |  | 9 (B082YFN2ZK) | Strike zone |  |  |
| volume shampoo and conditioner for fine hair | 250 |  | 9 (B082YGK39W) | Strike zone |  |  |
| mens facial exfoliator | 250 |  | 10 (B003Z4OD24) | Strike zone |  |  |
| natural dry shampoo powder | 250 |  | 10 (B0071HIE94) | Strike zone |  |  |
| bonding hair mask | 250 |  | 10 (B0CMZ58SMT) | Strike zone |  |  |
| face exfoliator | 6342 | 0.38 | 11 (B003Z4OD24) | Strike zone |  |  |
| exfoliant scrub for face | 250 |  | 11 (B003Z4OD24) | Strike zone |  |  |
| facial exfoliant scrub | 250 |  | 11 (B003Z4OD24) | Strike zone |  |  |
| crème eclaircissant visage nuit | 250 |  | 11 (B003Z4QGRE) | Strike zone |  |  |
| bakuchiol serum for face | 250 |  | 11 (B082YFMNTK) | Strike zone |  |  |
| exfoliator face | 250 |  | 12 (B003Z4OD24) | Strike zone |  |  |
| microdermabrasion scrub | 250 | 0.54 | 12 (B003Z4OD24) | Strike zone |  |  |
| shampoing volume femme | 250 |  | 12 (B082YGK39W) | Strike zone |  |  |
| hair bonding mask | 250 |  | 12 (B0CMZ58SMT) | Strike zone |  |  |
| bakuchiol face serum | 250 |  | 12 (B082YFMNTK) | Strike zone |  |  |
| brightening face wash | 982 | 0.31 | 13 (B003Z4OD24) | Strike zone |  |  |
| top rated exfoliating face scrub | 250 |  | 13 (B003Z4OD24) | Strike zone |  |  |
| face brightening cream for men | 250 |  | 13 (B003Z4QHP0) | Strike zone |  |  |
| rejuvenating cream | 250 |  | 13 (B07NJ4H5S3) | Strike zone |  |  |
| facial cleanser scrub | 250 |  | 14 (B003Z4OD24) | Strike zone |  |  |
| shampoo and conditioner set for oily scalp | 250 |  | 14 (B082YFN2ZK) | Strike zone |  |  |
| detox shampoo and conditioner for curly hair | 250 |  | 14 (B082YFN2ZK) | Strike zone |  |  |
| ravitalisant cheveux ultra hydratant | 250 |  | 14 (B082YG2VT1) | Strike zone |  |  |
| natural hydrating conditioner | 250 |  | 14 (B082YG2VT1) | Strike zone |  |  |
| gentle exfoliating face wash | 250 | 0.31 | 15 (B003Z4OD24) | Strike zone |  |  |
| detox shampoo and conditioner curly hair | 250 |  | 15 (B082YFN2ZK) | Strike zone |  |  |
| detox shampoo and conditioner | 250 |  | 15 (B082YFN2ZK) | Strike zone |  |  |
| bakuchiol serum | 1594 | 0.74 | 15 (B082YFMNTK) | Strike zone |  |  |
| facial scrub | 2655 | 0.46 | 16 (B003Z4OD24) | Strike zone |  |  |
| face scrub men brightning | 250 |  | 16 (B003Z4UKGM) | Strike zone |  |  |
| exfoliant facial | 250 |  | 16 (B003Z4OD24) | Strike zone |  |  |
| powder dry shampoo blonde | 250 |  | 16 (B0071HIE94) | Strike zone |  |  |
| clean shampoo and conditioner | 250 |  | 16 (B082YFN2ZK) | Strike zone |  |  |
| brightening exfoliating body scrub | 250 |  | 16 (B082YGKB59) | Strike zone |  |  |
| face brightening cream for women | 250 |  | 16 (B003Z4QHP0) | Strike zone |  |  |
| facial scrub mens | 250 |  | 17 (B003Z4OD24) | Strike zone |  |  |
| powder dry shampoo | 1505 | 0.64 | 17 (B0071HIE94) | Strike zone |  |  |
| brightening night cream | 250 |  | 17 (B003Z4QGRE) | Strike zone |  |  |
| exfoliant visage | 4445 | 0.38 | 18 (B003Z4OD24) | Strike zone |  |  |
| exfiliant visage | 250 |  | 18 (B003Z4OD24) | Strike zone |  |  |
| shampoing sec poudre | 250 |  | 18 (B0071HIE94) | Strike zone |  |  |
| travel dry shampoo powder | 250 |  | 18 (B0071HIE94) | Strike zone |  |  |
| organic dry shampoo | 250 |  | 18 (B0071HIE94) | Strike zone |  |  |
| volume shampoo and conditioner | 775 | 0.35 | 18 (B082YGK39W) | Strike zone |  |  |
| shampoo and conditioner volume | 250 |  | 18 (B082YGK39W) | Strike zone |  |  |
| natural hydrating shampoo | 250 |  | 18 (B078ZHPLNR) | Strike zone |  |  |
| facial exfoliant | 926 | 0.46 | 19 (B003Z4OD24) | Strike zone |  |  |
| facial exfoliator | 819 | 0.46 | 19 (B003Z4OD24) | Strike zone |  |  |
| scrub face wash | 250 |  | 19 (B003Z4OD24) | Strike zone |  |  |
| bakuchiol oil for face | 250 |  | 19 (B082YFMNTK) | Strike zone |  |  |
| exfoliant face | 1016 | 0.38 | 20 (B003Z4OD24) | Strike zone |  |  |
| face wash scrub | 250 |  | 20 (B003Z4OD24) | Strike zone |  |  |
| brightening night face cream | 250 |  | 20 (B003Z4QGRE) | Strike zone |  |  |
| clarifying conditioner | 250 | 0.57 | 20 (B082YH2CD8) | Strike zone |  |  |
| mens face scrub | 936 | 0.38 | 21 (B003Z4OD24) | Strike zone |  |  |
| shampoo and conditioner set for fine hair | 250 |  | 21 (B082YGK39W) | Strike zone |  |  |
| bakuchiol retinol serum | 250 | 0.79 | 21 (B082YFMNTK) | Strike zone |  |  |
| natural dry shampoo | 489 | 0.57 | 22 (B0071HIE94) | Strike zone |  |  |
| shampoing sec en poudre | 250 |  | 22 (B0071HIE94) | Strike zone |  |  |
| natural dry shampoo for dark hair | 250 |  | 22 (B0071HIE94) | Strike zone |  |  |
| powder dry shampoo for dark hair | 250 |  | 22 (B0071HIE94) | Strike zone |  |  |
| shampooing sec poudre naturel | 250 |  | 22 (B0071HIE94) | Strike zone |  |  |
| shampoo and conditioner set for oily hair | 250 |  | 22 (B082YFN2ZK) | Strike zone |  |  |
| face exfoliant | 2180 | 0.46 | 23 (B003Z4OD24) | Strike zone |  |  |
| face scrub men | 1276 | 0.38 | 23 (B003Z4OD24) | Strike zone |  |  |
| dry shampoo natural | 250 |  | 23 (B0071HIE94) | Strike zone |  |  |
| shampoo and conditioner set oily hair | 250 |  | 23 (B082YFN2ZK) | Strike zone |  |  |
| facial wash exfoliating | 250 |  | 24 (B003Z4OD24) | Strike zone |  |  |
| dry shampoo non aerosol | 679 | 0.57 | 24 (B0071HIE94) | Strike zone |  |  |
| dry shampoo powder for women | 250 |  | 24 (B0071HIE94) | Strike zone |  |  |
| dark hair dry shampoo powder | 250 |  | 24 (B0071HIE94) | Strike zone |  |  |
| face brightening night cream | 250 |  | 24 (B003Z4QGRE) | Strike zone |  |  |
| volumizing shampoo and conditioner | 250 |  | 24 (B082YGK39W) | Strike zone |  |  |
| dry shampoo non-aerosol | 250 |  | 25 (B0071HIE94) | Strike zone |  |  |
| dry shampoo powder brown hair | 250 |  | 25 (B0071HIE94) | Strike zone |  |  |
| volumizing hair conditioner | 250 |  | 25 (B082YG2VT8) | Strike zone |  |  |
| superfood cleanser | 250 | 0.23 | 25 (B082G1XYRB) | Strike zone |  |  |
| vegan shampoo | 250 | 0.26 | 25 (B082YGK39W) | Strike zone |  |  |
| dry shampoo powder dark hair | 250 | 0.71 | 26 (B0071HIE94) | Strike zone |  |  |
| powder dry shampoo dark hair | 250 |  | 26 (B0071HIE94) | Strike zone |  |  |
| shampooing sec poudre | 250 |  | 26 (B0071HIE94) | Strike zone |  |  |
| smoothing shampoo and conditioner | 250 |  | 26 (B082YG5X38) | Strike zone |  |  |
| gommage eclaircissant pour le corps | 250 |  | 26 (B082YGKB59) | Strike zone |  |  |
| exfoliating face wash | 8886 | 0.31 | 27 (B003Z4OD24) | Strike zone |  |  |
| dry shampoo powder | 7318 | 0.64 | 27 (B0071HIE94) | Strike zone |  |  |
| non aerosol dry shampoo | 741 | 0.64 | 27 (B0071HIE94) | Strike zone |  |  |
| powdered dry shampoo | 250 |  | 27 (B0071HIE94) | Strike zone |  |  |
| dry shampoo powder brunette | 250 |  | 27 (B0071HIE94) | Strike zone |  |  |
| dry shampoo non aerosol dark | 250 |  | 27 (B0071HIE94) | Strike zone |  |  |
| shampoo and conditioner set thin hair | 250 |  | 27 (B082YGK39W) | Strike zone |  |  |
| dry shampoo powder for dark hair | 250 |  | 28 (B0071HIE94) | Strike zone |  |  |
| travel size dry shampoo | 744 | 0.64 | 30 (B0071HIE94) | Strike zone |  |  |
| brunette dry shampoo powder | 250 |  | 30 (B0071HIE94) | Strike zone |  |  |
| dry shampoo mini | 250 | 0.57 | 30 (B0071HIE94) | Strike zone |  |  |
| shampoo and conditioner for fine thin hair | 250 |  | 30 (B082YGK39W) | Strike zone |  |  |

_Synced 2026-07-30 from dashboard Data Dive snapshots. Rank = best across tracked ASINs (shown in brackets). Rank ≤30 keywords always listed; the rest are top-volume._
<!-- AUTO:KEYWORDS END -->

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

**Attitude, Live Clean, OGX** — target these (product targeting + their brand terms are fair game). Shoppers cross-shop the clean/affordable hair & skin space; position Acure as the ingredient-honest step up.

## Notes

- **Promotions:** light schedule from the brand — plan for roughly one promotion every two months.
- **Subscribe & Save:** a large and growing part of the strategy — increasing focus; favour S&S enrollment and repeat-purchase framing in audits and recommendations.
- **New launches:** continual — roughly one new product per month. Expect new ASINs regularly; launch support (listing-copy + ppc-campaign-builder) is a recurring need, not an exception.
