# Brand Dashboard Access

The RMC brand dashboard holds daily ASIN-level data: units, revenue (CAD/USD), sessions, page views, Buy Box %, ad spend/clicks/impressions/attributed sales, refunds, inventory.

- Hosted: `https://app.rockymountainco.ca` (HTTP Basic Auth — get credentials from Mike; never commit or paste them into saved files). Old URL `https://rmc-brand-dashboard-1.onrender.com` still works.
- Key endpoints (GET, JSON): `/api/brands?preset=7d|14d|30d|thisMonth|lastMonth` (all brands + ad summaries), `/api/report-data/:brandId`, `/api/report-ads/:brandId`, `/api/brand-report-dataset/:brandId`
- PPC endpoints: `/api/ads/search-terms?brand=<id>&profile=CA|US` (rolling 30d clicked search terms with campaign/ad-group/keyword context, refreshed Mondays), `/api/ads/campaigns?brand=<id>&profile=CA|US` (campaign structure snapshot: budgets, states, targeting type, ASINs, keyword/negative counts; add `&full=1` for full keywords/targets/negatives detail — large)
- Data Dive endpoint: `/api/datadive/:brandId` — ORGANIC keyword data only: per-keyword current rank, 30d-ago rank, trend, search volume, relevancy, SQP where present (compact by default; `?full=1` for daily histories). Refreshed Mondays.
- Listing content endpoint: `/api/listing-content/:brandId` (`?asin=` for one listing with full description) — per-ASIN variant relationships (parent + variation theme), structured attributes (flavour/size/count), image count, bullets, description, **backend search terms (seller-private — never in client-facing output)**, listing status + suppression issues. Refreshed Mondays. Use this instead of asking anyone to paste from Seller Central.
**Source policy (Mike, 2026-07-21): advertising metrics come ONLY from the Amazon-direct endpoints above (spend, clicks, ACOS, search terms, campaigns). Data Dive supplies organic data only — if any Data Dive payload ever shows ad-looking numbers, ignore them.**

## How skills use it

**Claude Code:** call the API directly, e.g. `curl -u <user>:<pass> "https://app.rockymountainco.ca/api/brands?preset=30d"`. Ask the user for credentials once per session if not already provided; do not store them.

**claude.ai chat — RMC Dashboard connector first:** if the "RMC Brand Dashboard" connector is available in the chat (check your tools), use it — it is the same data as the API: `list_brands`, `get_brand_report` (report-data + ads + orders + inventory in one call, custom from/to), `get_ads_campaigns`, `get_search_terms`, `get_datadive`, `get_listing_content`, `get_listing_health`. No pasting needed.

**claude.ai chat without the connector:** ask the user to export the data instead — open the dashboard, use the brand report page or copy the relevant table/JSON, and paste it into the chat. Skills must accept pasted data as a first-class input.

**Data-freshness rule:** always state the preset/date range and pull time alongside any number quoted from the dashboard. Units/revenue are authoritative from the Orders API (matches Sellerboard).

## Ad data: what's covered, and the attribution window

- **ASIN-level ad data = Sponsored Products (CA + US profiles).** Sponsored Brands + Sponsored Display are tracked **brand-level** since Jun 2026 (Amazon doesn't attribute them to ASINs), but are **not yet exposed via the API/connector** — until they are, the SB/SD-inclusive monthly numbers live in each brand's Master sheet "Ads (auto)" tab (ALL AD TYPES + TACOS block).
- **RMC attribution standard = 7-day** (decided 2026-08-13: "one number everywhere" — matches what the Ads console shows sellers). The dashboard stores both 7d and 14d; API/connector responses still return **14-day** until their migration ships. 14d reads 3–5% higher than 7d. **Always label which window a number uses**; never compare a 14d figure against a console/7d figure without saying so.
- **TACOS must use total ad spend (SP+SB+SD).** SP-only TACOS is understated (this caused a real 2026-08 discrepancy — Acure ~23% low). If only SP data is available, label it "TACOS (SP only — understated)".
