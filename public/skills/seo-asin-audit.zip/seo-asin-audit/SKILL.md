---
name: seo-asin-audit
description: Audit a single ASIN for SEO richness — whether every piece of copy real estate (title, Item Highlights, bullets, description, backend keywords) works the highest-value keywords given current organic ranks, volume, relevancy, and the brand's targets. Returns a 0-100 SEO score, a keyword-to-placement efficiency map, and a ranked gap list. Use for "SEO audit this ASIN", "is this listing optimized", or "keyword efficiency check".
---

# /seo-asin-audit [ASIN] [brand-id if known]

Scores how efficiently an ASIN's copy uses its keyword opportunity. This skill audits — it never writes copy. Rewrites route to `/listing-copy`, which inherits the same tier logic.

## Read first

1. `references/rmc-standards.md` and `references/dashboard-access.md` (in this skill folder on claude.ai; at `../../references/` in the repo).
2. The brand profile in `references/brand-profiles/<brand-id>.md` — its keyword table (the Tier override column beats any formula) and its Targets section. No profile → say so and proceed with what's given.

## Inputs (gather before scoring)

1. **Keyword data — organic ONLY (Data Dive):**
   - Dashboard snapshots first: Claude Code `/api/datadive/:brandId`; claude.ai connector `get_datadive`. Gives rank now, rank 30d ago, trend, volume, relevancy, SQP/conversion share. Refreshed Mondays — always cite the snapshot date.
   - Data Dive MCP if connected (fresher, per-ASIN).
   - A Data Dive / Helium 10 CSV export as fallback.
   - No rank data → the audit is rank-blind: score only Utilization + Waste, label the output "rank-blind — rerun with Rank Radar data", and skip the tier sub-scores rather than guessing.
2. **Current listing copy:** title (the dashboard has it), Item Highlights, bullets, description — from the live listing if viewable, else ask the user to paste them.
3. **Backend search terms:** ask the user to paste them from Seller Central. They are never guessable — without them Index coverage scores "unknown" and drops out of the calculation; it is never scored as a failure.
4. Ask ONE consolidated question for everything missing. Don't drip-feed.

## Tier the keywords (same logic as /listing-copy)

Score = volume × relevancy × winnability, where winnability comes from current organic rank:

- **Defend (rank 1–5):** words that must live in the title, always.
- **Strike zone (rank 6–30):** indexed and winnable — the priority tier for title/Highlights/bullets 1–3 placement.
- **Index gaps (relevant, not indexed):** must appear literally somewhere (backend/description) to index at all.
- **Long shots (rank 31–100):** should NOT hold prime real estate; note them for PPC.
- **Conversion-share bonus:** keywords where the ASIN out-converts the market get one tier bump in placement priority.
- The profile keyword table's Tier override wins over all of the above. Cite the rank-data date — rank moves weekly.

## Score the placement — 0–100

| Sub-score | Weight | Full marks when |
|---|---|---|
| Defend coverage | 25 | every Defend keyword's words appear in the title |
| Strike placement | 25 | top Strike terms hold title / Item Highlights / bullets 1–3 in score order |
| Real-estate utilization | 20 | title 40–75 chars, Item Highlights present ≤125, five substantive bullets, description ~1,500+ chars, backend present ≤250 bytes |
| Index coverage | 15 | every index-gap keyword literally present in backend or description (scored only when backend terms were provided) |
| Waste | 15 | no word more than 2x in the title, no Long shots in prime slots, no backend bytes repeating words already visible, no title space on zero-volume words |

Conversion-share bonus: ±5 — bonus keywords in prime placement earn it; buried ones lose it.
When a sub-score's data is missing, remove its weight from the denominator and say so — missing data shrinks scope, never inflates the score.

**Verdict bands:** 85+ tuned — protect it; 70–84 minor gaps; 50–69 rework bullets/Highlights/backend; below 50 → route to `/listing-copy` for a full rewrite.

## Output — one page

1. **Verdict line:** score, band, and the single biggest inefficiency in one sentence.
2. **Keyword→placement map:** keyword | tier (+ override flag) | rank now vs 30d ago | volume | where it appears (title / HL / bullet # / description / backend / nowhere) | verdict (right place / wrong place / missing).
3. **Gap list, ranked by volume × winnability.** Each gap: the keyword, the evidence, and the exact move — "move X from bullet 4 into Item Highlights", "add Y to backend — indexed nowhere", "Z holds 12 title chars at zero volume — free the space".
4. **Defend risk callout:** the words no rewrite may ever drop, plus any Defend keyword slipping 5+ positions (pair with matching exact-match PPC pressure — route to `/ppc-campaign-builder`).
5. Save as `Outputs/YYYY-MM-DD_seo-asin-audit_<asin>.md` (Claude Code) or a downloadable file (claude.ai).

## Rules

- Audit only — never draft replacement copy here; that's `/listing-copy`.
- Data Dive is an ORGANIC source only. Any ads context comes from the dashboard's Amazon-direct endpoints, and this skill needs none by default.
- Every number cites its source and date. A stale rank date gets said out loud, not hidden.
- Respect the brand profile's Targets: if a target names an SEO/rank goal for this ASIN, judge against it explicitly.
- Missing inputs shrink scope, not confidence: score what you can, list what you couldn't check.

## Self-check before delivering

- [ ] Every sub-score traces to rows visible in the keyword→placement map
- [ ] Every gap has an exact placement move, not advice
- [ ] Rank-data date cited; tier overrides honored; nothing scored on missing data
