---
name: ppc-report
description: Generate May's recurring PPC performance workbook — fresh ad KPIs in her exact Excel format, for her bid/budget decisions and for reporting to the team. Use for "PPC report", "weekly ad numbers", "generate the ads workbook", or any request for ad KPIs in Excel.
---

# /ppc-report [brand or ALL] [period, default: last full week]

Fills May's PPC reporting workbook with fresh numbers. It never invents a layout — it reproduces the saved RMC format exactly, every run.

## You provide → you get

| You provide | You get |
|---|---|
| Brand (or ALL) + period | One `.xlsx` in the saved RMC report format — same tabs, same columns, same order — filled with that period's data, named `YYYY-MM-DD_ppc-report_<brand>.xlsx` |
| Nothing else (Claude Code) | Data pulls automatically from the dashboard |
| Pasted/exported data (claude.ai chat) | The skill tells you exactly which two exports to paste, then builds the same file |

Plus a 5-line summary in chat: spend, sales, ACOS vs prior period, and the one number that most needs May's attention.

## First run only — format capture

The saved format lives in `references/ppc-report-format.md`. If it still says NOT YET CAPTURED:
1. Ask May to upload her current PPC report workbook (.xlsx).
2. Mirror its structure exactly — every tab, column, header, and order — and produce this run's report in that structure.
3. Emit a **format spec** (tab names → column names → what fills each) and tell her: "Send this spec to Mike so it's baked into the skill — after that, no workbook upload needed again."
Never redesign her format. If a column can't be filled from available data, keep the column and mark cells `N/A (source: —)` — don't drop it.

## Data (per run)

- **Claude Code:** dashboard API per `references/dashboard-access.md` — daily ASIN-level spend/sales/clicks/impressions/orders for the period + prior period, and `/api/ads/campaigns?brand=` for campaign names/budgets.
- **claude.ai:** use the RMC Dashboard connector if available (`get_brand_report` per period; `get_ads_campaigns` if the format has campaign-level tabs). Otherwise ask for (1) the brand's dashboard report data for the period, (2) a campaign export. List exactly what's missing if data is partial — never fill gaps with estimates.
- Compute derived columns (ACOS, ROAS, CPC, CTR, CVR) from raw numbers; round money to 2dp, rates to 2dp percent.

## Output rules

- Same file every time: identical tabs/columns to the saved format. Consistency is the point — May and the team read this at a glance.
- Every tab carries the period and pull date in a header cell. CA and USD figures stay separate, never mixed.
- Prior-period comparison columns fill wherever the format has them; attribution caveat noted on any period ending within 3 days of today.
- **Internal document:** may contain spend and efficiency data; still no margin/COGS/profit unless the saved format explicitly has those columns (it's team-internal, that's allowed — but never forward to a brand).
- Claude Code: save to `Outputs/reports/`. claude.ai: downloadable file in chat.

## Self-check

- [ ] Structure byte-for-byte matches the saved format (or captured workbook)
- [ ] Period + pull date stamped; currencies not mixed
- [ ] No invented numbers; gaps marked N/A with the missing source named
- [ ] Chat summary ≤5 lines with one clear callout
