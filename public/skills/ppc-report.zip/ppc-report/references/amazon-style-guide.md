# Amazon Listing Style Guide (RMC)

Last reviewed: 2026-07-14. Marketplaces: Amazon.com + Amazon.ca. Verify anything category-specific against the category style guide in Seller Central before publishing.

## ⚠ Title policy change — effective July 27, 2026

Amazon caps titles at **75 characters (including spaces)** in all categories except media. Titles over the cap will be gradually replaced with Amazon's AI-generated rewrite; brand owners get a **14-day review window** in Seller Central → Review Listings Changes before a rewrite goes live. Write all new titles to the 75-char standard now; move overflow keywords to Item Highlights and backend search terms.

## Titles (≤75 characters)

Formula: `Brand + Product Type + 1–2 strongest differentiators + Size/Count`

- Every character earns its place: lead with what shoppers search, cut filler.
- No promotional language ("sale", "free shipping", "best", "#1", "hot").
- No special characters `! $ ? _ { } ^ ¬ ¦` unless part of the brand name. `~ # < > *` only for style numbers or measurements.
- Don't repeat a word more than twice (articles/prepositions exempt). Ideally never repeat.
- Title Case, not ALL CAPS. Numerals ("2" not "two"). No seller name, no ASIN.

## Item Highlights (≤125 characters)

New searchable field shown with the title in search results and on the detail page. Use it for what no longer fits in the title: materials, key use cases, secondary keywords. Treat it as ranked keyword real estate, not a slogan.

## Bullet points (5)

- Order: 1) core benefit/outcome, 2) key differentiator, 3) how it works / ingredients-materials, 4) use case / who it's for, 5) trust (guarantee-free trust: certifications, origin, compatibility).
- Structure: `BENEFIT HOOK (2–4 words): supporting detail with specifics.` Front-load keywords in the first three bullets.
- ~150–200 characters each. Start with a capital, write fragments, no ending period.
- Banned: pricing/promos, shipping info, seller/company story, "100% satisfaction guaranteed"-type claims, emojis, decorative symbols (✓ ★ →), ALL-CAPS words except acronyms.

## Product description / A+

A+ content replaces the description on the detail page, but the description field is still indexed — always fill it (~1,500–2,000 chars, plain paragraphs, keywords woven in naturally, no HTML except line breaks).

## Backend search terms (generic keywords)

- **≤250 bytes** total (accented characters count extra). Space-separated, no commas, no quotes.
- Do NOT include: competitor brand names, your own brand, ASINs, words already in title/bullets, subjective claims ("best"), temporary words ("new", "sale"), profanity.
- Singular or plural, not both. Include common synonyms, regional terms (e.g., US vs CA spellings), and category jargon.

## Health & wellness claims (RMC's core vertical)

- **Never** disease claims: treat, cure, prevent, heal, diagnose, or naming diseases ("fights arthritis"). Applies to copy, keywords, and A+.
- Structure/function framing only: "supports joint health" not "relieves joint pain".
- "Clinically proven", "doctor recommended", specific percentages → only if the brand profile lists them as approved with substantiation on file.
- Amazon.ca: natural health products need a Health Canada NPN; claims must match the licensed claims. Stricter than US — when in doubt, use the CA-safe version in both marketplaces.
- Any claim not in the brand profile's approved list → flag as "needs substantiation", don't use it.

## Images (reference only — creative work is out of scope for now)

Main: pure white background (RGB 255,255,255), product fills ≥85% of frame, no text/logos/props/watermarks. Target 7 images + video. Detail work goes to the asset project when it's picked back up.

---
Sources: Amazon title policy update effective 2026-07-27 (Seller Central announcement; 75-char cap, media exempt, Item Highlights 125 chars, 14-day Review Listings Changes window); Amazon title requirements 2025-01-21 (special characters, word repetition); Amazon search terms best practices (250-byte limit).
