# Brand Profile: <Brand Name>

<!-- Copy to <brand-id>.md. brand_id must match the id in the brand dashboard. -->

```yaml
brand_id:        # dashboard id, e.g. "acme-naturals"
name:
marketplaces: [CA, US]
category:        # e.g. supplements, personal care, grocery
```

## ASINs

| ASIN | Product | Marketplace | Notes |
|---|---|---|---|
| | | | |

## Audience

Who buys this and why (1–3 sentences). Primary use cases. Price position vs competitors (premium/mid/value).

## Voice & tone

How this brand sounds (e.g., "clinical and precise", "warm, plain-spoken"). 2–3 example phrases that fit; 2–3 that don't.

## Claims — approved

Only these may appear in copy. Include substantiation source per claim (NPN #, study, certification).

| Claim | Substantiation |
|---|---|
| | |

## Claims — banned

Anything the brand or regulators prohibit, plus known past compliance issues.

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC's call). Override column is the BM/specialist's call and beats the formula.
Source: Data Dive link / Rank Radar export date: …

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN's own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

| Brand | ASIN | Why they win / lose |
|---|---|---|
| | | |

## Notes

Promos calendar, S&S status, known catalog quirks (parent/child structure, duplicate ASIN history), anything a new specialist should know.
