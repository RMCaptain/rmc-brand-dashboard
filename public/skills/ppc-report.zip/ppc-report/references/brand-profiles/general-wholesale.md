# Brand Profile: General Wholesale

```yaml
brand_id: general-wholesale
name: General Wholesale
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B0C9V2DMF7 | (no title on file) |  |
| B08QDQCYWN | (no title on file) |  |
| B0764LVPGF | (no title on file) |  |
| B08WJPQNYB | Poo-Pourri Before-You-Go Toilet Spray, Fresh Sea Salt, 2 Fl Oz, Up to 100 Uses, Bathroo... |  |
| B00O53SIKC | DGT 3000 Chess timer ,12 years+ |  |
| B012Z6EQ06 | Animal Animal Flex 44 Paks - CLF-ANI-AP53 by Animal |  |
| B0D7JWN3V3 | Arm & Hammer for Pets Odor Control Wipes for Dogs, Best Odor Eliminating Waterless Clea... |  |
| B00020HNG2 | Aura Cacia Essential Oil, Lemon Eucalyptus, 0.5 Fluid Ounce |  |
| B0CS4JZH2H | Core Nutritionals ABC Advanced BCAA Supplement / Amino Acid Recovery Blend / with Gluta... |  |
| B0CS45YFJG | Core Nutritionals ABC Advanced BCAA Supplement / Amino Acid Recovery Blend / with Gluta... |  |
| B0CS4B5HTN | Core Nutritionals ABC Advanced BCAA Supplement / Amino Acid Recovery Blend / with Gluta... |  |
| B089WD943F | Core Nutritionals Platinum Hard Advanced Recomposition and Hardening Agent, Reduces Cor... |  |
| B00822ZWHO | Dr. Bronner's - Pure-Castile Liquid Soap (Citrus, 2 ounce) - Made with Organic Oils, 18... |  |
| B09K145VXR | Dr. Bronner's Citrus Liquid Soap Parent |  |
| B00028O82Q | Dr. Bronner’s - Pure-Castile Liquid Soap (Tea Tree, 237 mL) - Made with Organic Oils, 1... |  |
| B0CDHXJHC4 | Dr. Bronner's Tea Tree Liquid Variation |  |
| B001E0ZJGK | Emerita Progest Parab Free Cream 2 oz |  |
| B07ZDJPFKZ | Essence of Argan Face Serum Collection – Hydrating, Brightening, Peptide & Anti-Aging S... |  |
| B0050N4DLO | Garnier Fructis Style Pure Clean Finishing Paste, 57g |  |
| B01MAW2294 | Google Whole Home Mesh Wi-Fi System (set of 3) [US Version] |  |
| B003M5SZY8 | Hilroy 10 Lb. Woven Envelopes, 4-1/8 X 9-1/2 Inches, 50 Count, White (36612) |  |
| B0DJRJ7WYD | LILLIES Q Smoky BBQ Sauce, 15.3 OZ |  |
| B0DJRGG8LW | LILLIES Q Carolina BBQ Sauce, 15.5 OZ |  |
| B00DKF7XPW | Mad Hippie Vitamin C Serum with Konjac Root, Hyaluronic Acid, and Ferulic Acid - 1.02 f... |  |
| B01INCGTGA | MRS. MEYER'S CLEAN DAY Liquid Dish Soap, Apple Cider Scent, 16 Fl Oz Bottle |  |
| B09FYN7J42 | Natural Vitality CALM, Magnesium Citrate Supplement, Stress Relief Gummies, Supports a ... |  |
| B00LM558M2 | LITTLE TREES Car Air Freshener / Hanging Tree Provides Long Lasting Scent for Auto and ... |  |
| B0DJFWMW7H | Naturium KP Body Scrub & Mask / Exfoliant for Rough and Bumpy Skin, With AHA, BHA & PHA... |  |
| B09CFT5WKW | PACHA SOAP Spearmint Lemongrass Bar Soap, 4 OZ |  |
| B0C5K42Z3F | Pacha Soap Coconut Papaya - 4 Ounce Bar - Natural |  |
| B08MGGX8YQ | Pacha Soap, Uplift Peaces Bar Soap, 7 Ounce |  |
| B087YYB1NY | PACHA SOAP Coconut Lemon Bar Soap, 4 OZ |  |
| B00SXG7ULK | Paper Mate Write Bros Ballpoint Pens, Medium Point (1.0mm), Black, 10 Count |  |
| B0F7H759GN | Magic Sponge Eraser POWOBEST 100 Pac Extra Thick Melamine Sponges Magic Cleaning Sponge... |  |
| B00016WY20 | Rainbow Light - Complete B-Complex, 90 Count, Food Based, Energy Support |  |
| B06ZYSRMF8 | Complete B-Complex by Rainbow Light |  |
| B0D9KTFDLG | ROCKY MOUNTAIN CO. Moisturizing Lemon Hand Wash Refill Pouches Bundle, 34 oz (1 L) Each... |  |
| B00C5TJ1MM | Slime 24011 Tire Plug Kit with T-Handle |  |
| B0CLN3LQF6 | SuperMush Energy Mushroom Gummies - Organic Lions Mane Supplement with Cordyceps, Rhodi... |  |
| B0GH46K33M | SuperMush Daily Energy Gummies Mushroom Supplement |  |
| B07X5MRGBP | Radius Zone Mosquito Repellent Refills by Thermacell, 40-Hours; Use with Radius Zone Mo... |  |
| B01NAHKVLM | Walker Tape C22 Solvent 4Oz Spray For Lace Wigs & Toupees by Walker Tape |  |
| B0G3SZS1RT | C-22 Solvent |  |
| B09R511V1Z | Yankee Candle Sidekick Refill MidSummer's Night |  |
| B005P0T12S | Calcium & Magnesium - Full Range Amino Acid Chelates in a Special Herb Base (90 Capsules) |  |
| B09VZX98DJ | SOLARAY Liposomal Multivitamin for Women, Enhanced Absorption, High Potency w/Iron, Vit... |  |
| B07K1DK2FP | Zinc 50mg Solaray 100 Veg Cap - Pack of 3 |  |
| B01MRT2HRP | Carina Organics Peppermint Shampoo & Body Wash, 360 Milliliter |  |
| B0002RID4G | Energizer 2032 Batteries, Lithium CR2032 6-Count [Compatible with Air Tag, Key Fob, Can... |  |
| B01IFKTNZE | Mattel BGG15 Apples to Apples Party in A Box |  |
| B08ZNRHLVH | Poo-Pourri Before-You-go Toilet Spray |  |
| B088CK4X7G | Oral-B iO Series 8 Electric Toothbrush with 2 Replacement Brush Heads, Violet Ametrine |  |
| B00UWRY9NU | Little Trees Green Apple Air Freshener (Pack of 6) |  |
| B0DNLR1RNZ | AIR WICK® SCENTED OIL - Refill - 0+2 Vibrant™ Pink Watermelon & Mimosa 2x23.9 mL |  |
| B0DS8L8ZTR | AIR WICK® SCENTED OIL - Refill - 0+2 Vibrant™ |  |
| B005P0W8RI | Natural Vitality calm lemon magnesium 8 oz |  |
| B000I4C3F8 | Solaray, Red Yeast Rice 600mg, 120 Veggie Capsules |  |
| B000GFJK8C | Planetary Herbals Myelin Sheath Support 820 mg, Herbal-Nutrient Nervous System Support,... |  |
| B08BDCHZ4Q | Core Nutritionals Vegan Gourmet Plant Based Protein Blend / with Vegan BCAAs / Lactose,... |  |
| B000QS7GQ2 | SOLARAY Reishi Mushroom 600mg - Reishi Mushroom Capsules for Immune Support - Vegan, La... |  |
| B007IJ0I12 | Pure Essence Labs Transitions Vitamins for Women, Natural Menopause Relief Supplement t... |  |
| B0D3J6NYYD | Lundberg Organic Chicken & Herb Seasoned Rice - Regenerative Organic Certified Long Gra... |  |
| B07HHWFZ5J | DGT3000 LE - Fide Approved Limited Edition Chess Timer… |  |
| B07QD6XDNM | Anima Mundi Apothecary Healthy Hair Vitamins - Adaptogenic He Shou Wu - Fo Ti Root Hair... |  |
| B0BG38SDRV | KAL Magnesium Glycinate ActivGels 315mg, Fully Chelated, High Absorption Magnesium Supp... |  |
| B081BD9T6Q | Atlantic Naturals Superfood Organic Irish Sea Moss Capsules - 120 Veggie Capsules / Wil... |  |
| B00RHMA3E2 | Dynamic Health Certified Organic Raw Apple Cider Vinegar with Mother / Unfiltered, Unpa... |  |
| B005P0NBBA | Rainbow LIght - Women's One Multivitamin, One-a-Day Support for Bone and Breast Health,... |  |
| B0F9ZR37P4 | Atlantic Naturals Sea Moss Superfood Capsules - 60 to 120 Count Vegetable Capsules |  |
| B0B3G27K6R | SOLARAY Liposomal Multivitamin with Enhanced Absorption |  |
| B06XTF7M64 | Pure Essence Labs Transitions Vitamins for Women, Natural Menopause Relief Supplement t... |  |
| B0DH8QQGRL | MyoBlox - SKYWALK |  |
| B00PXOP7C4 | Carina Organics Extra Gentle Baby Lotion, Organic & Natural, for Sensitive Skin, Whole ... |  |
| B000VHLGAK | Bionaturae, Tomato Paste Organic, 7 Ounce |  |
| B0B453RMGX | Pacha Soap Co. Bar Soap 5 Pack, Coconut Lemon, 4 oz each - Handcrafted, Hydrating, Natu... |  |
| B0G4CVKTN6 | Jarrow Formulas See Packaging |  |
| B00EE7PXZW | Jarrow Formulas Vitamin D3, 2500IU, 100 Softgels |  |

_Last synced: 2026-07-16 (77 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

TODO — who buys this and why, primary use cases, price position.

## Voice & tone

TODO — how this brand sounds; example phrases that fit and that do not.

## Claims — approved

TODO — only claims listed here may appear in copy. Include substantiation per claim. Until filled, skills must treat ALL claims beyond current listing copy as unapproved.

## Claims — banned

TODO

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO

## Notes

No Data Dive coverage by design (not dived) — keyword work for this brand runs rank-blind; skills should not flag missing rank data as a gap.

TODO — promos, S&S strategy, catalog quirks.
