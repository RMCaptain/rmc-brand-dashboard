# Brand Profile: Viva

```yaml
brand_id: viva
name: Viva
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B078YBJ6YG | Viva Vitamins Time Release Vitamin C 1000mg Tablets, High Potency Organic Vitamin C Sup... |  |
| B01DYJ4G4O | Viva Vitamins PMA Positive Mental Attitude - Mood Support Supplement - Mood Pills - Moo... |  |
| B01DYKA64W | Viva Vitamins - Complete Minerals, Regular Strength - Complete Multiple Mineral Supplem... |  |
| B08813TWX1 | Greater Greens Detox Cleanse - Super Greens Powder for Bloating Relief for Women & Men,... |  |
| B0CFRNSNZD | Hair Growth Vitamins for Women & Men, Multivitamin Hair Growth Supplement with Biotin S... |  |
| B08T7K9S56 | Bone Supplement - Calcium Supplement for Women and Men, Bone Health Vitamin D 3 w/Calci... |  |
| B078YW78H4 | Super Magnesium |  |
| B078YYZ8Z1 | CSP Packs Extra Strength - Multivitamin and Multi Mineral Supplements Complete E & C, I... |  |
| B01DYJ4IDS | Viva Vitamins Prostate Health Supplements for Men - with Pygeum, Pumpkin Seed Oil, and ... |  |
| B08T8C7S35 | Viva Vitamins Relaaax - with Magnesium, GABA, L-Theanine, Lemon Balm, Supports Mood, Re... |  |
| B01DYJ4DO2 | Natural Cleanse - Laxatives Senna Tablets for Colon Cleanse, Gut Cleanse, and Stool Sof... |  |
| B0C2F2FLQ8 | CalMagD - Calcium Supplement with Magnesium and Vitamin D as D3 - Calcium Magnesium Sup... |  |

_Last synced: 2026-07-16 (12 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

TODO — who buys this and why, primary use cases, price position.

## Voice & tone

TODO — how this brand sounds; example phrases that fit and that do not.

## Claims — approved

TODO — only claims listed here may appear in copy. Include substantiation per claim. Until filled, skills must treat ALL claims beyond current listing copy as unapproved.

## Claims — banned

TODO

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO

## Notes

TODO — promos, S&S strategy, catalog quirks.
