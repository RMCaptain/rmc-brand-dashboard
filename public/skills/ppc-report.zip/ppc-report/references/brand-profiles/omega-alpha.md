# Brand Profile: Omega Alpha

```yaml
brand_id: omega-alpha
name: Omega Alpha
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B00I47O7J6 | OptiPet Liquid Multivitamin, Dog Supplements, Cat Essentials, Cat & Dog Vitamins and Su... |  |
| B00H2U50CO | Omega Alpha Probiotic 8 Plus Equine Powder 500g, Multi-Strain Digestive Support Supplem... |  |
| B07PKH1V5V | Hyaluronic Acid Supplement (HA-180), Hip and Joint Supplement for Dogs & Cats, Pets Per... |  |
| B00CORLZ1A | Omega Alpha Dong Quai Elixir Liquid Herbal Supplement for Women's Hormonal Balance & Vi... |  |
| B00FIJ1KVG | Omega Alpha LungTone 500mL Liquid for Pets, Lung Support & Respiratory Care for Dogs & ... |  |
| B0765DSVQD | Omega Alpha Probiotic 8 Plus 310g Powder for Dogs & Cats with 8 Strains & Digestive Enz... |  |
| B0829XY237 | Omega Alpha GlucosaPet, Liquid Supplement for Dogs & Cats 4 Litre with Glucosamine Chon... |  |
| B00CORM5NM | Omega Alpha Resprit Liquid Herbal Supplement for Respiratory Wellness & Airway Comfort,... |  |
| B007YN3QRU | EnduraStress Dog Vitamins and Supplements, Supplement Boost for Energy, Focus and Endur... |  |

_Last synced: 2026-07-16 (9 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

TODO — who buys this and why, primary use cases, price position.

## Voice & tone

TODO — how this brand sounds; example phrases that fit and that do not.

## Claims — approved

TODO — only claims listed here may appear in copy. Include substantiation per claim. Until filled, skills must treat ALL claims beyond current listing copy as unapproved.

## Claims — banned

TODO

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO

## Notes

TODO — promos, S&S strategy, catalog quirks.
