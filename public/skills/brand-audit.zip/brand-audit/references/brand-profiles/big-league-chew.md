# Brand Profile: Big League Chew

```yaml
brand_id: big-league-chew
name: Big League Chew
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B0FXYFNYDB | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0015DMKGI | Big League Chew Sour Apple 12 Pack Box |  |
| B0FKKJ672S | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0FXYG5H5T | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0FKD1YM9G | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0FXYGNW3N | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0FKKRMLGY | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B000FOIYSG | Big League Chew, Outta' Here Original Bubble Gum, 2.12-Ounce Pouches (Pack of 12) |  |
| B0FXYD5X11 | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0FXYGBGKN | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0G1NH4N9H | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0FKKZ99Y5 | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0087SVODE | Big League Original Chew Bubble Gum 12 Count |  |

_Last synced: 2026-07-16 (13 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

TODO — who buys this and why, primary use cases, price position.

## Voice & tone

TODO — how this brand sounds; example phrases that fit and that do not.

## Claims — approved

TODO — only claims listed here may appear in copy. Include substantiation per claim. Until filled, skills must treat ALL claims beyond current listing copy as unapproved.

## Claims — banned

TODO

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO

## Notes

TODO — promos, S&S strategy, catalog quirks.
