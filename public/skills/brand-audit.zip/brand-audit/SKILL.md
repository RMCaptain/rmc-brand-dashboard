---
name: brand-audit
description: Judge an entire brand as a whole — traffic and Buy Box trends, promotion effectiveness, Subscribe & Save, repeat purchase, portfolio shape — and produce the Brand Manager's monthly review brief with brand-level recommendations. Use for "brand audit", "how is the brand doing overall", monthly brand reviews, or QBR prep.
---

# /brand-audit [brand] [period, default: last full month vs prior month]

The brand-level view. `/asin-audit` grades products; this grades the *brand* — its trajectory, its promotional motion, its subscriber base, and what the Brand Manager should do about it. Built to feed the Monthly Brand Performance Review.

## You provide → you get

| You provide | You get |
|---|---|
| Brand + period | A one-page monthly brand brief: trend verdict, promotion scorecard, S&S and repeat-purchase read, portfolio risks, and 3–7 brand-level moves |
| Promo calendar for the period (dates + type + ASINs) — from the brand profile Notes or pasted | Lift analysis per promotion (during vs. before/after) with a ran-it-worth-it verdict |
| Optional: Brand Analytics repeat-purchase export, Data Dive conversion-share data | Repeat-rate trend; keyword-level conversion advantages folded into recommendations |

## Read first

`references/rmc-standards.md`, `references/kpi-targets.md`, `references/dashboard-access.md`, and the brand profile (Notes section often holds the promo calendar and S&S strategy).

## Data

- **Dashboard:** daily brand-wide and per-ASIN sessions, units, revenue, Buy Box %, ad spend/sales, refunds, inventory — period + prior period + enough history for baselines (~90d).
- **Promotions:** the dashboard does NOT store promo history. Get the calendar from the brand profile or the user. No calendar → analyze visible anomalies (sales spikes with price/session shifts), label them "unexplained spikes — provide promo calendar to confirm," and never guess causes.
- **S&S:** enrolled ASINs from dashboard flags; subscription counts/trend from the S&S report if the user provides it.
- **Repeat purchase:** requires a Brand Analytics repeat-purchase export (Brand Registry access — may not exist for all reseller brands). Without it, use S&S enrollment + trend as the loyalty proxy and say so plainly.

## Audit dimensions

1. **Trajectory:** revenue, units, sessions, brand CVR — period vs prior vs baseline. Say whether growth is traffic-driven or conversion-driven (they demand different responses).
2. **Buy Box:** brand-wide weighted %, worst offenders, trend. Lost Buy Box compounds every other metric — it leads the fix list when present.
3. **Promotions:** classify every promo in the calendar by type — **brand-tailored promotions** (coupons, tiered discounts, bundles), **Prime Exclusive Discounts**, **Best Deals**, **Lightning Deals** — and for the latter three, mark **event-specific** (Prime Day, BFCM, Big Spring Sale, etc.) vs **non-event**. That distinction changes the yardstick: event promos get judged against event-window expectations (event traffic inflates everything — compare to the same event last year or other event participants, never to a regular week); non-event promos get judged against the ASIN's normal baseline. For each: units/revenue lift during vs. comparable windows, post-promo dip (pull-forward), estimated promo cost vs incremental revenue. Verdict per promo: repeat / adjust / drop. Then the forward call: which type fits the data next — a brand-tailored promo for loyalty/basket goals, PED/Best/Lightning for velocity or rank pushes, event slots where the brand has proven event lift. Never "run more promos" without a mechanism.
4. **Subscribe & Save — with trends:** enrolled vs. eligible ASINs, then the trend breakdown: subscription count over time and new-vs-cancelled movement (from the S&S performance report when provided), S&S delivery volume trend, and S&S-enrolled ASINs' share of brand units month over month (computable from dashboard history — a decent loyalty proxy even without the report). Growing subscriptions with flat sessions = compounding base worth protecting; shrinking subscriptions on a replenishable product = churn problem to diagnose before chasing new traffic. High-CVR, replenishable, un-enrolled ASINs are the S&S recommendation shortlist.
5. **Repeat purchase:** rate and trend (or the S&S proxy, labeled). Rising repeat + flat new-customer traffic vs. the reverse are opposite problems — name which one this brand has.
6. **Portfolio shape:** revenue concentration (top ASIN's share of brand), dark ASINs (converting well, no ad support), inventory risk roll-up, dormant listings. Concentration >40% on one ASIN gets flagged with a diversification note.
7. **Conversion advantages (Data Dive — dashboard `/api/datadive/:brandId` snapshots first, MCP live second):** keywords where the brand's ASINs out-convert the market — the brand's structural strengths; recommendations should lean into them.

## Output — the monthly brief

1. **Verdict paragraph:** trajectory in two sentences with the two numbers that matter.
2. **Brand-level moves, ranked** (3–7): each with mechanism, expected effect, owner (BM decides; route product-level digs to `/asin-audit`, ad work to `/ppc-*`, copy to `/listing-copy`).
3. **Promotion scorecard** (table, when calendar provided).
4. **Watch list** and **data gaps** (what was proxied or missing, and what to provide next month to close it).
5. Save as `Outputs/YYYY-MM-DD_brand-audit_<brand>.md` (Claude Code) or downloadable file (claude.ai).

## Rules

- Every number: period + source + comparison. Never attribute a sales change to a promo without the calendar confirming timing.
- **No margin, COGS, or profit figures in anything a client could see.**
- Draft only. Promo proposals are proposals — nothing gets scheduled or published.
- Missing data shrinks scope, not confidence: audit what exists, list the gaps, tell the user exactly which export closes each gap.

## Self-check

- [ ] Traffic-vs-conversion diagnosis stated explicitly
- [ ] Every promo verdict traces to a lift number, or the promo is marked unanalyzable
- [ ] Recommendations are brand-level (promos, S&S, portfolio) — product-level items routed to the right skill
- [ ] Data gaps section present and specific
