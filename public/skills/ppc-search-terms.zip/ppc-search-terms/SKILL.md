---
name: ppc-search-terms
description: Analyze an Amazon Sponsored Products search term report — produce a negation list, harvest converting terms into exact-match targets, and flag match-type migrations. Use for "search term report", "negatives", "harvest keywords", or weekly search-term hygiene.
---

# /ppc-search-terms [brand] [report attached or via Ads MCP]

Search-term hygiene: cut waste, promote winners.

## Read first

`references/rmc-standards.md` and `references/kpi-targets.md` (in this skill folder on claude.ai; at `../../references/` in the repo). Brand profile for hero keywords context.

## Get the data

1. **Preferred (Claude Code):** the dashboard's search-term endpoint — `GET /api/ads/search-terms?brand=<id>` per `references/dashboard-access.md`. Rolling 30 days, clicked terms only, refreshed Mondays; response includes the window — state it. Pair with `GET /api/ads/campaigns?brand=<id>` to see which exact-match targets already exist (critical for harvest dedup).
2. Seller Central search term report (60 days if available) — uploaded CSV/XLSX. Parse whatever columns exist; state the date range found.
3. Amazon Ads MCP if connected — pull search-term data for the brand's campaigns.
4. No data → tell the user exactly which report to export (Advertising Console → Measurement & Reporting → Sponsored Products Search Term Report) and stop.

Ask for the brand's ACOS target if it differs from the default 30% (check brand profile first).

## Analysis

1. **Negate** (recommend negative exact unless a whole theme is bad, then negative phrase at campaign level):
   - Spend > ~2× average CPC-per-order benchmark with 0 orders (default: spend > $8 CAD, 0 orders — scale threshold to the account's average order value and state the threshold used)
   - Clicks ≥ 10 with 0 orders
   - Converting but ACOS > 2× target with meaningful spend
   - Clearly irrelevant terms regardless of spend (wrong product, wrong species/size, competitor-brand terms per brand policy)
2. **Harvest:** terms with ≥ 2 orders and ACOS under target that are NOT already exact-match targets → recommend adding as exact (state which campaign/ad group, or "new exact campaign" if none fits), with a starting bid = ~90% of the term's observed CPC.
3. **Migrate:** terms converting well in auto/broad that dominate an ad group's spend → recommend exact + negate at source to stop cannibalization.
4. **Duplicates:** same term converting in multiple campaigns → keep the best performer, negate elsewhere.

## Output

Three tables — Negate / Harvest / Migrate — each row: term, campaign, ad group, spend, clicks, orders, ACOS, action, reason. Bottom line: projected monthly spend saved by negations (sum of trailing waste, labeled as an estimate from the report window). Save as `Outputs/YYYY-MM-DD_ppc-search-terms_<brand>.md` + offer the tables as CSV for bulk upload.

## Rules

- Draft only. Never push changes via Ads MCP or anywhere else — the PPC Specialist applies changes.
- Never recommend negating a brand's own branded terms without flagging it as a strategic call.
- State thresholds used; if the data window is short (<30 days), say conclusions are weaker and why.
- Report currency as found (CA and US campaigns are separate — don't mix without converting; label which profile the data is from).

## Self-check

- [ ] Every recommendation has the numbers that justify it in the same row
- [ ] Thresholds stated; date range stated
- [ ] No pushes, no sends — output is a draft for May Grace's review
