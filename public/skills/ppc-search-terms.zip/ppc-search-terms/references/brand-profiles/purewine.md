# Brand Profile: Purewine

```yaml
brand_id: purewine
name: Purewine
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B07LGBLWBS | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B06XGP85LR | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B09HJJ2C8Z | PureWine Phoenix Bio-Pods - Premium Wine Filter Replacements for Enhanced Flavour - Rem... |  |
| B09HJMRZWS | Phoenix Wine Aerator & Purifier - Reusable Wine Aerator Pourer with BioPod Filter Syste... |  |
| B099MNMLVZ | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B09RRX1XF8 | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B0BJ4JSQB6 | Phoenix Wine Aerator & Purifier - Reusable Wine Aerator Pourer with BioPod Filter Syste... |  |
| B0771H8V5H | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B08TRNKYND | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B08JNQ39JM | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B099M8WLKD | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B06XGP5B63 | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B0CN9J6NQ4 | PureWine Pink Wand Technology Histamine and Sulfite Filter, Purifier Reduces Wine Aller... |  |
| B0FL9J8QJQ | (no title on file) |  |
| B06XBPFHNJ | PureWine Wand Filters Stick Histamines and Sulfites - Reduces Wine Allergies & Purifier... |  |

_Last synced: 2026-07-22 (15 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

TODO — who buys this and why, primary use cases, price position.

## Voice & tone

TODO — how this brand sounds; example phrases that fit and that do not.

## Claims — approved

TODO — only claims listed here may appear in copy. Include substantiation per claim. Until filled, skills must treat ALL claims beyond current listing copy as unapproved.

## Claims — banned

TODO

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO

## Notes

TODO — promos, S&S strategy, catalog quirks.
