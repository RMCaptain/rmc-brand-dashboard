# Brand Profile: Trimax

```yaml
brand_id: trimax
name: Trimax
marketplaces: [CA]
category: trailer, towing & marine security hardware
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B003ESOAIS | Trimax TCP50 Trailer Lock Combo Pack (Keyed Alike), Black |  |
| B002IV4ZW8 | TRIMAX THP3XL - Trailer Door Lock (3 Pack Keyed Alike) - Shackleless Puck Lock for Trai... |  |
| B000W0OFXG | TRIMAX MAG200 - Trailer Receiver Lock (Resettable Combination) - Combination Lock Trail... |  |
| B0000ATZD5 | TRIMAX ST30 - Trimaflex Spare Tire Cable Lock (Round Key) for Boat Trailers, Motor Home... |  |
| B00J0ABS5M | Trimax – T5Black – 5/8" Receiver Lock – 3.5" Span, Fits Class V Hitches, Machine-Forged... |  |
| B0031XXWHG | Trimax TBL610 Outboard Motor Lock Quick Release/Install, Secures for Maximum Security, ... |  |
| B0031XULF2 | TRIMAX TCL65 - Trailer Wheel Lock - Fits 6"-10.5" Tires - Wheel Boot Lock for Trailer, ... |  |
| B007ACZTGQ | Trimax – TCP100 – Keyed-Alike Towing Kit – Locks Include UMAX100 Coupler, TC123 Coupler... |  |
| B000W0OGUS | Trimax TDL3010 - Trimaflex Dual Loop Multi-Use Security Cable 30 Feet x 10mm - Commerci... |  |
| B000MU8XI4 | Trimax TDL815 - Trimaflex Dual Loop Multi-Use Security Cable 8 Feet x 15mm - Commercial... |  |
| B08ND21DCZ | Trimax - TFW80HD - 5th Wheel King Pin Lock -Heavy Duty Anti-Theft Trailer Lock, Hardene... |  |
| B007ACZVXC | Trimax - TH6 5/8" x 6-1/8" Swing-Away Trailer Lock - Premium Receiver Lock for Trailer,... |  |
| B00020XQ1S | Trimax TMC10 Deluxe Coupler/Door Latch Lock (fits couplers to 3/4" Span) |  |
| B0031XULHK | Trimax - TNL740 Spare Tire Nut Lock for Side Mount Spare Tires, Easy Install - for SUV,... |  |
| B003E1GLSM | Trimax TWL100 Ultra-Max Adjustable Wheel Lock, Yellow/Black |  |
| B00J0ABS5W | TRIMAX TLR51 - Pintle Hitch Ring Lock - Lunette Ring Lock for Pintle Hook Trailers - Fi... |  |
| B00J0ABROY | (no title on file) |  |
| B07JPCVM14 | (no title on file) |  |
| B07JDF79W9 | (no title on file) |  |
| B000CKRWL8 | (no title on file) |  |
| B000OC3Q2I | (no title on file) |  |
| B000W0PMN8 | (no title on file) |  |
| B0055DQ2RC | (no title on file) |  |
| B000W0KUEY | (no title on file) |  |
| B086HLGXZ3 | (no title on file) |  |
| B07533PQNC | (no title on file) |  |
| B001H494DC | (no title on file) |  |
| B007ACZTEI | (no title on file) |  |
| B007ACZTIY | (no title on file) |  |
| B09DHSQD5S | (no title on file) |  |
| B00J0ABRL2 | (no title on file) |  |
| B004OHAK5K | (no title on file) |  |
| B07VMWH4SZ | (no title on file) |  |

_Last synced: 2026-07-22 (33 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

RV, boat, and trailer owners — generally men 35–65, "protect your investment" buyers. They're securing something worth tens of thousands of dollars; the purchase is insurance-minded, not impulse. Price position: more premium than Master Lock-type options.

## Voice & tone

Tough security, straight business. Spec-forward, confident, zero fluff — no jokes, no lifestyle framing.
Fits: "Machine-forged. Keyed alike. Fits Class V hitches."
Does not fit: playfulness, hype, vague "peace of mind" filler in place of specs.

## Claims — approved

**Lean on what's already on the listings — materials, features, benefits, and fitment — and nothing beyond it.**

- Material and construction claims (hardened steel, machine-forged, etc.) as stated on the current listing for that product.
- Fitment facts (span, diameter, class, tire size range, keyed-alike vs resettable) — from the listing/label only; never guess, wrong fitment = returns.
- Model numbers (TCP50, MAG200, TH6...) stay in titles and copy.
- **Never mention warranty.** No warranty claims of any kind.

## Claims — banned

- Warranty — do not mention it at all.
- Anything not on the product's current listing.
- No other known banned claims — but stay inside the current-listing rule, and keep security framing to deterrence/specs rather than absolute guarantees ("theft-proof") unless the current listing itself says it.

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

Positioned above Master Lock-type options (see Audience). Dedicated competitor list TODO — evaluate per ASIN when needed.

## Notes

- **Seasonality: spring and summer** — towing season. Weight audits, ads, and expectations to the season; soft winter numbers are the pattern, not a problem.
- **No promotions, ever.** No discounts, no coupons, no deal events — across the board. Skills must never recommend a promotion for this brand.
- **S&S is completely irrelevant** — locks don't re-order. Skip S&S analysis entirely.
- **Buy Box takeover in progress:** RMC is currently taking the winning Buy Box from Amazon and other third-party sellers and will soon be the only dominant seller. Interpret Buy Box % shifts in that context — rising RMC share is the plan working, not volatility.
