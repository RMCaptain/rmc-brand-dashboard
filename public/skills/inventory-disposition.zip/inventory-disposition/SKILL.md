---
name: inventory-disposition
description: Weekly FBA inventory disposition brief for the Monday team meeting — every unit that is not fulfillable or inbound (unfulfillable, reserved, researching, stranded), by brand and ASIN, with week-over-week trends and ranked actions. Use for "inventory disposition", "unfulfillable report", "stranded inventory", "what's stuck at FBA", or Monday meeting inventory prep.
---

# /inventory-disposition [brand or ALL, default ALL] [week ending, default last Saturday]

Finds every FBA unit that can't sell right now, explains why, and shows whether each problem is growing or shrinking week over week. Built for the Monday 10am team meeting.

## Read first

`references/rmc-standards.md`, `references/dashboard-access.md` (in this skill folder on claude.ai; at `../../references/` in the repo). Brand profiles only for offboarding status — offboarding brands still get reported (their stock still needs a decision), flagged as offboarding.

## Disposition buckets

Report everything EXCEPT fulfillable and inbound:

| Bucket | What it means | Usual action |
|---|---|---|
| Unfulfillable | Damaged (customer/warehouse/carrier/distributor), defective, expired | Warehouse/carrier damage → reimbursement claim; customer damaged/defective → removal or disposal order; expired → disposal |
| Reserved — customer orders | Picked for an order in progress | Normal; only flag if it spikes vs units sold |
| Reserved — FC transfer | Moving between fulfillment centres | Normal; flag if one ASIN sits here 2+ weeks |
| Reserved — FC processing | Held for measurement, investigation, or inbound processing | Flag if held 2+ weeks — open a case |
| Researching | Lost/misplaced, Amazon investigating | Flag at 2+ weeks — reimbursement eligibility window |
| Stranded | In FBA with no active offer (listing suppressed, pricing error, closed) | Fix listing or create removal — stranded units accrue storage fees and earn nothing |

## Get the data

- **Claude Code:** dashboard API per `dashboard-access.md`. **claude.ai:** RMC Dashboard connector — `get_brand_report` (per brand, `from`/`to` = trailing 5 weeks, `includeDaily=true` for the reserved/unfulfillable/on-hand series) and `get_listing_health` (stranded units + reasons, current snapshot).
- **What has history (as of 2026-10):** on-hand, reserved total, unfulfillable total — daily since 2026-05-28 (reserved since 2026-08-05). **Current-only (no history yet):** stranded, researching, and the sub-reasons inside reserved/unfulfillable. Dashboard work to store those daily is queued.
- **Reserved reason (required — never report a bare reserved number).** The connector's `inventory.reserved` is a total only. Get the split from, in order:
  1. Connector/API field `inventory.reservedBreakdown` (`customerOrders`, `fcTransfer`, `fcProcessing`) when present.
  2. **Sellerboard connector** `inventory` (channel `FBA`, `search_query` = one ASIN per call; `list_accounts` once, then use the account holding the brand, main account is "Rocky Mountain Co"). Read `reserved_customerorders`, `reserved_fc_transfers`, `reserved_fc_processing` per marketplace row. Do NOT use Sellerboard's `Reserved` field as the total: it excludes customer orders. Use units fields only; ignore every cost/profit/sales field it returns. Pace calls (≤3/sec).
  3. Seller Central **Reserved Inventory report** (Reports → Fulfillment → Inventory → Reserved Inventory; columns `reserved_customerorders`, `reserved_fc-transfers`, `reserved_fc-processing`). On claude.ai ask the user to upload or paste it once at the start of the run.
  4. None available → reason cell reads `Unknown — pull Reserved Inventory report`, the ASIN goes on the action list as "confirm reserved reason", and the data coverage line says so. Never infer a reason from sales velocity.
  Splits must sum to the reserved total; if they don't (snapshot timing), show both and flag the gap.
- For current-only buckets, week-over-week comes from last week's brief: Claude Code reads the newest `Outputs/reports/*_inventory-disposition_*.md`; claude.ai asks the user to paste last week's summary table. No prior brief → mark trend "baseline week", never guess.
- Week = Sunday–Saturday, matching the PPC report. Compare the Saturday snapshot of the reported week vs the prior Saturday.

## Analysis

1. **Headline:** total non-sellable units across all brands this week vs last, and units that changed bucket.
2. **Per brand → per ASIN table:** each bucket's units this week, last week, Δ, and weeks-in-bucket (consecutive weeks with units > 0). Sort by total non-sellable units, worst first. Reserved is never one column: show **Reserved** (total), then **Reserved reason** stating the split in plain words, e.g. `FC processing 15 · Customer orders 4`, biggest first, with the disposition implied by the bucket table (customer orders = normal; FC transfer = normal unless 2+ weeks; FC processing = case if 2+ weeks). Required columns, in order: ASIN · Product · Unfulfillable · Reserved · Reserved reason · Researching · Stranded · Total non-sellable · Δ vs last week · Weeks in bucket · Sellable on hand · Units sold (35d) · Res ÷ wk sales (reserved ÷ (35-day units ÷ 5); bold above 1.0).
3. **Trends (5-week window where history exists):** buckets growing 2+ weeks straight; ASINs new to a bucket this week; anything cleared (good news counts too). Unfulfillable rising while units sold is flat → inbound/prep problem, call it out.
4. **Ranked actions:** reserved units only become an action when the reason calls for one (FC processing or FC transfer stuck 2+ weeks, customer orders spiking vs units sold, or reason unknown). Each action names the ASIN, units, bucket, recommended step, and owner role (Amazon Specialist for listings/cases, Warehouse Ops for removals). Order by units × weeks stuck.

## Output

Meeting-ready one-pager: headline (3 lines) → actions (ranked, max 10) → per-brand tables → trend notes → data coverage line (which buckets had history, which compared against last week's brief). Save as `Outputs/reports/YYYY-MM-DD_inventory-disposition_<brand-or-all>.md` (Claude Code) or downloadable file (claude.ai). The saved file is next week's comparison baseline — always save it.

## Rules

- Internal document. Units only — no COGS, buy cost, or dollar value of inventory unless Mike asks for it explicitly.
- CA and US reported separately; never sum units across marketplaces without labeling it as a combined count.
- General Wholesale excluded (per `rmc-standards.md`).
- Draft only. No removal orders, cases, or listing changes are created — every action is a recommendation for the team.
- Missing data is stated, never estimated.

## Self-check

- [ ] Every non-fulfillable, non-inbound bucket covered (or stated as unavailable)
- [ ] Every ASIN with reserved > 0 has a Reserved reason cell (split or "Unknown — pull Reserved Inventory report")
- [ ] Each trend states its comparison source (dashboard history vs last week's brief vs baseline)
- [ ] Every action has ASIN, units, step, owner
- [ ] File saved for next week's comparison
