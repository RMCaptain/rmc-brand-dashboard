---
name: ppc-campaign-builder
description: Design Sponsored Products campaign structures for a product launch or restructure — campaign/ad-group layout, targeting, starting bids, budgets, negatives — delivered as a bulk-upload-ready draft. Use for "launch campaigns for", "restructure ads", or "campaign recommendations".
---

# /ppc-campaign-builder [brand] [ASIN(s)]

Designs the campaign structure; May Grace launches it.

**Budget model:** RMC does not use launch budgets. The brand scales slowly, managed to brand-level TACOS, and budget decisions belong to the PPC Specialist. Never ask for a monthly budget — propose conservative *starting* daily budgets per campaign and frame every budget number as May's call, with scaling tied to the brand's TACOS trend.

## Read first

`references/rmc-standards.md`, `references/kpi-targets.md` (in this skill folder on claude.ai; at `../../references/` in the repo). Brand profile for hero keywords, ACOS target, competitors.

## Inputs

- ASIN(s) + price point; keyword data (dashboard Data Dive data via API or the RMC Dashboard connector's `get_datadive` → Data Dive MCP → export → brand profile, in that order — same ladder as `/listing-copy`).
- ACOS target (profile default 30% if unstated). Do NOT ask for a budget (see Budget model above).
- Existing campaigns for the ASIN (Ads MCP or export) — REQUIRED for restructures so nothing is duplicated; for new launches, ask whether any exist.

## Structure (default ladder — adapt, don't force)

1. **Auto campaign** (research): close/loose/substitutes/complements as separate targeting groups, low bids, feeds harvest loop.
2. **Broad/phrase research campaign:** 10–20 mid-volume keywords from the keyword data.
3. **Exact performance campaign:** hero keywords (5–15), one ad group per tight theme, highest bids.
4. **Competitor/product targeting** if profile lists competitors: their ASINs + category refinement.
5. Single-ASIN campaigns for hero products; group only true variants together (shared ad group = shared search results real estate).

Per campaign: name using `<brand>-<asin/theme>-<type>-<match>` convention, a conservative starting daily budget (slow-scale default: enough for ~5–10 clicks/day at expected CPC; weight exact > auto > broad ≈ competitor) flagged as the PPC Specialist’s call, starting bids (from keyword data CPC estimates; auto ~70% of exact), placement modifier suggestion (top-of-search only where exact CVR history supports it), built-in negatives (cross-negate exact terms from research campaigns at creation).

## Output

1. **Structure sheet:** every campaign → ad groups → targets → match type → starting bid → daily budget, as a table ready to transcribe into a bulk file. Offer CSV matching the user's bulk-file template — ask for a sample bulk file first and mirror its exact columns rather than guessing Amazon's current template.
2. **Launch notes:** slow-scale plan — hold starting budgets until ACOS stabilizes, then scale in ~20% steps only while brand TACOS holds; when to first touch bids (not before 7 days / attribution settle); the harvest loop (`/ppc-search-terms` weekly).
3. **Assumptions list:** every number you assumed (CPCs, CVR) and where a real number should replace it.
4. Save as `Outputs/YYYY-MM-DD_ppc-campaign-builder_<brand>.md` + CSV.

## Rules

- Draft only. Never create campaigns via Ads MCP, even if connected and asked casually — output is always a reviewable artifact first.
- Every budget number is labeled "starting point — PPC Specialist’s call"; scaling guidance references brand TACOS, never a monthly envelope.
- No keyword data → build the structure but mark every bid "placeholder — pull Data Dive before launch"; never present guessed bids as data-backed.
- Restructures: map every existing campaign to keep/pause/merge before proposing new ones — never orphan spend.

## Self-check

- [ ] Budgets framed as conservative starting points owned by the PPC Specialist; scaling tied to brand TACOS
- [ ] Every bid traceable to data or explicitly marked placeholder
- [ ] Negatives/cross-negation included at creation, not left for later
- [ ] Nothing was pushed anywhere
