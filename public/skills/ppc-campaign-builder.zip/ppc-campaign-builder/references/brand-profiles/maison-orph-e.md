# Brand Profile: Maison Orphée

> **OFFBOARDING (Mike, 2026-07-23):** brand is leaving RMC soon. Maintenance only — no proactive listing rewrites, audits, or campaign builds unless Mike asks. Unconfirmed draft sections below are frozen as-is.

```yaml
brand_id: maison-orph-e
name: Maison Orphée
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B00PN1AFHE | Maison Orphée Grey Coarse Sea Salt w/Mineral from Noirmoutier Identical to Celtic Salt ... | Yes |
| B00PN0EW42 | Organic Dijon Mustard 250ml, BBQ & Grilling Condiment for Burgers, Marinades & Summer S... | Yes |
| B00PNQ0ER0 | Grey Non Iodized Fine Sea Salt ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral Rich Rea... | Yes |
| B00PN1AXLW | Grey Non Iodized Fine Sea Salt Shaker ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral R... | Yes |
| B0DPBJQ3QB | Grey Non Iodized Fine Sea Salt Shaker ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral R... | Yes |
| B0DPBK36TX | Grey Non Iodized Fine Sea Salt Shaker ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral R... | Yes |
| B015GEJJR4 | Organic Old-Fashioned Whole Grain Mustard 250ml, Low FODMAP Organic Mustard Condiment f... | Yes |
| B0DPBCPG8J | Grey Non Iodized Fine Sea Salt ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral Rich Rea... |  |
| B0DPBKTC1L | Fleur De Sel Flaky Sea Salt, Non-Iodized Sun Dried Mineral Salt with Trace Minerals, Ir... | Yes |
| B0DPGTT3ML | Grey Sea Salt Bundle 1kg Coarse + 500g Fine ‒ Organic Non Iodized Sel de Mer w/Potassiu... | Yes |
| B00PN0EUDU | Organic Yellow Mustard with Turmeric 250ml, BBQ Condiment & Dipping Sauce for Burgers a... | Yes |
| B0DPBCGM3B | Grey Non Iodized Fine Sea Salt ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral Rich Rea... | Yes |
| B0DPBKY581 | Maison Orphée Grey Coarse Sea Salt with Mineral from Noirmoutier Identical to Celtic Sa... | Yes |
| B00PN1AJHU | Fleur De Sel Flaky Sea Salt, Non-Iodized Sun Dried Mineral Salt with Trace Minerals, Ir... | Yes |
| B0DPBKTQTX | Fleur De Sel Flaky Sea Salt, Non-Iodized Sun Dried Mineral Salt with Trace Minerals, Ir... | Yes |
| B0DPGWGQJ7 | Fleur De Sel 125g & Fine Grey Sea Salt Shaker 250g ‒ Organic Non Iodized Sel de Mer w/P... |  |
| B0DPBJTX74 | Maison Orphée Grey Coarse Sea Salt w/Mineral from Noirmoutier Identical to Celtic Salt ... |  |

_Last synced: 2026-07-30 (17 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

_(draft — Mike to confirm)_ Home cooks and food-curious households who pay for provenance — organic buyers, Québec/French-food affinity, gift-basket builders. Premium grocery pricing.

## Voice & tone

_(draft)_ Warm, artisanal, provenance-proud — a good grocer telling you where the food comes from.
Fits: "Hand-harvested in Noirmoutier. Nothing else added."
Does not fit: industrial food-brand tone, health-benefit selling, hype.

## Claims — approved

**Facts model — origin, method, and label facts, per product per its current listing.**

| Claim | Substantiation |
|---|---|
| Origin (Noirmoutier, France etc.) | label / current listing |
| Organic (certified products only) | certification on label |
| Hand-harvested / sun-dried / cold-pressed / first cold pressing | label / current listing |
| Non-iodized, unrefined, no additives | label facts |
| Mineral-rich / trace minerals | current listings (descriptive of grey sea salt) |
| "Identical to Celtic salt" comparative | current listing — PENDING MIKE: keep or drop in new copy? |

## Claims — banned

- Health-benefit selling ("healthier salt", electrolyte/wellness framing) — it's food; sell provenance and taste.
- "Organic" on any product without the certification.

## Keywords

<!-- AUTO:KEYWORDS START — data columns refresh weekly from Data Dive; Tier override + Notes are yours and survive every refresh -->
| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| maison orphee | 250 |  | 1 (B00PN1AFHE) | Defend |  |  |
| grey salt | 250 | 0.82 | 2 (B00PN1AFHE) | Defend |  |  |
| non iodized sea salt | 250 | 0.89 | 2 (B00PN1AXLW) | Defend |  |  |
| fleur de sel | 1995 | 0.64 | 5 (B00PN1AJHU) | Defend |  |  |
| non iodized salt | 597 | 0.89 | 7 (B00PN1AXLW) | Strike zone |  |  |
| fancy salt | 250 | 0.73 | 8 (B00PN1AJHU) | Strike zone |  |  |
| flaky salt | 1326 | 0.73 | 9 (B00PN1AJHU) | Strike zone |  |  |
| flake salt | 720 | 0.82 | 11 (B00PN1AJHU) | Strike zone |  |  |
| salt flakes | 704 | 0.82 | 11 (B00PN1AJHU) | Strike zone |  |  |
| flaked sea salt | 548 | 0.91 | 13 (B00PN1AJHU) | Strike zone |  |  |
| flakey salt | 250 | 0.73 | 13 (B00PN1AJHU) | Strike zone |  |  |
| sea salt coarse | 250 | 0.73 | 14 (B00PN1AFHE) | Strike zone |  |  |
| flaked salt | 250 | 0.91 | 15 (B00PN1AJHU) | Strike zone |  |  |
| finishing salt | 459 | 0.82 | 16 (B00PN1AJHU) | Strike zone |  |  |
| flaky sea salt for baking | 250 | 0.91 | 16 (B00PN1AJHU) | Strike zone |  |  |
| flake sea salt | 250 | 0.91 | 17 (B00PN1AJHU) | Strike zone |  |  |
| iodized sea salt | 250 | 0.73 | 19 (B00PN1AFHE) | Strike zone |  |  |
| flaky sea salt | 3923 | 0.91 | 20 (B00PN1AJHU) | Strike zone |  |  |
| coarse sea salt | 859 | 0.73 | 21 (B00PN1AFHE) | Strike zone |  |  |
| sea salt flakes | 1163 | 0.91 | 22 (B00PN1AJHU) | Strike zone |  |  |
| mineral salt | 1260 | 0.91 | 24 (B00PN1AFHE) | Strike zone |  |  |
| curing salt | 841 | 0.55 | 24 (B00PN1AFHE) | Strike zone |  |  |
| curing salt for meat | 674 | 0.38 | 24 (B00PN1AFHE) | Strike zone |  |  |
| celtic salt | 7981 | 0.73 | 28 (B00PN1AFHE) | Strike zone |  |  |
| gourmet salt | 250 | 0.55 | 28 (B00PN1AJHU) | Strike zone |  |  |
| sel de mer | 691 | 0.91 | 29 (B00PN1AFHE) | Strike zone |  |  |
| sel celtique | 250 | 0.73 | 29 (B00PN1AFHE) | Strike zone |  |  |

_Synced 2026-07-30 from dashboard Data Dive snapshots. Rank = best across tracked ASINs (shown in brackets). Rank ≤30 keywords always listed; the rest are top-volume._
<!-- AUTO:KEYWORDS END -->

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO — team to add (Celtic/grey sea salt brands; premium mustard/oil brands per line).

## Notes

- Bilingual angle: French terms (Sel de Mer) already in titles — natural fit for .ca; keep French product names.
- 7 rank radars active.
