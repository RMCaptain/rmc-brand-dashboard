# Brand Profile: Zollipops

```yaml
brand_id: zollipops
name: Zollipops
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B0CSDXL3MZ | (no title on file) |  |
| B0HFKQKGT4 | (no title on file) |  |
| B00NUW6GHG | (no title on file) | Yes |
| B076QRBRLS | (no title on file) | Yes |
| B00NUW6DYW | (no title on file) | Yes |
| B0DFRSQGDF | (no title on file) |  |
| B0HFKFC9JF | (no title on file) | Yes |
| B0C6W88TZ5 | (no title on file) |  |
| B0B3B4JTWL | (no title on file) | Yes |
| B0198DHO76 | (no title on file) |  |
| B0HJD9L4RS | (no title on file) |  |
| B08P54MCKW | (no title on file) |  |
| B08Q4LKMHS | (no title on file) |  |
| B01BLAVYDY | (no title on file) |  |
| B094NVCST2 | (no title on file) |  |
| B0CSDX1KQ9 | (no title on file) |  |
| B00NUW6GQW | (no title on file) |  |

_Last synced: 2026-11-21 (17 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

TODO — who buys this and why, primary use cases, price position.

## Voice & tone

TODO — how this brand sounds; example phrases that fit and that do not.

## Claims — approved

TODO — only claims listed here may appear in copy. Include substantiation per claim. Until filled, skills must treat ALL claims beyond current listing copy as unapproved.

## Claims — banned

TODO

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO

## Notes

TODO — promos, S&S strategy, catalog quirks.
