# Brand Profile: Viva

> **OFFBOARDING (Mike, 2026-07-23):** brand is leaving RMC soon. Maintenance only — no proactive listing rewrites, audits, or campaign builds unless Mike asks. Unconfirmed draft sections below are frozen as-is.

```yaml
brand_id: viva
name: Viva
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B078YBJ6YG | Viva Vitamins Time Release Vitamin C 1000mg Tablets, High Potency Organic Vitamin C Sup... |  |
| B01DYJ4G4O | Viva Vitamins PMA Positive Mental Attitude - Mood Support Supplement - Mood Pills - Moo... |  |
| B01DYKA64W | Viva Vitamins - Complete Minerals, Regular Strength - Complete Multiple Mineral Supplem... |  |
| B08813TWX1 | Greater Greens Detox Cleanse - Super Greens Powder for Bloating Relief for Women & Men,... |  |
| B0CFRNSNZD | Hair Growth Vitamins for Women & Men, Multivitamin Hair Growth Supplement with Biotin S... |  |
| B08T7K9S56 | Bone Supplement - Calcium Supplement for Women and Men, Bone Health Vitamin D 3 w/Calci... |  |
| B078YW78H4 | Super Magnesium |  |
| B078YYZ8Z1 | CSP Packs Extra Strength - Multivitamin and Multi Mineral Supplements Complete E & C, I... |  |
| B01DYJ4IDS | Viva Vitamins Prostate Health Supplements for Men - with Pygeum, Pumpkin Seed Oil, and ... |  |
| B08T8C7S35 | Viva Vitamins Relaaax - with Magnesium, GABA, L-Theanine, Lemon Balm, Supports Mood, Re... | Yes |
| B01DYJ4DO2 | Natural Cleanse - Laxatives Senna Tablets for Colon Cleanse, Gut Cleanse, and Stool Sof... |  |
| B0C2F2FLQ8 | CalMagD - Calcium Supplement with Magnesium and Vitamin D as D3 - Calcium Magnesium Sup... |  |

_Last synced: 2026-07-30 (12 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

_(draft — Mike to confirm)_ Adults 35–65 managing their own supplementation routines — repeat-purchase category. Mid-market pricing vs big-box brands.

## Voice & tone

_(draft)_ Straightforward, trustworthy, label-first — a knowledgeable clerk, not a wellness influencer.
Fits: "Time-release Vitamin C, 1000mg per tablet. The label is the pitch."
Does not fit: miracle language, influencer-wellness tone, any effect promise beyond the licensed claim.

## Claims — approved

**Kidstar rule applies verbatim: whatever licensed NHP claim is on that specific product's current listing/label is fair to use — on that product only. Never transplant claims between products.**

- Reuse licensed wording exactly (e.g. "Immune Support", "Mood Support") only where the product's listing/label already carries it.
- Dosage, potency (mg), tablet counts, time-release format = label facts.

## Claims — banned

- Anything beyond the product's exact licensed claim — no disease treatment/cure/prevention language ever.
- No transplanting a sibling product's claim.
- Watch list from current titles (verify each is actually licensed wording before reuse): "Detox Cleanse", "Bloating Relief", "Hair Growth". If not on the NPN license, these are banned in new copy.

## Keywords

<!-- AUTO:KEYWORDS START — data columns refresh weekly from Data Dive; Tier override + Notes are yours and survive every refresh -->
| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| super magnesium | 2115 | 0.33 | 27 (B078YW78H4) | Strike zone |  |  |
| magnesium | 1464232 | 0.33 | 101 (B078YW78H4) | — |  |  |
| vitamin c | 1301469 | 0.21 | 101 (B078YBJ6YG) | — |  |  |
| magnesium complex for women | 972438 |  | 101 (B078YW78H4) | — |  |  |
| magnesium citrate | 675067 | 0.11 | 101 (B078YW78H4) | — |  |  |
| magnesium complex | 478590 | 0.11 | 101 (B078YW78H4) | — |  |  |
| biotin | 418331 | 0.05 | 101 (B0CFRNSNZD) | — |  |  |
| l theanine | 346433 | 0.05 | 101 (B08T8C7S35) | — |  |  |
| calcium | 299756 | 0.25 | 101 (B0C2F2FLQ8) | — |  |  |
| multivitamin | 240403 | 0.07 | 101 (B078YYZ8Z1) | — |  |  |
| hair growth supplements | 203968 | 0.47 | 101 (B0CFRNSNZD) | — |  |  |
| hair growth | 191208 | 0.11 | 101 (B0CFRNSNZD) | — |  |  |
| l-theanine | 178216 | 0.05 | 101 (B08T8C7S35) | — |  |  |
| calcium citrate | 159033 | 0.13 | 101 (B0C2F2FLQ8) | — |  |  |
| calcium supplements for women | 124101 | 0.29 | 101 (B0C2F2FLQ8) | — |  |  |

_Synced 2026-07-30 from dashboard Data Dive snapshots. Rank = best across tracked ASINs (shown in brackets). Rank ≤30 keywords always listed; the rest are top-volume._
<!-- AUTO:KEYWORDS END -->

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO — team to add (big-box vitamin brands are the price anchor; name specific rivals per product line).

## Notes

- 12 rank radars active — best per-ASIN Data Dive coverage in the portfolio.
- Several current titles look claim-heavy ("Mood Enhancer", "Detox") — verify against NPN licenses during the title sweep review.
