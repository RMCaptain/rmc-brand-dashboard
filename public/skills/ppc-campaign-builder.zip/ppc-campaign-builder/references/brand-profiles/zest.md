# Brand Profile: Zest

> **Minimal-effort brand (Mike, 2026-07-23):** staying, but low investment by design. Quick wins only (e.g. the bare 23-char title) — no deep audits, no sustained keyword work.

```yaml
brand_id: zest
name: Zest
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B0G3B8YKF2 | Zest Under Eye Patches for Dark Circles – Under Eye Mask with Collagen & Hyaluronic Aci... |  |
| B0CRFSFP4P | Zest Under Eye Patches for Dark Circles – Under Eye Mask with Collagen & Hyaluronic Aci... | Yes |
| B0GTMZSRLY | Zest Under Eye Patches |  |

_Last synced: 2026-07-27 (3 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

Women 25–50 buying affordable self-care/skincare extras; impulse + gift friendly price point.

## Voice & tone

Fresh, light, ritual-forward — a spa moment at home.
Fits: "Ten minutes. Cooler, brighter under-eyes."
Does not fit: medical/anti-aging promises, luxury-brand seriousness.

## Claims — approved

**Acure cosmetic model: ingredient + free-from facts per current listing; cosmetic-APPEARANCE wording only.**

| Claim | Substantiation |
|---|---|
| With Collagen & Hyaluronic Acid | label / current listing |
| "Reduces the appearance of" puffiness/dark circles/wrinkles | cosmetic wording — appearance only |
| Count/usage facts (pairs per jar etc.) | label |

## Claims — banned

- Structural/medical skin claims: "removes wrinkles", "repairs skin", "treats dark circles" — appearance wording only.
- Anything not on the current listing/label.

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO — team to add (under-eye patch category is crowded; name the 2–3 actually competing on our keywords).

## Notes

- Only 3 ASINs, one with a bare 23-char title ("Zest Under Eye Patches") — under-optimized; the one quick listing-copy win worth taking.
- 1 rank radar.
