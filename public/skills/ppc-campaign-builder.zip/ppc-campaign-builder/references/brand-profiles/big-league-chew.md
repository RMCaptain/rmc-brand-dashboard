# Brand Profile: Big League Chew

```yaml
brand_id: big-league-chew
name: Big League Chew
marketplaces: [CA]
category: candy — bubble gum
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B0FXYFNYDB | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... | Yes |
| B0015DMKGI | Big League Chew Sour Apple 12 Pack Box |  |
| B0FKKJ672S | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... | Yes |
| B0FXYG5H5T | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0FKD1YM9G | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... | Yes |
| B0FXYGNW3N | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... | Yes |
| B0FKKRMLGY | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... | Yes |
| B000FOIYSG | Big League Chew, Outta' Here Original Bubble Gum, 2.12-Ounce Pouches (Pack of 12) |  |
| B0FXYD5X11 | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0FXYGBGKN | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... | Yes |
| B0G1NH4N9H | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0FKKZ99Y5 | Big League Chew Bubble Gum, Shredded Bubblegum in a Stay Fresh Pouch, Soft Shredded Che... |  |
| B0087SVODE | Big League Original Chew Bubble Gum 12 Count |  |
| B09ZJ4BG5F | (no title on file) |  |
| B0H312JDRZ | (no title on file) |  |
| B0H1Y1YDXK | (no title on file) | Yes |

_Last synced: 2026-07-27 (16 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

Mostly parents buying for kids, plus nostalgic adults who grew up with it. The baseball connection exists but is not a major purchase driver — don't lean the copy on it. Price position: slightly above regular gum, below premium gum on a per-gram basis.

## Voice & tone

Fun and nostalgic, slightly sporty, playful at about 6/10 — a wink, not a circus.
Fits: "The original shredded bubble gum, in the pouch you remember."
Does not fit: full-zany candy voice, heavy baseball framing, anything health-adjacent, dry corporate copy.

## Claims — approved

**It's candy. There are no health benefits at all — claims are facts about the product, nothing more.**

| Claim | Substantiation |
|---|---|
| Flavor (Original, Sour Apple, etc.) | label |
| Count / pack size | label |
| Shredded format | product itself |
| Stay-fresh pouch | packaging, as a physical descriptor only |

## Claims — banned

- Any claim that supports, diagnoses, treats, or prevents any disease, illness, or condition — and any health-benefit implication of any kind (dental, sugar-related, or otherwise).

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

Hubba Bubba, Dubble Bubble, Bazooka — definitely cross-shopped, but **we do not chase their terms**. Stay on Big League Chew branded and category terms, and protect the SEO work already done (Defend-tier keywords survive every rewrite — see Keywords tiers).

## Notes

- **Hero:** Original flavor, by a distance.
- **Catalog quirk:** variety packs outperform every other product by a long shot — except 12-packs of Original. Weight ads and copy attention accordingly.
- Promo cadence and S&S strategy: TODO — confirm with Mike.
