# Brand Profile: Purewine

> **OFFBOARDING (Mike, 2026-07-23):** brand is leaving RMC soon. Maintenance only — no proactive listing rewrites, audits, or campaign builds unless Mike asks. Unconfirmed draft sections below are frozen as-is.

```yaml
brand_id: purewine
name: Purewine
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B07LGBLWBS | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... | Yes |
| B06XGP85LR | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... | Yes |
| B09HJJ2C8Z | PureWine Phoenix Bio-Pods - Premium Wine Filter Replacements for Enhanced Flavour - Rem... |  |
| B09HJMRZWS | Phoenix Wine Aerator & Purifier - Reusable Wine Aerator Pourer with BioPod Filter Syste... |  |
| B099MNMLVZ | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B09RRX1XF8 | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B0BJ4JSQB6 | Phoenix Wine Aerator & Purifier - Reusable Wine Aerator Pourer with BioPod Filter Syste... |  |
| B0771H8V5H | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B08TRNKYND | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... | Yes |
| B08JNQ39JM | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... | Yes |
| B099M8WLKD | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B06XGP5B63 | PureWine The Wand Wine Purifier - Remove Histamine & Sulfites, Eliminate Headaches & Al... |  |
| B0CN9J6NQ4 | PureWine Pink Wand Technology Histamine and Sulfite Filter, Purifier Reduces Wine Aller... |  |
| B0FL9J8QJQ | (no title on file) |  |
| B06XBPFHNJ | PureWine Wand Filters Stick Histamines and Sulfites - Reduces Wine Allergies & Purifier... |  |

_Last synced: 2026-07-27 (15 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

_(draft — Mike to confirm)_ Wine drinkers 30–65 who get headaches/congestion from wine, plus gift buyers (host gifts, wine lovers). Problem-aware shoppers searching for a fix. Premium accessory pricing.

## Voice & tone

_(draft)_ Confident, practical, a little celebratory — solving a real annoyance without medical gravity.
Fits: "Filter out the histamines and sulfites. Keep the wine."
Does not fit: medical promises, chemistry-lecture tone, party-gimmick silliness.

## Claims — approved

**Apply per product per its current listing; never transplant.**

| Claim | Substantiation |
|---|---|
| Removes/filters histamines & sulfites | product function, current listings |
| Removes sediment | current listings (Phoenix pods) |
| No added chemicals / nothing added to the wine | current listings where stated |
| Works with red, white & rosé | current listings |
| BPA-free etc. | label facts where stated |

## Claims — banned

- **PENDING MIKE:** "Eliminate Headaches & Allergies" is on the CURRENT live titles — that is a health-outcome claim, not a filtration fact. Draft position: banned in all NEW copy (say what the filter removes, never what symptoms it prevents); existing titles are the brand's call to fix. Confirm.
- Any health outcome: prevents/eliminates headaches, allergy relief, hangover prevention/cure.
- Any implication of medical benefit or that filtered wine is "healthier".

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO — team to add (Üllo is the known category rival; confirm before targeting).

## Notes

- Current live titles carry the "Eliminate Headaches & Allergies" claim — flagged above; several titles also exceed 75 chars (in the title sweep).
- Strong gifting angle (occasions/holiday) worth a promo-calendar note.
