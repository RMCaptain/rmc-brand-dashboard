# PPC Budget Model

How campaign budgets are sized and allocated. Used by `/ppc-campaign-builder` (allocation table) and available to `/ppc-deep-dive` (budget sanity checks). Every number this model produces is a **conservative starting point — the PPC Specialist's call**. RMC has no monthly ad envelopes: totals are built bottom-up from CPC and CVR, and scaling is governed by brand TACOS, never by a budget cap.

## Data ladders

Use the first available source; anything below rung 1 goes in the assumptions list.

**CPC** (per campaign / keyword theme):
1. Actual CPC from the ASIN's existing campaigns (restructures — pull from campaign export or Ads MCP)
2. Data Dive keyword CPC estimates (dashboard `get_datadive`, Data Dive MCP, or CSV export)
3. Placeholder — mark every derived number "placeholder — pull Data Dive before launch"

**CVR**:
1. Ad CVR for the ASIN: ad orders ÷ ad clicks from existing campaigns
2. Dashboard ASIN CVR (units ÷ sessions) — this is *total* CVR including organic; label it "total CVR — ad CVR typically runs lower"
3. Brand `avgCvr` from the dashboard, same label
4. 10% placeholder, flagged

## Sizing (bottom-up, anchored on Exact)

1. **Size the Exact campaign for ~1 order/day:** clicks/day = 1 ÷ CVR; Exact daily budget = clicks/day × CPC.
   *Example: CVR 10%, CPC $1.20 → 10 clicks/day → $12/day.*
2. **Total recommended daily budget** = Exact budget ÷ Exact's split share (launch: ÷ 0.40).
3. **Allocate the rest by the split table below.**
4. **Report per campaign:** % share, daily $, expected clicks/day at its CPC (auto ≈ 70% of exact CPC), expected orders/day at its CVR, implied ACOS.

**Click floor:** every campaign needs ≥ 3 clicks/day at its expected CPC to produce data. Below floor → don't silently keep it; propose merging (phrase into broad, competitor into exact) or state "below click floor — slower data, acceptable for research."

## Split by campaign type

| Campaign type | Launch | Restructure |
|---|---|---|
| Exact (performance) | 40% | 55% |
| Auto (research) | 25% | 15% |
| Broad (research) | 20% | 15% |
| Phrase (research) | 10% | 10% |
| Competitor / product targeting | 5% | 5% |

Restructure shifts research budget into Exact because proven search terms already exist — the harvest loop has done its job.

**Adjustment rules** (apply and say so in the output; the PPC Specialist can override any of them):
- No competitor ASINs in the brand profile → fold Competitor into Exact (45/60%).
- Thin keyword data (< 10 usable keywords) → shift 10 pts from Phrase to Auto; research has to cast wider.
- Existing campaigns already cover a type → its share goes to the gap being filled, not duplicated.

## Guardrails

**Implied ACOS per campaign** = CPC ÷ (CVR × price). Check against the SKU's ACOS target — brand profile Targets table first; RMC SKUs generally target **15–30% ACOS depending on the SKU** (global default ≤ 30%, `kpi-targets.md`). Over target → do one of, explicitly:
- propose a starting bid below the CPC estimate that brings implied ACOS inside target, or
- label the campaign "launch-phase overage — conscious call" with the expected settle path.
Never present an over-target campaign without one of those two labels.

**Brand TACOS check** (brand goal ≈ **3–4%**): projected monthly spend = total daily budget × 30.4. Compare against the brand's trailing-30d revenue (dashboard): if existing spend + new campaigns would push brand TACOS past 4%, flag it at the top of the allocation table before anything else. If brand TACOS is already above goal, recommend starting at 50–75% of computed budgets and say so.

**Scaling:** hold starting budgets until ACOS stabilizes (≥ 7 days, attribution settle), then scale in ~20% steps only while brand TACOS holds the 3–4% goal band.
