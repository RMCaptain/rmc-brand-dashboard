---
name: listing-copy
description: Write or rewrite conversion-focused Amazon listing copy — title, Item Highlights, bullets, description, backend keywords — compliant with the July 2026 75-character title policy. Also runs title-compliance checks and whole-brand catalog audits (duplicates, variant discipline, multi-pack sprawl, missing data, zombie ASINs). Use for any listing copy request, new product launches, "fix this title/listing", or "audit the catalog".
---

# /listing-copy [ASIN or product] [--titles-only for a compliance sweep]

Writes complete, compliant, keyword-loaded Amazon listing copy in the brand's voice.

## Read first

1. `references/rmc-standards.md` and `references/amazon-style-guide.md` (in this skill folder on claude.ai; at `../../references/` in the repo).
2. The brand's profile in `references/brand-profiles/<brand-id>.md`. No profile → say so, ask for brand voice/claims context, proceed with what's given.

## Inputs (gather before writing)

- **Product facts:** ASIN or product description, variant details (size/count/flavour), current listing copy if it exists.
- **Keywords, in priority order:**
  1. Dashboard Data Dive data (Claude Code: `/api/datadive/:brandId`; claude.ai: the RMC Dashboard connector's `get_datadive` — per dashboard-access.md) — niche keyword lists (volume/relevancy) + Rank Radar rank histories, refreshed Mondays. Default first stop.
  2. Data Dive MCP if connected — live pull for the ASIN or niche (fresher than the weekly snapshot; use for brand-new listings).
  3. A Data Dive or Helium 10 CSV export pasted/uploaded by the user (ask for the Rank Radar export too).
  4. Keywords listed in the brand profile.
  5. None available → write from product facts, label output "keywords not data-backed — rerun with Data Dive data before publishing".
- Ask ONE consolidated question for anything missing. Don't drip-feed questions.

## Steps

1. **Claims check.** List every claim implied by the product facts/current copy. Anything not in the brand profile's approved list → exclude and flag. Health products: structure/function wording only, per the style guide.
2. **Keyword plan — rank-banded tiers.** Score = volume × relevancy × winnability, where winnability comes from current organic rank (Rank Radar):
   - **Defend (rank 1–5):** PRESERVATION RULE — no rewrite may drop a word the ASIN ranks top-5 for. These keep their title placement, always.
   - **Strike zone (rank 6–30):** the priority tier — indexed and winnable. Gets the best remaining title/Highlights/bullet 1–3 real estate. Note in the output that these deserve matching exact-match PPC pressure (route to `/ppc-campaign-builder`).
   - **Index gaps (relevant, not indexed):** literal inclusion in backend/description so the ASIN indexes at all. Cheap, low placement priority.
   - **Long shots (rank 31–100):** out of the copy plan by default; note them for PPC to evaluate.
   - **Conversion-share bonus:** where Data Dive shows the ASIN out-converting the market on a keyword, bump that keyword one tier up in placement priority — we win when seen, so get seen more.
   Data Dive is an ORGANIC source only — ignore any ad-looking metrics in its payloads; ads context comes from the dashboard's Amazon-direct endpoints. The brand profile's keyword table can override any tier (its Tier override column wins — the BM/specialist call beats the formula). No rank data available → fall back to volume × relevancy, and label the plan "rank-blind — verify against Rank Radar before publishing". Always cite the rank-data date; rank moves weekly.
   Placement: Defend + top Strike → title; next Strike → Item Highlights + bullets 1–3; supporting → bullets 4–5, description; unique leftovers + index gaps → backend. Never waste backend bytes on words already used.
3. **Write:**
   - Title ≤75 chars (formula + rules in style guide)
   - Item Highlights ≤125 chars
   - 5 bullets (~150–200 chars each, benefit-led per style guide)
   - Description ~1,500–2,000 chars
   - Backend search terms ≤250 bytes
4. **Verify programmatically** (Claude Code: `node -e`; claude.ai: count carefully and state counts): title ≤75, highlights ≤125, backend ≤250 bytes, no banned characters, no word repeated >2x in the title.
5. **Deliver** the draft with char counts on every element, the keyword→placement map, and flagged claims. Save as `Outputs/YYYY-MM-DD_listing-copy_<asin>.md` (Claude Code) or as a downloadable file (claude.ai).

## Titles-only compliance mode

When asked to sweep titles: for each ASIN, report current length; if >75, produce compliant title + Item Highlights using only words from the existing title (no new claims). Output a table: ASIN | old | old len | new | new len | highlights. Same verification step applies.

## Catalog audit mode

When asked for a catalog audit, "catalog issues", or a catalog clean-up for a brand, skip the copywriting flow and audit the catalog's structure instead.

**Get the data:** the brand profile's ASIN table, plus per dashboard-access.md — Claude Code: `/api/listing-content/:brandId` + `/api/brands?preset=last90d`; claude.ai: connector `get_listing_content` + `get_brand_report` + `get_listing_health`. Listing content gives real parent/child variant relationships, structured attributes, image counts, and suppression issues — prefer it over title heuristics for checks 1, 2, 4, and 8. Use ~90 days of sessions/sales per ASIN where available.

**Checks — run all; if data for one is missing, say so and move on:**

1. **Duplicate listings** — near-identical titles on different ASINs (the title sweep found byte-identical pairs). Flag as merge-or-differentiate decisions for the BM.
2. **Variant discipline** — every variant title carries its distinguisher (size/count/flavour/model); flag families whose titles use inconsistent naming patterns, and any variant indistinguishable from a sibling by title alone.
3. **Multi-pack sprawl** — the same product spread over many pack-size ASINs (2/3/6/12-pack): flag likely cannibalization and consolidation candidates, with each ASIN's 90d sales beside it.
4. **Missing catalog data** — "(no title on file)" ASINs, missing structured attributes (flavour, unit count, size — hurts filtering and SEO), listings with zero bullets/description (check Amazon's own `issues` field in listing content — it names exact problems like over-length Item Highlights or missing attributes). NOTE: variation PARENT ASINs are placeholder listings — `incomplete` status and empty content on a parent is normal, never a finding. Flag only non-parent incompletes (cross-check against the parentAsin values of sibling rows).
5. **Zombie ASINs** — near-zero sessions AND sales over 90d: candidates to deprioritize or retire; never recommend deletion, only flag.
6. **Title compliance** — over 75 chars, ALL-CAPS words, banned characters, promo language in titles.
7. **S&S gaps** — where the profile's strategy notes call for repeat-purchase/S&S focus, list ASINs not S&S-enabled.
8. **Health flags** — suppressed/stranded/unfulfillable and Buy Box losses from `get_listing_health`.

**Output:** ranked catalog fix list — issue | ASINs affected | evidence (numbers + period) | recommended action | owner (BM / Amazon Specialist). Lead with a one-line verdict on catalog shape (family count, sprawl, dead weight). Save as `Outputs/YYYY-MM-DD_catalog-audit_<brand>.md` (Claude Code) or a downloadable file (claude.ai). Draft-only, as always — catalog changes go through the BM.

## Rules

- Draft only — never publish to Seller Central or anywhere else.
- Variant distinguishers (size, count, flavour, colour, model number) must survive every rewrite.
- Never invent claims, ingredients, specs, or certifications. Missing fact → ask or omit.
- Two variants of the same parent get copy that differs exactly where the products differ.

## Self-check before delivering

- [ ] Every length limit verified and stated
- [ ] No unapproved claims; flags listed
- [ ] Keywords actually placed, not just listed
- [ ] Brand voice matches profile (or absence of profile was flagged)
