# KPI Targets & Flags

The numbers every audit and review in this pack measures against. Source: RMC Operations Playbook + brand dashboard conventions.

**Ownership:** the Brand Manager is accountable for overall brand performance — CTR, CVR, Search Query Performance, Buy Box, pricing, strategy, replenishment/purchase orders, and project coordination (internal + external). Amazon Specialists execute listing/catalog work behind CTR + CVR; the PPC Specialist owns ACOS and spend efficiency; the Warehouse Operations & Logistics Manager owns physical flow (supplier → warehouse/prep → Amazon, incl. prep). Route audit findings accordingly: performance calls → BM, listing execution → Amazon Specialist, ad execution → PPC, physical/inbound issues → Warehouse Ops.

## Target cascade

Audits judge each ASIN against the first available of: **explicit ASIN target** (brand profile Targets table) → **the ASIN's own trailing ~90d baseline** (median; use when ≥30 days of history) → **brand override** (profile) → **global defaults below**. CTR/CVR vary hugely by product — the globals are a floor for thin-history ASINs, not a grade for everything.

## Performance — global defaults (per ASIN unless noted)

| Metric | Target | Flag when |
|---|---|---|
| CVR (units ÷ sessions) | ≥ 8% | < 8% |
| ACOS | ≤ 30% | > 30% |
| TACOS (brand) | stable or declining | rising 2+ periods |
| Ad CTR (Sponsored Products) | ≥ 0.35% | < 0.25% |
| Buy Box % | ≥ 95% | < 90% |
| Refund rate | category-dependent | rising trend vs prior period |

## Listing quality (per ASIN)

| Element | Target |
|---|---|
| Title | ≤ 75 chars, formula per style guide |
| Item Highlights | filled, ≤ 125 chars |
| Images | 7+ (main on pure white) |
| Video | present |
| Bullets | 5, each ≥ 80 chars |
| A+ content | present |
| Rating | ≥ 4.3 |
| Reviews | scale toward 500+ |

## Severity convention

- **Critical:** suppressed/inactive listing, stranded inventory, Buy Box lost, disease-claim risk.
- **High:** CVR or ACOS beyond flag threshold, missing A+, title over 75 chars (post 2026-07-27).
- **Medium:** below-target images/bullets/rating, CTR below flag.
- **Low:** polish items (video missing, review velocity).

When a target here conflicts with a brand profile's stated target, the brand profile wins — note the override in the output.
