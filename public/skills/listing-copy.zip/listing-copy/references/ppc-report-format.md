# PPC Report Format — May's Workbook (captured 2026-07-17)

Captured from May's live workbook (Google Sheet, one tab per brand). Reproduce this structure exactly — same sections, same columns, same order. Do not redesign.

## Sheet layout (per brand)

One worksheet per brand. Header cell at top: `ACCOUNT NAME: <Brand>`. Two tables on the same sheet, monthly first, weekly below it.

## Table 1 — Monthly

One row per calendar month from Jan of the first tracked year to the current month, plus a `<YYYY> Total` row after each completed year's December. Current partial month: include it, and stamp the through-date in the row's Notes/label (e.g. "Jul 2026 (through Jul 15)") so partial-vs-full comparisons are obvious.

Columns, in order:

| # | Header | Fill |
|---|--------|------|
| 1 | (month label) | `Mon YYYY` — header cell in sheet reads "MoM" |
| 2 | YoY Diff | (this month − same month prior year) / same month prior year, on Total Sales. Blank if no prior-year data |
| 3 | MoM Diff | (this month − prior month) / prior month, on Total Sales. Blank for first row |
| 4 | Total Sales | dashboard total revenue for the month |
| 5 | Total Units | total units ordered |
| 6 | Total Orders | total orders |
| 7 | Sessions | total sessions |
| 8 | CVR | Total Orders / Sessions |
| 9 | Ad Sales | attributed ad sales |
| 10 | Ad Spend | ad spend |
| 11 | Impressions | ad impressions |
| 12 | Clicks | ad clicks |
| 13 | Ad Orders | attributed ad orders |
| 14 | CTR | Clicks / Impressions |
| 15 | CPC | Ad Spend / Clicks |
| 16 | ACoS | Ad Spend / Ad Sales |
| 17 | TACOS | Ad Spend / Total Sales |
| 18 | Organic Sales | Total Sales − Ad Sales |
| 19 | Ad Sales % | Ad Sales / Total Sales |
| 20 | Total Revenue from Ads | Ad Sales − Ad Spend |

**Formula note:** May's sheet computes YoY/MoM as diff ÷ *current* month and has broken cells (all-2025 MoM = 100%, Jan 2026 YoY = −825%). The skill computes diff ÷ *prior* period (standard). Flagged to May 2026-07-17 — if she wants her original method, change columns 2–3 only.

## Table 2 — Weekly

One row per week, `WoW Ending` = Saturday date (`d-MMM-yyyy`, e.g. `11-Oct-2025`). Week = Sunday–Saturday. A totals/summary row sits above the header row in her sheet (current-period totals); reproduce it.

Column groups (merged header row above the column headers): **PPC Performance** → **Overall Performance** → **Organic Performance**.

| Group | Columns, in order | Fill |
|-------|-------------------|------|
| (label) | WoW Ending | Saturday week-end date |
| PPC Performance | Ad Sales, Ad Spend, Impressions, Clicks, Ad Orders, ACoS, Ad CVR, CTR, CPC, TACOS | Ad CVR = Ad Orders / Clicks; ACoS = Spend/Ad Sales; TACOS = Spend/Total Sales |
| Overall Performance | Total Sales, Sessions, Total Order, CVR | CVR = Total Order / Sessions |
| Organic Performance | Organic Sales, Organic % | Organic = Total Sales − Ad Sales; % = Organic / Total Sales |
| (tail) | Total Revenue from Ads, Notes | Ad Sales − Ad Spend; Notes left blank for May |

## Formatting

- Money: `$#,##0.00`. Rates: `0.00%`. Counts: `#,##0`.
- CA and USD never mixed — if the brand runs both marketplaces, one sheet (or clearly separated table) per currency, matching however May's workbook splits it.
- Period + pull date stamped in a header cell per the SKILL.md output rules.

## Data sources (dashboard, per dashboard-access.md)

- Totals/Sessions: `/api/report-data/:brandId` (daily_metrics rollup)
- Ad metrics: `/api/report-ads/:brandId` (Sponsored Products, CA + US profiles)
- **Caveat:** dashboard ad data = Sponsored Products only. If May's manual numbers included Sponsored Brands/Display, skill output will read slightly lower on ad metrics — state this caveat in the chat summary until confirmed either way.
