# Brand Profile: Zellies

```yaml
brand_id: zellies
name: Zellies
marketplaces: [CA]
category: oral care — xylitol gum & mints
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B08K78TJ8D | Zellie's / 100% Xylitol Spearmint Breath Mints / No Aspartame, Gluten Free, Vegan & Kos... |  |
| B01LWKACRL | Zellies Xylitol Sweetened Cherry Berry Mints, 250 Count Jar |  |
| B0B25XZGGY | Zellie's / 100% Xylitol Cherry Berry Breath Mints / No Aspartame, Gluten Free, Vegan & ... |  |
| B0B26HRZLZ | Zellie's / 100% Xylitol Sugar Free Chewing Gum (Cinnamon, 240 Count (Pack of 1)) |  |
| B00CAUMQQE | Zellie's / 100% Xylitol Sugar Free Cinnamon Chewing Gum / Cinnamon Flavor (100 Count (P... |  |
| B00L2E2VXC | Zellies Cinnamon Xylitol Mints, 250 Count Jar by Zellies |  |
| B004MAEXRK | Zellie's Cool Fruit Mints, 250 Count Jar by Zellies |  |
| B0B26FWMXD | Zellie's / 100% Xylitol Sugar Free Cool Fruit Mints Breath Mints / Non-GMO, Low-Calorie... |  |
| B0B26HWF2Z | Zellie's / 100% Xylitol Cool Mint Breath Mints / No Aspartame, Gluten Free, Vegan & Kos... |  |
| B0B26XLQZ9 | Zellie's / 100% Xylitol Sugar Free Chewing Gum (Peppermint, 240 Count (Pack of 1)) |  |
| B00C5L14YS | Zellie's / 100% Xylitol Sugar Free Peppermint Chewing Gum / Peppermint Flavor (100 Coun... |  |
| B00CB1L4O2 | Zellie’s 100% Spearmint Xylitol Gum – Sugar Free Gums for Fresh Breath, Dental Gums for... |  |
| B004EB5C6I | Health Life Zellies Cool Mint Mints, 250 count jar |  |
| B0B25XVFLP | Zellie's /100% Xylitol Sugar Free Breath Mints / Non-GMO, Low-Calorie, Gluten Free, Veg... |  |
| B0B26KNSJC | Zellie's / 100% Xylitol Sugar Free Spearmint Chewing Gum / Spearmint Flavor (240 Count ... |  |
| B0D51HQH7G | Zellie's /100% Xylitol Sugar Free Breath Mints / Non-GMO, Low-Calorie, Gluten Free, Veg... |  |
| B0H24LPRRD | (no title on file) |  |
| B0DZ3LZ45C | (no title on file) |  |
| B00CASWC9W | (no title on file) |  |
| B0DZ3ZTNG5 | (no title on file) |  |
| B0B26SWRBG | Zellie's / 100% Xylitol Fresh Fruit Chewing Gum / No Aspartame, Gluten Free, Vegan & Ko... |  |
| B0F3FDCFT6 | (no title on file) |  |
| B0GLZ9YTSM | (no title on file) |  |
| B0GLYYNG94 | (no title on file) |  |
| B0H6C19K4Y | (no title on file) |  |
| B0F28BNPJC | (no title on file) |  |
| B0GVZ34ZK3 | (no title on file) |  |
| B0GVPYVPPK | (no title on file) |  |

_Last synced: 2026-07-16 (28 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

25–45, mostly women (men too), middle-to-upper income, health-conscious — and specifically invested in their oral health. They read ingredient panels. Premium position vs mainstream gum/mints.

## Voice & tone

Professional but fun; serious but trendy. Confident ingredient-first talk, never clinical, never juvenile.
Fits: "100% xylitol. Zero sugar. That’s the whole list." / "Gum that takes ingredients seriously."
Does not fit: medical/clinical tone, cutesy candy language, any effect promise (see Claims).

## Claims — approved

**The rule: say what’s IN it and what’s NOT in it — never what it DOES.** Ingredient and free-from facts are open season; effect language of any strength is banned (see below).

| Claim | Substantiation |
|---|---|
| 100% Xylitol | ingredient panel |
| Sugar Free | label |
| Aspartame Free | label |
| Non-GMO | label (mints) |
| Gluten Free | label |
| Vegan & Kosher | label (mints) |
| Low-Calorie | label (mints) |
| "Oral care" / "dental" as category words | allowed as descriptors only — e.g. "dental gum" OK; "supports dental health" NOT OK |

## Claims — banned

- ANY effect claim — cure, treat, prevent, support, improve, or change any condition. Includes soft forms: "supports oral health", "fights cavities", "remineralizes", "good for your teeth".
- **"Made in USA" or any US-origin framing — keep out at all costs.** We sell in Canada; US origin is a negative here.

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

Little direct xylitol competition in Canada (per search-term data). Watch: **PUR** (pur mints/gum — shoppers cross-search constantly), **Epic** (epic xylitol gum), **XyliMelts** (dry-mouth adjacent — their brand term converts for us at ~1% ACOS). Excel/Freedent are mainstream-gum noise, not competitors — negate, don’t chase.

## Notes

- B0GVPYVPPK: Cinnamon Gum, 100 count (Mike, 2026-07-16). Structured attributes (flavor/unit count) missing in Amazon catalog data — backfill in Seller Central. Possible duplicate of B00CAUMQQE (same product) — BM to confirm both should be live.
- B0GVZ34ZK3 (mints): PARKED per Mike 2026-07-16 — not found in our catalog despite live listing + rank radar; possibly orphaned/unauthorized. Do not work it.
- Zero S&S enrollment across the catalog despite fully replenishable products — open brand-audit recommendation.
- B0D51HQH7G dormant (zero traffic, zero inventory). B004EB5C6I stockout + B00CAUMQQE Buy Box collapse under investigation (2026-07-15 audits).
- Keyword tiers auto-populate from Data Dive rank radars (3 active) via the dashboard.
