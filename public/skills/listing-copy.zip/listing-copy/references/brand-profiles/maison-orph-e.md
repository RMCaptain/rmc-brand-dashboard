# Brand Profile: Maison Orphée

```yaml
brand_id: maison-orph-e
name: Maison Orphée
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B00PN1AFHE | Maison Orphée Grey Coarse Sea Salt w/Mineral from Noirmoutier Identical to Celtic Salt ... |  |
| B00PN0EW42 | Organic Dijon Mustard 250ml, BBQ & Grilling Condiment for Burgers, Marinades & Summer S... |  |
| B00PNQ0ER0 | Grey Non Iodized Fine Sea Salt ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral Rich Rea... |  |
| B00PN1AXLW | Grey Non Iodized Fine Sea Salt Shaker ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral R... |  |
| B0DPBJQ3QB | Grey Non Iodized Fine Sea Salt Shaker ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral R... |  |
| B0DPBK36TX | Grey Non Iodized Fine Sea Salt Shaker ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral R... |  |
| B015GEJJR4 | Organic Old-Fashioned Whole Grain Mustard 250ml, Low FODMAP Organic Mustard Condiment f... |  |
| B0DPBCPG8J | Grey Non Iodized Fine Sea Salt ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral Rich Rea... |  |
| B0DPBKTC1L | Fleur De Sel Flaky Sea Salt, Non-Iodized Sun Dried Mineral Salt with Trace Minerals, Ir... |  |
| B0DPGTT3ML | Grey Sea Salt Bundle 1kg Coarse + 500g Fine ‒ Organic Non Iodized Sel de Mer w/Potassiu... |  |
| B00PN0EUDU | Organic Yellow Mustard with Turmeric 250ml, BBQ Condiment & Dipping Sauce for Burgers a... |  |
| B0DPBCGM3B | Grey Non Iodized Fine Sea Salt ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral Rich Rea... |  |
| B0DPBKY581 | Maison Orphée Grey Coarse Sea Salt with Mineral from Noirmoutier Identical to Celtic Sa... |  |
| B00PN1AJHU | Fleur De Sel Flaky Sea Salt, Non-Iodized Sun Dried Mineral Salt with Trace Minerals, Ir... |  |
| B0DPBKTQTX | Fleur De Sel Flaky Sea Salt, Non-Iodized Sun Dried Mineral Salt with Trace Minerals, Ir... |  |
| B0DPGWGQJ7 | Fleur De Sel 125g & Fine Grey Sea Salt Shaker 250g ‒ Organic Non Iodized Sel de Mer w/P... |  |
| B0DPBJTX74 | Maison Orphée Grey Coarse Sea Salt w/Mineral from Noirmoutier Identical to Celtic Salt ... |  |

_Last synced: 2026-07-16 (17 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

TODO — who buys this and why, primary use cases, price position.

## Voice & tone

TODO — how this brand sounds; example phrases that fit and that do not.

## Claims — approved

TODO — only claims listed here may appear in copy. Include substantiation per claim. Until filled, skills must treat ALL claims beyond current listing copy as unapproved.

## Claims — banned

TODO

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO

## Notes

TODO — promos, S&S strategy, catalog quirks.
