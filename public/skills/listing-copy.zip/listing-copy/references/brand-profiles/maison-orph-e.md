# Brand Profile: Maison Orphée

> **OFFBOARDING (Mike, 2026-07-23):** brand is leaving RMC soon. Maintenance only — no proactive listing rewrites, audits, or campaign builds unless Mike asks. Unconfirmed draft sections below are frozen as-is.

```yaml
brand_id: maison-orph-e
name: Maison Orphée
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B00PN1AFHE | Maison Orphée Grey Coarse Sea Salt w/Mineral from Noirmoutier Identical to Celtic Salt ... |  |
| B00PN0EW42 | Organic Dijon Mustard 250ml, BBQ & Grilling Condiment for Burgers, Marinades & Summer S... |  |
| B00PNQ0ER0 | Grey Non Iodized Fine Sea Salt ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral Rich Rea... |  |
| B00PN1AXLW | Grey Non Iodized Fine Sea Salt Shaker ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral R... |  |
| B0DPBJQ3QB | Grey Non Iodized Fine Sea Salt Shaker ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral R... |  |
| B0DPBK36TX | Grey Non Iodized Fine Sea Salt Shaker ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral R... |  |
| B015GEJJR4 | Organic Old-Fashioned Whole Grain Mustard 250ml, Low FODMAP Organic Mustard Condiment f... |  |
| B0DPBCPG8J | Grey Non Iodized Fine Sea Salt ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral Rich Rea... |  |
| B0DPBKTC1L | Fleur De Sel Flaky Sea Salt, Non-Iodized Sun Dried Mineral Salt with Trace Minerals, Ir... |  |
| B0DPGTT3ML | Grey Sea Salt Bundle 1kg Coarse + 500g Fine ‒ Organic Non Iodized Sel de Mer w/Potassiu... |  |
| B00PN0EUDU | Organic Yellow Mustard with Turmeric 250ml, BBQ Condiment & Dipping Sauce for Burgers a... |  |
| B0DPBCGM3B | Grey Non Iodized Fine Sea Salt ‒ Sel De Mer Fin Gris from Noirmoutier, Mineral Rich Rea... |  |
| B0DPBKY581 | Maison Orphée Grey Coarse Sea Salt with Mineral from Noirmoutier Identical to Celtic Sa... |  |
| B00PN1AJHU | Fleur De Sel Flaky Sea Salt, Non-Iodized Sun Dried Mineral Salt with Trace Minerals, Ir... |  |
| B0DPBKTQTX | Fleur De Sel Flaky Sea Salt, Non-Iodized Sun Dried Mineral Salt with Trace Minerals, Ir... |  |
| B0DPGWGQJ7 | Fleur De Sel 125g & Fine Grey Sea Salt Shaker 250g ‒ Organic Non Iodized Sel de Mer w/P... |  |
| B0DPBJTX74 | Maison Orphée Grey Coarse Sea Salt w/Mineral from Noirmoutier Identical to Celtic Salt ... |  |

_Last synced: 2026-07-22 (17 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

_(draft — Mike to confirm)_ Home cooks and food-curious households who pay for provenance — organic buyers, Québec/French-food affinity, gift-basket builders. Premium grocery pricing.

## Voice & tone

_(draft)_ Warm, artisanal, provenance-proud — a good grocer telling you where the food comes from.
Fits: "Hand-harvested in Noirmoutier. Nothing else added."
Does not fit: industrial food-brand tone, health-benefit selling, hype.

## Claims — approved

**Facts model — origin, method, and label facts, per product per its current listing.**

| Claim | Substantiation |
|---|---|
| Origin (Noirmoutier, France etc.) | label / current listing |
| Organic (certified products only) | certification on label |
| Hand-harvested / sun-dried / cold-pressed / first cold pressing | label / current listing |
| Non-iodized, unrefined, no additives | label facts |
| Mineral-rich / trace minerals | current listings (descriptive of grey sea salt) |
| "Identical to Celtic salt" comparative | current listing — PENDING MIKE: keep or drop in new copy? |

## Claims — banned

- Health-benefit selling ("healthier salt", electrolyte/wellness framing) — it's food; sell provenance and taste.
- "Organic" on any product without the certification.

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO — team to add (Celtic/grey sea salt brands; premium mustard/oil brands per line).

## Notes

- Bilingual angle: French terms (Sel de Mer) already in titles — natural fit for .ca; keep French product names.
- 7 rank radars active.
