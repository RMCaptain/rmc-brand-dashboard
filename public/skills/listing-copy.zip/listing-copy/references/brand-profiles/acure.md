# Brand Profile: Acure

```yaml
brand_id: acure
name: Acure
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B003Z4UKGM | Acure Brightening Cleansing Gel - Vegan Face Scrub, Gentle Facial Cleanser for Radiant ... |  |
| B003Z4OD24 | Acure Brightening Facial Scrub, Exfoliating Face Wash, Gentle Daily Scrubber & Exfoliat... |  |
| B003Z4QGRE | Acure Brightening Night Cream - Radiance Boosting Night Face Cream for Women & Men, Hyd... |  |
| B01KU49HEA | ACURE The Essentials Moroccan Argan Oil / 100% Vegan / Versatile - for Any Skin & Hair ... |  |
| B01IKK31UC | Acure Dry Shampoo - Mini Powder Dry Shampoo for Women with Brunette & Dark Hair, Care t... |  |
| B004DTQ9L8 | ACURE The Essentials Moroccan Argan Oil / 100% Vegan / Versatile - for Any Skin & Hair ... |  |
| B082G1C4BZ | Acure Ultra Hydrating 12 Hour Facial Cream - Intense Face Moisturizer for Women & Men, ... |  |
| B0FSTJ4KFP | Acure The Essentials Argan Oil - Organic Argan Oil for Hair & Skin, Pure Renewing Moist... |  |
| B0CMZ58SMT | Acure Bonding Hair Mask - Weekly Deep Conditioning Hair Mask for Damaged Locks, Rescue ... |  |
| B0CMZ1G5F9 | Acure Bonding Hair Serum - Leave In Hair Oil for Damaged and Frizzy Hair, Treatment for... |  |
| B0FSVVRJ9L | Acure Bonding Hair Serum - Leave In Hair Oil for Damaged and Frizzy Hair, Treatment for... |  |
| B0FSTKZ85S | Acure Bonding Leave-In Conditioner - Leave in Conditioner Spray for Women & Men, Moistu... |  |
| B09MYC86PG | Acure Brightening Day & Night Cream Set - Daily Cica Cream & Night Face Cream for Women... |  |
| B003Z4QHP0 | Acure Brightening Day Cream - Cica Cream, Anti Aging Moisturizer to Brighten for Women ... |  |
| B09L5GGN1Z | Acure Brightening Facial Scrub - Exfoliating Face Wash, Gentle Daily Scrubber & Exfolia... |  |
| B00H4H9RRE | Acure Curiously Clarifying Conditioner - Hair Conditioner for Women & Men with Oily Hai... |  |
| B0DY8RRY91 | Acure Curiously Clarifying Conditioner & Argan Gently Cleanses, Removes Buildup, Boost ... |  |
| B0DZDCG1FT | Acure Curiously Clarifying Shampoo and Conditioner Set - Daily Deep Cleansing & Hydrati... |  |
| B082G1Z6HH | Acure Daily Workout Watermelon Conditioner - Lightweight Hydrating & Moisturizing Condi... |  |
| B0FSX8ZSRY | Acure Daily Workout Watermelon Shampoo & Conditioner - Lightweight Hydrating & Clarifyi... |  |
| B0071HIE94 | Acure Dry Shampoo - Mini Powder Dry Shampoo for Women with Blonde & Dark Hair, Care to ... |  |
| B0DZDCMD6N | Acure Dry Shampoo - Mini Powder Dry Shampoo for Women with Blonde & Dark Hair, Care to ... |  |
| B071XVDZ1D | Acure Dry Shampoo - Mini Powder Dry Shampoo for Women with Brunette & Dark Hair, Care t... |  |
| B082G1XYRB | Acure Ultra Hydrating Green Juice Face Cleanser - Superfood Cleanser, Green Face Wash f... |  |
| B0FSTHT5RD | Acure Ultra Hydrating Green Juice Face Cleanser - Superfood Cleanser, Face Wash for Wom... |  |
| B082YG2VT1 | Acure Ultra Hydrating Conditioner - Deep Moisture Conditioner for Women & Men with Dry,... |  |
| B0CMZC4GY3 | Acure Bonding Leave-In Conditioner - Leave in Conditioner Spray for Women & Men, Moistu... |  |
| B003Z4MCJA | Acure Radically Rejuvenating Eye Cream - Under Eye Cream for Dark Circles & Wrinkles, F... |  |
| B082G1SBGX | Acure Resurfacing 1% Glycolic Acid & Unicorn Root Cleanser - Exfoliating Face Wash, Gly... |  |
| B0FSTLNKXY | Acure Resurfacing 1% Glycolic Acid & Unicorn Root Cleanser - Exfoliating Face Wash, Gly... |  |
| B0DZDDZ3SW | Acure Simply Smoothing Shampoo and Conditioner Set - Hydrating & Moisturizing for Women... |  |
| B082YG5X38 | Acure Simply Smoothing Shampoo - Hydrating Anti Frizz Shampoo for Women & Men, Moisturi... |  |
| B082YG4LNC | Acure Simply Smoothing Conditioner - Hydrating & Moisturizing Conditioner for Women & M... |  |
| B00B4C35IW | Acure Seriously Soothing Cleansing Cream - Gentle Hydrating & Exfoliating Face Wash, Da... |  |
| B00BTYPW5E | Acure Soothing Day Cream - Moisturizer for Dry Sensitive Skin, Hydrating & Soothing Fac... |  |
| B078ZHPLNR | Acure Ultra Hydrating Shampoo - Moisturizing Shampoo for Women & Men, Moisturize & Soft... |  |
| B0DZDDDJ4Z | Acure Vivacious Volume Shampoo and Conditioner Set - Thickening & Volumizing Hair Care ... |  |
| B082YGK39W | Acure Vivacious Volume Shampoo - Volumizing Shampoo for Fine Thin Hair, Add Body and Th... |  |
| B082YG2VT8 | Acure Vivacious Volume Conditioner - Volumizing Conditioner for Women & Men, Lightweigh... |  |
| B07NJ4H5S3 | Acure Radically Rejuvenating Whipped Night Cream - Anti Aging Peptide Night Face Cream ... |  |
| B0GSSFNDNL | Acure Brightening Body Scrub - Exfoliating Body Scrub with Sea Salt, Scrubber for Men &... |  |
| B0DHJD7FYM | Acure Zombie Cell Clarifying Serum - Rejuvenate Face Serum with Niacinaminde & Milk Thi... |  |
| B0GR1QQK8B | Acure Radically Rejuvenating Rose Argan Oil - Face, Hair & Body Oil Serum Rich in Vitam... |  |
| B0GR1SVFJ7 | Acure Bonding Hair Mask - Weekly Deep Conditioning Hair Mask for Damaged Locks, Rescue ... |  |
| B0GR1VW2H4 | Acure Bonding Hair Serum - Leave In Hair Oil for Damaged and Frizzy Hair, Treatment for... |  |
| B0GR2471JR | Acure Simply Smoothing Shampoo and Conditioner, Hydrating & Moisturizing for Women & Me... |  |
| B0GR3QLN62 | Acure Bonding Leave-In Conditioner - Leave in Conditioner Spray for Women & Men, Moistu... |  |
| B0GR6ZW4MM | Acure Brightening Day & Night Cream, Daily Cica Cream & Night Face Cream for Women & Me... |  |
| B0GR7CTHSM | Acure Daily Workout Watermelon Shampoo & Conditioner - Lightweight Hydrating & Clarifyi... |  |
| B0GRK2X3HB | Acure Dry Shampoo - Mini Powder Dry Shampoo for Women with Blonde & Dark Hair, Care to ... |  |
| B0GRK7DPY1 | Acure Dry Shampoo - Mini Powder Dry Shampoo for Women with Brunette & Dark Hair, Care t... |  |
| B082YH2CD8 | Acure Curiously Clarifying Conditioner - Hair Conditioner for Women & Men with Oily Hai... |  |
| B0GS49LYNS | Acure Curiously Clarifying Conditioner & Argan Gently Cleanses, Removes Buildup, Boost ... |  |
| B0040ZHUH2 | Acure Brightening Glowing Serum - 100% Vegan, Brighter Skin Appearance, Argan Oil, Pump... |  |
| B082YGKB59 | Acure Brightening Body Scrub - Exfoliating Body Scrub with Sea Salt, Scrubber for Men &... |  |
| B082YFMNTK | Acure Radically Rejuvenating Dual Phase Bakuchiol Serum - Bakuchiol Oil Serum for Face,... |  |
| B082G1VNQ6 | Acure Daily Brightening Vitamin C Serum with Ferulic Acid - Brightening Face Serum for ... |  |
| B0DHJH8534 | Acure Zombie Cell Clarifying Mask - Detoxifying Face Mask with Niacinamide, Pore Minimi... |  |
| B0GR1NVK6Q | Acure Resurfacing 1% Glycolic Acid & Unicorn Root Cleanser - Exfoliating Face Wash, Gly... |  |
| B0GR1KZ3FY | Acure Ultra Hydrating Green Juice Face Cleanser - Superfood Cleanser, Green Face Wash f... |  |
| B0GQXK7D5W | Acure Brightening Facial Scrub, Exfoliating Face Wash, Gentle Daily Scrubber & Exfoliat... |  |
| B082G1C4BV | Acure Daily Workout Watermelon Shampoo - Lightweight Hydrating & Clarifying Shampoo for... |  |
| B082YFN2ZK | Acure Curiously Clarifying Shampoo - Cleansing & Clarifying Shampoo for Women & Men, Sc... |  |
| B0GX2S2XBZ | Acure Curiously Clarifying Shampoo and Conditioner, Daily Deep Cleansing & Hydrating Se... |  |
| B0FSWHQ91F | Acure Brightening Body Scrub - Exfoliating Body Scrub with Sea Salt, Scrubber for Men &... |  |

_Last synced: 2026-07-16 (65 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

TODO — who buys this and why, primary use cases, price position.

## Voice & tone

TODO — how this brand sounds; example phrases that fit and that do not.

## Claims — approved

TODO — only claims listed here may appear in copy. Include substantiation per claim. Until filled, skills must treat ALL claims beyond current listing copy as unapproved.

## Claims — banned

TODO

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO

## Notes

TODO — promos, S&S strategy, catalog quirks.
