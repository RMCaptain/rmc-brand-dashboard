# Brand Profile: Jarrow

```yaml
brand_id: jarrow
name: Jarrow
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B001GAOHMK | Jarrow Formulas Biotin 5000 mcg - 100 Veggie Caps, Pack of 2 - Supports Skin & Hair Gro... |  |
| B001F0R78M | Jarrow Formulas B-Right - 100 Veggie Caps, Pack of 2 - Low-Odor Vitamin B-Complex Formu... |  |
| B003ZCNER6 | Jarrow Formulas - Glutathione Reduced 500 mg 60 caps (Pack of 2) |  |
| B00OGXISJW | Jarrow Formulas Vitamin B12 5000 mcg - Maximum Strength for Cellular Energy and Brain H... |  |
| B010E6RMLY | Jarrow Formulas Milk Thistle 150 mg - 100 Veggie Capsules - Antioxidant Supporting Immu... |  |
| B00R1OFSC8 | JARROW FORMULAS Qh Absorb Ubiquinol 200 MG, 60 CT |  |
| B00TDFMU2Y | Jarrow Formulas Same 200 mg - 60 Tablets - Highest Concentration of Active S,S Form - S... |  |
| B001GL1VGE | Jarrow Formulas Vitamin D3 2500 IU - 100 Softgels, Pack of 2 - Bone Health, Immune Func... |  |
| B000HKZ85A | Jarrow Formulas Curcumin 95 Supplement - Turmeric Extract Supplement, 500 mg for Antiox... |  |
| B0013OSK40 | Jarrow Formulas Co-Q10, Promotes Cellular Energy Production, 100 mg, 60 Caps |  |
| B00OGXKHB4 | Jarrow Formulas Glutathione Reduced 500 mg - 150 Veggie Capsules - Intracellular Antiox... |  |
| B000SPF03O | Jarrow Formulas MK-7 60 Softgels |  |
| B008OXVMBQ | Jarrow Formulas trans-Pterostilbene, 50 Milligrams Per Serving, 60 Vegetarian Capsules.... |  |
| B093RVLX3X | Jarrow Formulas QH-Absorb 200 mg - Active Antioxidant Form of Co-Q10 - Dietary Suppleme... |  |
| B001U3QT24 | Jarrow Formulas Zinc Balance 15 mg - 100 Veggie Caps, Pack of 2 - Immune Support - Incl... |  |
| B002LIGRN8 | Jarrow Formulas Krill Oil - 60 Softgels - Phospholipid Omega-3 Complex with Astaxanthin... |  |
| B003L8VQLK | Jarrow Formulas Vitamin D3 5000 IU, 100 Softgels, Pack of 2 |  |
| B001B1RUJ6 | Jarrow Formulas BroccoMax, Supports Liver Health, 60 Delayed Veggie Caps |  |
| B0013OSH5C | Jarrow Formulas Alpha Lipoic Sustain Capsules, 300 mg, 60 Count |  |
| B008OYI7RC | Jarrow Formulas Alpha Lipoic Sustain 300, Value Size, 300 Mg, 120 Sustain Tablets ( 3-P... |  |

_Last synced: 2026-07-16 (20 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

TODO — who buys this and why, primary use cases, price position.

## Voice & tone

TODO — how this brand sounds; example phrases that fit and that do not.

## Claims — approved

TODO — only claims listed here may appear in copy. Include substantiation per claim. Until filled, skills must treat ALL claims beyond current listing copy as unapproved.

## Claims — banned

TODO

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO

## Notes

No Data Dive coverage by design (not dived) — keyword work for this brand runs rank-blind; skills should not flag missing rank data as a gap.

TODO — promos, S&S strategy, catalog quirks.
