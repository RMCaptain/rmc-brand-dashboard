# Brand Profile: Supreme Petfoods

> **OFFBOARDING (Mike, 2026-07-23):** brand is leaving RMC soon. Maintenance only — no proactive listing rewrites, audits, or campaign builds unless Mike asks. Unconfirmed draft sections below are frozen as-is.

```yaml
brand_id: supreme-petfoods
name: Supreme Petfoods
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B007ZYR7T6 | Supreme Petfoods Science Selective Junior Rabbit 1.5 kg |  |
| B09PZ1772S | Supreme Petfoods Science Selective Bathing Sand for Hamsters, Gerbils, Chinchillas & Degu |  |
| B0058OCDBC | Tiny Friends Farm Supreme Russel Premium Crunchers Carrot Healthy Baked Bites for Rabbi... |  |
| B0DL6GG2V9 | Selective Vitamin C Care Supplement |  |
| B091VQJMRX | Supreme Petfoods Selective Naturals Berry Loops with Timothy Hay & Cranberry 80g |  |
| B01N442619 | Selective Naturals Garden Sticks for Rabbits |  |
| B083FS2FK6 | Science Selective Rabbit 8.8lbs |  |
| B01NA9AJPS | Selective Naturals Forest Sticks for Guinea Pigs |  |
| B078VKDBL2 | Supreme Selective Naturals Grain Free Rabbit Food 3.3Lbs |  |
| B07PJYSZYH | Supreme Science Selective Naturals Country Loops for Guinea Pigs, Chinchillas & Degus, ... |  |
| B07PGPQ54H | SUPREME Selective Naturals Harvest Loops 80 g (4 Pieces) |  |
| B01BHVDSGS | Supreme Petfoods Science Selective Rabbit Food, 4 lb |  |
| B0746RPLXX | Supreme Petfoods Selective Naturals Grain Free Guinea Pig Food, 3.3lbs 1 Pack |  |
| B07ZH7XSFN | (3 Pack) Supreme Lovelies Banana Strawberry & Apricot Baked Hamster Treat 4.2 oz |  |
| B005OCXN1M | Supreme Petfoods Tiny Friends Farm Bathing Sand |  |
| B00VF2AN7M | Supreme Petfoods Tiny Friends Farm Gerty Guinea Pig Tasty Mix, 2lb 1 Pack |  |
| B0B3S7QQHP | Supreme Petfoods Tiny Friends Farm Harry Hamster Fruity Nutty Mix, Various |  |
| B08T1QDV6Y | Supreme Tiny Friends Farm Russell Rabbit Tasty Mix 5.5lb |  |
| B00VF2IRH0 | Supreme Petfoods Tiny Friends Farm Reggie Rat and Mimi Mouse Tasty Mix, 2lb 1 Pack |  |
| B07SJ93GT7 | Supreme Petfoods 3 Pack of Charlie Chinchilla Cookies Small Pet Treats, 4.2 Ounces each... |  |
| B09S3YVPVF | Supreme Petfoods Tiny Friends Farm Charlie Chinchilla Cookies (Pack of Four) |  |
| B0012SNXJ4 | Supreme Petfoods Farm Gerty Guinea Pig Tasty Mix |  |
| B00J5Z03DU | Supreme Petfoods 3 Pack of Tiny Friends Farm Russel Rabbit Crunchers with Carrot, 4.2 O... |  |
| B0028Z5F96 | Supreme Russel Cherry and Apricot Crunchers 80G |  |
| B003672P98 | Supreme Petfoods Science Selective Hamster 350 g |  |
| B01BHVDS9A | Supreme Petfoods Science Selective Chinchilla Food, 4 lb |  |
| B087RSQN7Y | Supreme Petfoods Science Selective Guinea Pig 8.8lbs, Brown (4290) |  |
| B07QD5X7WY | SCIENCE Selective Supreme Junior Rabbit Food 4lb 6 ounce (pack of 1) |  |
| B0716ZVTJ5 | Supreme Petfoods Science Selective Mature 4+ Rabbit, 4.4lb 1 Pack |  |
| B0DL6C9B2M | Selective Skin & Coat Care Supplement |  |
| B0DL6G34D4 | Selective Urinary Care Supplement |  |
| B01BHVDSFE | Supreme Petfoods 4516 Science Selective Rat, 4lbs 1 Pack |  |
| B07SN6B37R | Supreme Petfoods 2 Pack of Selective Naturals Forest Sticks Guinea Pig Treats, 2.1 Ounc... |  |
| B07SH9G75L | Supreme Petfoods Selective Naturals Forest Sticks Treats (2.1 oz) (3-Pack) |  |
| B0DL6CZ2SZ | Selective Digestive Care Supplement |  |
| B01MTQP79L | Selective Naturals Meadow Loops for Rabbits |  |
| B01NBAN5OK | Selective Naturals Woodland Loops for Guinea Pigs |  |
| B00VF2G52E | Supreme Original Russel Rabbit Food Nutritious Balanced Pet Tasty Meal 2Lbs |  |
| B01BHVDS7C | Supreme Petfoods Tiny Friends Farm Hazel Hamster Tasty Mix (2 Pounds) |  |
| B00VF239NC | Supreme Petfoods Tiny Friends Farm Charlie Chinchilla Tasty Mix, 2lb 1 Pack |  |
| B00TPZ9H14 | Supreme Tiny Friends Farm Russel Rabbit Tasty Mix 5.5lb |  |
| B01BHVDUSE | Supreme Petfoods Tiny Friends Farm Gerty Guinea Pig Food, 6lbs 1 Pack |  |
| B07WG2S31B | Supreme Petfoods Science Selective House Rabbit Food, Brown,Natural,52.8 ounces |  |
| B003ZGBJII | Supreme Charlie Raisin Carrots Crunchers Cookies Pet Healthy Baked Bites 4.2z |  |
| B0922S61M3 | Selective Naturals Orchard Loops with Timothy Hay & Apple (Pack of 4) |  |
| B091VMQ93H | Supreme Science Selective Naturals Orchard Loops with Timothy Hay & Apple for Rabbits, ... |  |
| B07SJVR8RB | Supreme Petfoods 3 Pack of Selective Naturals Meadow Loops, 2.8 Ounces each, with Timot... |  |
| B07S1Q189X | Supreme Petfoods Russel Rabbit Fruities Small Pet Treats 3 Pack, 4.2 Ounce Each, Cherry... |  |
| B0C33TWCNL | Supreme Petfoods Science Selective Rabbit Food |  |
| B0C5MP1QNV | Supreme Petfoods Tiny Friends Farm Hamster Mix |  |
| B0030N1QZ2 | SupremePetfoods Charlie Chinchilla Food, 2-Pound |  |
| B07S4KLBK4 | Supreme Petfoods Russel Rabbit Fruities Small Pet Treats 2 Pack, 4.2 Ounce Each, Cherry... |  |
| B07SNW77J2 | Supreme Selective Naturals Garden Sticks 2.1 oz - Pack of 10 |  |
| B07SN66BBF | Supreme Selective Naturals Garden Sticks 2.1 oz - Pack of 12 |  |
| B07SM1ZX7B | Supreme Petfoods 2 Pack of Selective Naturals Garden Sticks Rabbit Treats, 2.1 Ounces e... |  |
| B07SNRX61V | Supreme Petfoods 3 Pack of Selective Naturals Garden Sticks Rabbit Treats, 2.1 Ounces e... |  |
| B07SNTYWWK | Supreme Selective Naturals Garden Sticks 2.1 oz - Pack of 6 |  |
| B01MYDU6BV | Selective Naturals Meadow Loops for Rabbits with Timothy Hay & Thyme 80g (Pack of 4) |  |
| B07SKCJYPX | Selective Naturals Woodland Loops Pissenlit & Rosehip Guinee Pig 2.8 oz - Lot of 4 |  |
| B07SKY1JVQ | Selective Naturals Woodland Loops Dandelion & Rosehip Guinea Pig 2.8-Oz - 3 Pack |  |
| B07SH9FRBN | Supreme Petfoods 2 Pack of Selective Naturals Woodland Loops Guinea Pig Treats, 2.8 Oun... |  |
| B07SNY9SKB | Supreme Selective Naturals Woodland Loops 2.8 oz - Pack of 10 |  |
| B07SNXRMF4 | Selective Naturals Meadow Loops Timothy Hay & Thyme For Rabbits 2.8-Oz - 2 Pack |  |
| B0791W7F4F | Supreme Petfoods Selective Naturals Meadow Loops for Rabbits 2.8oz (Pack of Four) |  |
| B078Y36KN1 | Selective Naturals Garden Sticks for Rabbits (Pack of Four) |  |
| B011M7W3MM | Tiny Friends Farm Russel Rabbit Munchers with Carrot & Leek 4.2oz |  |
| B07SLCVFKP | Russel Rabbit Carrot Crunchers Treat, 4.2-oz. |  |
| B07ZH9DWXQ | (2 Pack) Supreme Lovelies Banana Strawberry & Apricot Baked Hamster Treat 4.2 oz |  |
| B003ZGCC98 | Supreme Petfoods Tiny Friends Farm Gerty Guinea Pig Scrummies with Apple and Strawberry... |  |
| B09RTDJLN4 | Supreme Petfoods Tiny Friends Farm Gerty Guinea Pig Scrummies (Pack of Four) (8163) |  |
| B00VF22140 | Supreme Tiny Friends Farm Lovelies Hamster Treats, 4.2 Oz. |  |
| B07SK8ZFY5 | Tiny Friends Farm Premium Carrot & Leek Healthy Bites for Rabbits 4.2oz - 3 Pack |  |
| B07SN61M8M | Tiny Friends Farm Premium Carrot & Leek Healthy Bites for Rabbits 4.2oz - 2 Pack |  |
| B086L6RD13 | Supreme Scrummies Apple Strawberry Baked Bites For Guinea Pigs 4.2 oz - 3 Pack |  |
| B07RZMDR4W | Tiny Friends Farm Premium Baked Bites with Carrots for Rabbits 4.2 oz - 2 Pack |  |
| B07SKY1Z7D | Tiny Friends Farm Premium Baked Bites with Carrots for Rabbits 4.2 oz - 12 Pack |  |
| B07SG7CR89 | Tiny Friends Farm Premium Baked Bites with Carrots for Rabbits 4.2 oz - 4 Pack |  |
| B07SLBXMHJ | Tiny Friends Farm Premium Baked Bites with Carrots for Rabbits 4.2 oz - 6 Pack |  |
| B00GONV6AU | Science Selective Recovery Plus |  |
| B087ZGG2WV | Supreme Science Selective Guinea Pig Food |  |
| B078Y5VSTZ | (no title on file) |  |

_Last synced: 2026-07-22 (81 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

_(draft — Mike to confirm)_ Small-pet owners — rabbits, guinea pigs, hamsters, chinchillas, degus, rats. Caring, research-inclined owners buying species-specific food and treats; strong repeat purchase.

## Voice & tone

_(draft)_ Caring, knowledgeable, species-first — the small-pet specialist.
Fits: "Made for rabbits. Timothy hay first, always."
Does not fit: generic pet-brand tone, medical claims, cutesy baby-talk.

## Claims — approved

**Facts model per product per its current listing.**

| Claim | Substantiation |
|---|---|
| Species + life stage (Junior/Adult/Mature) | product line facts — SACRED variant distinguishers |
| Ingredient facts (Timothy hay, cranberry, no added sugar etc.) | label / current listing |
| "Veterinarian recommended" | ONLY where the current listing carries it — PENDING MIKE: confirm substantiation before any reuse |
| Texture/format facts (baked, sticks, loops) | label |

## Claims — banned

- Pet health-outcome claims: dental disease prevention, digestive treatment, urinary health promises — unless the exact wording is on the current listing/label, and even then flag before reuse.
- Transplanting claims across species products.

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO — team to add (Oxbow is the obvious category rival; confirm before targeting).

## Notes

No Data Dive coverage by design (not dived) — keyword work for this brand runs rank-blind; skills should not flag missing rank data as a gap.

- 81 ASINs, biggest managed catalog — species/life-stage/size variants everywhere; variant discipline matters most here.
- Second-biggest title-sweep workload after Acure.
