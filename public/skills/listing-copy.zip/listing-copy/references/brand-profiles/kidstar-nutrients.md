# Brand Profile: Kidstar Nutrients

```yaml
brand_id: kidstar-nutrients
name: Kidstar Nutrients
marketplaces: [CA]
category: TODO
```

## ASINs

<!-- AUTO:ASINS START — updated by tools/sync-profiles.js, do not edit between markers -->
| ASIN | Product | S&S |
|---|---|---|
| B09NJQGJTH | KidStar Nutrients BioFe Pure Iron Chewables, Sweet Blast, No Sugar, Sweetened with Xyli... |  |
| B0CJW8F4S4 | KidStar Nutrients BioFe Pure Iron Chewables, Sweet Blast, No Sugar, Sweetened with Xylitol |  |
| B0D9HX2FRP | Kidstar Nutrients - BioFe Pure Iron 5mg, 120 Chewable Tablets 60-Day Supply - Helps to ... |  |
| B0DPGP2NC4 | KidStar Nutrients - BeRegular Prebiotic Fibre & Probiotic Blend, 180g Unflavoured Powde... |  |
| B0B1RX555V | KidStar Nutrients - BioFe+ Iron Liquid for the Family, 250ml 50-Servings - Helps to Pre... |  |
| B0B1RJBWP7 | KidStar Nutrients - Star Multi Kids Multivitamin, 60 Chewable Tablets 60-Day Supply, Sp... |  |
| B0GYZNMV83 | KidStar Nutrients StarMulti Multinutrient Chewable (Space Berry) |  |
| B0F8KPTRF4 | KidStar Nutrients - BioFe Liquid Elemental Iron 30mg, 46 Sachets 46-Day Supply - Helps ... |  |
| B0B1RXN2VX | KidStar Nutrients - Vitamin D3 Spray 500 IU, 52ml Liquid 375-Servings, Organic Orange F... |  |
| B0GYZPSVRB | KidStar Nutrients - Vitamin D3 Spray 500 IU, Organic Orange |  |
| B0BTKTPBWD | KidStar Nutrients BioFe Pure Iron Chewables, Natural Grape Flavour, 10 Mg Iron Per Tabl... |  |
| B0GYZSDKFQ | KidStar Nutrients BioFe Pure Iron Chewables, Natural Grape Flavour, 60 Chewable Tablets |  |
| B0BJHHY19F | (no title on file) |  |
| B0GGDTTPJH | KidStar Nutrients All-in-One Vegan Protein Vanilla, For Kids and Adults, 10 Grams Plant... |  |
| B0GYZVJ3DV | KidStar Nutrients All-in-One Plant-Based Protein 400g |  |
| B09K4FX6T5 | KidStar Nutrients - BioFe+ Liquid Iron with Vitamin B6 & B12 for the Family, 250ml 50-S... |  |
| B0GYZVS452 | KidStar Nutrients BioFe+ Iron Liquid ADULT LABEL (Sweet Blast), 250 mL |  |
| B0B1RSXX4P | Kidstar Nutrients - BioFe Pure Iron Drops Unflavoured 30ml 50-Day Supply - Helps to Pre... |  |
| B0GZ1PJ7PS | KidStar Nutrients BioFe Pure Iron Drops Unflavoured 30ml |  |
| B0GYZMWT46 | KidStar Nutrients BioFe+ Iron Liquid KIDS LABEL (Sweet Blast), 250ml |  |
| B0GXX6QYWW | KidStar Nutrients - BioFe Liquid Elemental Iron 30mg, 46 Sachets 46-Day Supply - Helps ... |  |
| B0B1RNX7LS | KidStar All-in-One Vegan Protein Powder, Chocolate Flavour, Plant-Based Protein Blend, ... |  |
| B0GY1RQ7XQ | KidStar Nutrients BioFe Pure Iron 5mg, 120 Chewable Tablets & BioFe Pure Iron 5mg, 60 C... |  |
| B0GY1SB9KM | KidStar Nutrients BioFe+ Iron Liquid for the Family, Kids 250ml & BioFe+ Iron Liquid fo... |  |
| B0GXXBPZTL | KidStar Nutrients - BioFe+ Iron Liquid for the Family, 250ml 50-Servings - Helps to Pre... |  |
| B0GXX5Y68V | KidStar Nutrients - Star Multi Kids Multivitamin, 60 Chewable Tablets, Space Berry Flav... |  |
| B0GXXBFCT9 | KidStar Nutrients - Vitamin D3 Spray 500 IU, 52ml Liquid 375-Servings, Organic Orange F... |  |
| B0GXX63BWK | KidStar Nutrients Omega 3 with Vitamin D3, High-DHA, Lemon Blueberry, 120 Chewable Soft... |  |
| B0GY1KSZPB | KidStar Nutrients Omega 3 with Vitamin D3, 120 Chewable Softgels & BioFe Pure Iron 5mg,... |  |
| B0GYZVDXHH | KidStar Nutrients Omega 3 with Vitamin D3, High-DHA, Lemon Blueberry |  |
| B0GXX7VMG3 | KidStar Nutrients BioFe Pure Iron Chewables, Sweet Blast, No Sugar, Sweetened with Xyli... |  |
| B0GYZWXC7N | KidStar Nutrients Vitamin C Chewable tablets |  |
| B0GY1VK6ST | KidStar Nutrients BioFe Pure Iron Drops Unflavoured 30ml & BioFe+ Iron Liquid for the F... |  |
| B0GXX8DG6F | Kidstar Nutrients - BioFe Pure Iron Drops Unflavoured 30ml - Helps to Prevent Iron Defi... |  |
| B0GXWYHYLN | KidStar Nutrients BioFe Pure Iron Chewables, Natural Grape Flavour, 10 Mg Iron Per Tabl... |  |
| B0CGTNWQY1 | KidStar Vitamin C 250mg, 60 Sugar-Free Chewable Tablets 60-Day Supply, Tangy Tangerine ... |  |
| B0GY1W84L8 | KidStar Nutrients Vitamin C 250mg, 60 Chewable Tablets & BioFe Pure Iron 5mg, 60 Chewab... |  |
| B0GY1QV1DG | KidStar Nutrients Star Multi Kids Multivitamin, 60 Chewable Tablets & BioFe Pure Iron 5... |  |
| B0GY1RJV9T | KidStar Nutrients Vitamin C 250mg, 60 Chewable Tablets & Star Multi Kids Multivitamin, ... |  |
| B0GYZPLYWK | (no title on file) |  |
| B0GXX59C4G | (no title on file) |  |
| B0GXX48MQG | (no title on file) |  |
| B0GY1SBHQF | (no title on file) |  |
| B0H4S9BQ1Q | (no title on file) |  |
| B0H3QKZRPF | (no title on file) |  |

_Last synced: 2026-07-16 (45 ASINs)_
<!-- AUTO:ASINS END -->

## Audience

TODO — who buys this and why, primary use cases, price position.

## Voice & tone

TODO — how this brand sounds; example phrases that fit and that do not.

## Claims — approved

TODO — only claims listed here may appear in copy. Include substantiation per claim. Until filled, skills must treat ALL claims beyond current listing copy as unapproved.

## Claims — banned

TODO

## Keywords

| Keyword | Volume | Relevancy | Current rank | Tier (auto) | Tier override | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

Tiers: Defend (rank 1–5, never drop from title) · Strike zone (6–30, priority push) · Index gap (not indexed, backend fix) · Long shot (31–100, PPC’s call). Override beats the formula.
Source: Data Dive link / Rank Radar export date: TODO

## Targets (optional — overrides for the audit)

Only set where you have a specific goal; unset metrics use the ASIN’s own trailing baseline, then brand/global defaults.

| ASIN | Metric | Target | Why |
|---|---|---|---|
| | | | |

## Competitors

TODO

## Notes

TODO — promos, S&S strategy, catalog quirks.
