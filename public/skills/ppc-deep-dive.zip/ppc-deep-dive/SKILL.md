---
name: ppc-deep-dive
description: Weekly per-brand PPC performance review — conversion analysis, bid and budget recommendations, wasted spend, organic-vs-paid mix (TACOS). Use for "PPC review", "how are ads doing", weekly deep dives, or pre-BM-meeting ad prep.
---

# /ppc-deep-dive [brand] [period, default 30d vs prior 30d]

The weekly per-brand ads review from the PPC Specialist playbook, done in minutes: what changed, why, and the bid/budget moves to make.

## Read first

`references/rmc-standards.md`, `references/kpi-targets.md`, `references/dashboard-access.md` (in this skill folder on claude.ai; at `../../references/` in the repo). Brand profile for ACOS target overrides and S&S context.

## Get the data

- **Dashboard** (per dashboard-access.md): daily ASIN-level spend, attributed sales, clicks, impressions, ad orders + total units/revenue/sessions for the organic side. Claude Code pulls the API; claude.ai uses the RMC Dashboard connector (`get_brand_report`, `get_ads_campaigns`) if available, else the user pastes the report data.
- **Campaign layer (Claude Code):** `GET /api/ads/campaigns?brand=<id>` — budgets, states, targeting types, keyword/negative counts per campaign, refreshed daily. Use it for the bid/budget recommendations so they name real campaigns.
- **Amazon Ads MCP if connected:** placements and live data — enriches both layers.
- **Campaign-level export** (optional upload) fills the same gap without the MCP.
- State clearly which layers you had: ASIN-level only vs campaign-level too.

## Analysis

1. **Headline:** spend, attributed sales, ACOS, TACOS this period vs prior — and whether ad-driven revenue is growing faster than spend.
2. **Conversion analysis (per ASIN):** ad CVR (ad orders ÷ clicks) vs organic CVR (units ÷ sessions). Ad CVR well below organic → targeting/relevance problem; both low → listing problem (route to `/asin-audit` and `/listing-copy`). Rank ASINs by spend so the analysis follows the money.
3. **Bid recommendations:** ASINs/campaigns with ACOS under 2/3 of target and lost impression share signals (impressions flat while spend caps) → raise bids/budget ~10–20%. ACOS over target → lower bids ~10–15% on the offending targets, not across the board. State the observed CPC each rec is based on.
4. **Budget recommendations:** reallocate from over-target-ACOS campaigns to under-target ones with headroom; flag campaigns hitting daily budget caps early (if time-of-day data exists). Total budget change is a recommendation for May Grace, never an action.
5. **Wasted spend:** spend with zero attributed orders by ASIN (and by campaign if available), trailing total for the period.
6. **Organic-vs-paid mix:** TACOS trend; flag ASINs whose ad dependence rose 2+ periods (ad sales share climbing while total flat = buying the same revenue).

## Output

One-page brief: headline verdict → 3–7 ranked moves (each: what, where, size of change, expected effect, the number justifying it) → wasted-spend table → watch list. Currency labeled CA/US throughout, never mixed. Save as `Outputs/YYYY-MM-DD_ppc-deep-dive_<brand>.md` (Claude Code) or downloadable file (claude.ai).

## Rules

- ASIN-level data is Sponsored Products only. SB/SD spend exists brand-level (Master sheet "Ads (auto)" tab, ALL AD TYPES block) — fold it into the headline TACOS when available; otherwise label TACOS "SP only — understated". Say in the header which ad types the numbers include.
- Attribution: RMC standard is 7-day (matches the Ads console); dashboard API/connector data is 14-day until its migration ships (reads 3–5% higher). State the window used.
- Recommendations sized in percentages with the base number shown; no "increase bids" without how much and on what.
- Draft only — no pushes via Ads MCP. May Grace owns execution.
- Attribution lag: flag that the most recent ~3 days of attributed sales are understated; never judge those days as failures.

## Self-check

- [ ] Every move has a number, a size, and a location (campaign/ASIN)
- [ ] Attribution lag caveat present when the window includes recent days
- [ ] Data layers used are stated up front
