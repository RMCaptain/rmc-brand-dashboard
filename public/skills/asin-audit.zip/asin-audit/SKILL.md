---
name: asin-audit
description: Audit an internal RMC brand or specific ASIN against KPI targets using brand-dashboard data — CTR, CVR, ACOS, Buy Box, listing quality — and return a prioritized fix list. Use for "audit this brand/ASIN", "why is CVR down", monthly brand reviews, or pre-QBR prep.
---

# /asin-audit [brand-id or ASIN] [period, default 30d]

Turns dashboard data into a ranked list of what to fix, who owns it, and what to fix it with.

## Read first

1. `references/rmc-standards.md`, `references/kpi-targets.md`, `references/dashboard-access.md` (in this skill folder on claude.ai; at `../../references/` in the repo).
2. The brand profile in `references/brand-profiles/<brand-id>.md` for ASIN list and context.

## Get the data

- **Claude Code:** pull `/api/brands?preset=<period>` and `/api/report-data/:brandId` + `/api/report-ads/:brandId` per dashboard-access.md. Ask for credentials once if needed. For baselines, pull enough history to cover the audit period + the preceding ~90 days.
- **claude.ai:** use the RMC Dashboard connector if available (`get_brand_report` + `get_listing_health` + `get_datadive`, per dashboard-access.md). Otherwise ask the user to paste the brand's dashboard report data (or upload the PDF/dataset export). Work with what you have; list what's missing.
- Always use a comparison period (same length, immediately prior) when the data allows.

## Targets — the cascade (evaluate in this order, first match wins)

1. **Explicit ASIN target** from the brand profile's Targets table — someone set a goal; judge against it and say so.
2. **The ASIN's own trailing baseline** — compute from its history (preceding ~90 days, excluding the audit period): median CVR, ad CTR, ACOS. Judge the current period as deviation from its own normal: "CVR 11.7% vs own baseline 13.2% (−11%) — investigate," not "11.7% vs 8% = pass." An ASIN converting at 25% is a star to protect, not merely passing; an ASIN at 9% that normally does 14% is failing even though it beats the global floor.
3. **Brand override** in the profile, then **global defaults** in kpi-targets.md — the floor for ASINs with thin history (<30 days of data) where a baseline is noise.

Products differ wildly by nature — the cascade exists so high performers aren't graded on a curve meant for the catalog floor, and strugglers can't hide behind a global default they happen to clear.

## Audit dimensions (score each ASIN, flag per kpi-targets.md severity bands)

1. **Conversion:** CVR vs cascade target; sessions trend; price/Buy Box factors (Buy Box % <95, lost days).
2. **Traffic:** sessions trend vs prior period; ad CTR vs cascade target; impressions trend.
3. **Ad efficiency:** ACOS vs cascade target; spend trend vs attributed sales; ad CVR vs organic CVR gap.
4. **Listing quality:** title ≤75 chars (URGENT until 2026-07-27 sweep is done), Item Highlights present, image count, A+, bullets, rating ≥4.3, review count — from the listing itself if viewable, else from profile/user input.
   **Conversion-share check (Data Dive — dashboard `/api/datadive/:brandId` snapshots first, MCP live second):** pull keyword-level conversion share for the ASIN. Flag every keyword where the ASIN out-converts the market — each is a growth lever: push rank (listing-copy Defend/Strike placement) and buy traffic (exact-match PPC) on terms we already win when seen. Under-converting on high-volume terms points the other way: a listing/price problem on that intent, not a traffic problem.
5. **Catalog health:** suppressed/inactive/stranded flags, refund rate trend, inventory cover (on-hand vs run rate).

## Output — one page, ranked

1. **Verdict line per brand:** overall trajectory in one sentence with the two numbers that matter most.
2. **Fix list, ranked by revenue impact.** Each item: ASIN, what's wrong (metric vs target, period), why it likely matters (diagnosis, e.g. "CVR 4.1% vs 8% with healthy sessions → listing/conversion problem, not traffic"), the fix, owner per KPI ownership (BM / Amazon Specialist / PPC Specialist), and the tool to use (`/listing-copy` for copy fixes, `/ppc-*` for ad fixes).
3. **Watch list:** metrics inside targets but trending wrong.
4. Save as `Outputs/YYYY-MM-DD_asin-audit_<brand>.md` (Claude Code) or downloadable file (claude.ai).

## Rules

- Every number cites period + source. No number without a comparison or target next to it.
- Diagnose before prescribing: low CVR with collapsing sessions is a traffic story, not a listing story — say which it is and why.
- **No margin, COGS, buy cost, or profit figures in any output a client could see.** If asked for a client-facing version, strip them.
- Internal data only — this skill does not audit prospect/competitor ASINs (that's the brand-auditor app).
- Missing data shrinks scope, not confidence: audit what you have, list what you couldn't check.

## Self-check before delivering

- [ ] Every flag traces to a number vs target vs period
- [ ] Fixes are specific and routed to an owner and a tool
- [ ] Nothing client-unsafe in the output
